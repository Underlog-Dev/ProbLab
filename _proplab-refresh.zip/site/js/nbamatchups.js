// NBA team matchup tables (owner request 29 Oct 2026). Shared by the nightly builder (owner-tools/nba-matchups.mjs, writes
// data-nba-matchups.json) and the backtest (owner-tools/nba-matchup-backtest.mjs), so the site uses exactly what was tested.
// For every team, from the completed games BEFORE a date in a season:
//   pace            possessions per game (both teams' possessions averaged; possessions = FGA + 0.44 x FTA - OREB + TOV)
//   off[stat]       what its players produce per 100 possessions
//   def[stat]       what opponents' players produce against it per 100 possessions, overall and by position group (G, F, C)
// Early in a season each figure is blended with last season's final figure: (n x this season + K x last season) / (n + K), K = 10 games,
// so the tables move steadily instead of jumping after a few games. Factors are each team's figure divided by the league figure.
export const STATS = ['pts', 'reb', 'ast', 'stl', 'blk', 'tpm'];
export const POS = ['G', 'F', 'C'];
export const K_BLEND = 10;
export const posGroup = p => { const s = String(p || '').toUpperCase(); return s.startsWith('C') ? 'C' : s.includes('F') ? 'F' : s.includes('G') ? 'G' : null; };
export const COMBOS = { pts: ['pts'], reb: ['reb'], ast: ['ast'], stl: ['stl'], blk: ['blk'], tpm: ['tpm'], pr: ['pts', 'reb'], pa: ['pts', 'ast'], ra: ['reb', 'ast'], pra: ['pts', 'reb', 'ast'], sb: ['stl', 'blk'] };
const poss = b => (b ? (b.fga || 0) + 0.44 * (b.fta || 0) - (b.oreb || 0) + (b.tov || 0) : null);
const z = () => Object.fromEntries(STATS.map(s => [s, 0]));

/** Raw season sums. games: [{ id, date, home, away, hb, ab }] (final only); rows: [{ game, team, pos, pts, ... }] played rows of those games. */
export function seasonSums(games, rowsByGame) {
  const T = new Map(); const team = t => { if (!T.has(t)) T.set(t, { n: 0, poss: 0, off: z(), def: z(), dvp: Object.fromEntries(POS.map(p => [p, z()])) }); return T.get(t); };
  for (const g of games) {
    const ph = poss(g.hb), pa = poss(g.ab); if (!(ph > 0 && pa > 0)) continue; const P = (ph + pa) / 2;
    const rows = rowsByGame.get(g.id); if (!rows || !rows.length) continue;
    const H = team(g.home), A = team(g.away); H.n++; A.n++; H.poss += P; A.poss += P;
    for (const r of rows) {
      const mine = r.team === g.home ? H : r.team === g.away ? A : null; if (!mine) continue; const opp = mine === H ? A : H, pg = posGroup(r.pos);
      for (const s of STATS) { const v = Number(r[s]) || 0; mine.off[s] += v; opp.def[s] += v; if (pg) opp.dvp[pg][s] += v; }
    }
  }
  return T;
}
/** Per-100-possession table blended with last season. cur, prev: Maps from seasonSums. Returns { league, teams }. */
export function buildTable(cur, prev) {
  const per100 = x => { const o = { n: x.n, pace: x.n ? x.poss / x.n : null, off: {}, def: {}, dvp: {} };
    for (const s of STATS) { o.off[s] = x.poss ? (x.off[s] / x.poss) * 100 : null; o.def[s] = x.poss ? (x.def[s] / x.poss) * 100 : null; }
    for (const p of POS) { o.dvp[p] = {}; for (const s of STATS) o.dvp[p][s] = x.poss ? (x.dvp[p][s] / x.poss) * 100 : null; } return o; };
  const sumAll = M => { const a = { n: 0, poss: 0, off: z(), def: z(), dvp: Object.fromEntries(POS.map(p => [p, z()])) };
    for (const x of M.values()) { a.n += x.n; a.poss += x.poss; for (const s of STATS) { a.off[s] += x.off[s]; a.def[s] += x.def[s]; for (const p of POS) a.dvp[p][s] += x.dvp[p][s]; } } return a; };
  const Lc = per100(sumAll(cur)), Lp = prev && prev.size ? per100(sumAll(prev)) : null;
  const mix = (n, c, p, lgc) => { const pv = p ?? lgc; if (c == null) return pv; if (pv == null) return c; return (n * c + K_BLEND * pv) / (n + K_BLEND); };
  const league = Lc.n ? Lc : Lp; const teams = {};
  for (const t of new Set([...cur.keys(), ...(prev ? prev.keys() : [])])) {
    if ((cur.get(t)?.n || 0) + (prev?.get(t)?.n || 0) < 15) continue; // All-Star / exhibition sides (1-3 games a season) are not teams to rank
    const c = cur.has(t) ? per100(cur.get(t)) : { n: 0, pace: null, off: {}, def: {}, dvp: { G: {}, F: {}, C: {} } }, p = prev && prev.has(t) ? per100(prev.get(t)) : null, n = c.n;
    const o = { n, pace: mix(n, c.pace, p && p.pace, league.pace), off: {}, def: {}, dvp: { G: {}, F: {}, C: {} } };
    for (const s of STATS) { o.off[s] = mix(n, c.off[s], p && p.off[s], league.off[s]); o.def[s] = mix(n, c.def[s], p && p.def[s], league.def[s]); for (const q of POS) o.dvp[q][s] = mix(n, c.dvp[q][s], p && p.dvp[q][s], league.dvp[q][s]); }
    teams[t] = o;
  }
  // 29 Oct: the league reference is the average of the teams' BLENDED figures, so it is blended exactly like them. (The raw league figure of
  // this season alone made every early-season multiplier lean the same way: e.g. this season's faster league pace made every team look slow.)
  const L = Object.values(teams).filter(x => x.pace != null), avg = f => { const v = L.map(f).filter(x => x != null && Number.isFinite(x)); return v.length ? v.reduce((a, b) => a + b, 0) / v.length : null; };
  const lg = { n: league.n, pace: avg(x => x.pace), off: {}, def: {}, dvp: { G: {}, F: {}, C: {} } };
  for (const s of STATS) { lg.off[s] = avg(x => x.off[s]); lg.def[s] = avg(x => x.def[s]); for (const q of POS) lg.dvp[q][s] = avg(x => x.dvp[q][s]); }
  return { league: lg, teams };
}
/** A scaled line (line / scale) usually falls between two half-point lines; the probability is interpolated between them, which is the same as
 *  treating each whole-number result as spread evenly over +-0.5 (29 Oct: without this a small adjustment changes nothing unless it crosses a
 *  whole number). { lo, hi, w }: P(line) = (1 - w) x P(lo) + w x P(hi). At a half-point line w = 0. */
export const interpLine = L => { const lo = Math.floor(L - 0.5 + 1e-9) + 0.5; return { lo, hi: lo + 1, w: Math.max(0, Math.min(1, L - lo)) }; };
/** Multiplier for a player's expected output vs this opponent: (opp allows to his position / league)^gd x (opp pace / league pace)^gp. */
export function matchupMult(table, opp, pos, market, gd, gp) {
  const T = table && table.teams[opp], L = table && table.league, pg = posGroup(pos), comps = COMBOS[market]; if (!T || !L || !comps) return null;
  const a = comps.reduce((t, s) => t + (pg ? T.dvp[pg][s] : T.def[s]), 0), b = comps.reduce((t, s) => t + (pg ? L.dvp[pg][s] : L.def[s]), 0);
  if (!(a > 0 && b > 0 && T.pace > 0 && L.pace > 0)) return null;
  return Math.pow(a / b, gd) * Math.pow(T.pace / L.pace, gp);
}
