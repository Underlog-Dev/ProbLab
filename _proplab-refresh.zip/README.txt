PropLab data-refresh tools, used by .github/workflows/proplab-data-refresh.yml. Built 2026-11-04T14:02:26Z.
No API keys or secrets. See docs/AUTOMATIC-REFRESH.md in the owner pack.
4 Nov 2026 audit: real per-type data dates in data-refresh-status.json; MLS local dates from the stadium time zone; NFL injuries per team (older reports never replace newer); Scottish kick-off times from openfootball (CC0) when its date matches; extra validation checks.
5 Nov 2026: six scheduled runs a day (only the 23:47 catch-up is skipped when a run succeeded since 22:30); squad lists read at most every 10 hours.
