PropLab data-refresh tools, used by .github/workflows/proplab-data-refresh.yml. Built 2026-11-02T22:30:50Z.
No API keys or secrets. See docs/AUTOMATIC-REFRESH.md in the owner pack.
