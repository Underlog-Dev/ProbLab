PropLab data-refresh tools, used by .github/workflows/proplab-data-refresh.yml. Built 2026-10-29T16:36:48Z.
No API keys or secrets. See docs/AUTOMATIC-REFRESH.md in the owner pack.
