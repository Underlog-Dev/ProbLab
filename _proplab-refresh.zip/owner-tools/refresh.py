#!/usr/bin/env python3
"""PropLab Data Refresh: one repeatable run that updates the site's data (never its design or code).

Usage (from the owner pack folder):
    python3 owner-tools/refresh.py --work <empty-work-dir> [--live <existing clone of underlog-dev/ProbLab>] [--skip-nfl] [--skip-download]
GitHub Actions (.github/workflows/proplab-data-refresh.yml) runs it with --live <the checked-out repository> --state data-refresh-status.json
--status-out <file>: the status file (last run, last success per source, freshness checks) is then published as data-refresh-status.json.

What it does, in order (details in docs/DATA-REFRESH.md):
  1. Clones the live site (github.com/underlog-dev/ProbLab): the published data is the starting point and the baseline.
  2. Downloads the sources: football-data.co.uk season CSVs (current + previous season, all 8 European leagues) and fixtures.csv,
     openfootball 2026-27 season files (7 leagues: fixtures, kick-off times, rounds), American Soccer Analysis (MLS results, team
     shots, player rows) and nflverse (schedules, weekly player stats, play-by-play, weekly rosters). A source that fails is reported
     and its existing published data is kept unchanged.
  3. Converts them to builder inputs and runs owner-tools/build-data.mjs and owner-tools/nfl-build.py on a copy of the live data.
  4. Validates the result (owner-tools/validate.py). If validation fails, nothing is prepared for upload.
  5. Compares with the live files, ignoring date stamps. Only files whose data changed go to OUT/UPLOAD-TO-GITHUB
     (plus data-manifest.json whenever any data file changed, so browsers fetch the new files).
  6. Writes OUT/REFRESH-REPORT.md and OUT/refresh-state.json (last successful refresh per dataset).
Running it twice in a row gives "no changes" the second time.
"""
import argparse, csv, re, datetime, gzip, io, json, os, shutil, subprocess, sys, time, urllib.request
from collections import Counter, defaultdict

PACK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO = 'https://github.com/underlog-dev/ProbLab'
FD_DIVS = {'E0': 'epl', 'SP1': 'laliga', 'I1': 'seriea', 'D1': 'bundesliga', 'F1': 'ligue1', 'P1': 'ligaportugal', 'N1': 'eredivisie', 'SC0': 'scotprem',
           'E1': 'championship', 'E2': 'leagueone', 'E3': 'leaguetwo', 'B1': 'proleague', 'T1': 'superlig'}  # 27 Oct 2026: five more divisions
# football-data.co.uk 'extra leagues' (final score + UK kick-off time only; no half-time score or statistics): Eliteserien, calendar-year seasons
FD_EXTRA = {'NOR': ('Norway|Eliteserien', 'eliteserien')}
HISTORY_FIRST = 2021  # a league with no published season file from 2021/22 on gets that season downloaded once (new leagues bootstrap themselves)
OPENFOOTBALL = {'epl': ('en.1', 'Europe/London'), 'laliga': ('es.1', 'Europe/Madrid'), 'seriea': ('it.1', 'Europe/Rome'), 'bundesliga': ('de.1', 'Europe/Berlin'),
                'ligue1': ('fr.1', 'Europe/Paris'), 'ligaportugal': ('pt.1', 'Europe/Lisbon'), 'eredivisie': ('nl.1', 'Europe/Amsterdam'),
                'championship': ('en.2', 'Europe/London')}
# openfootball files that may not exist yet: used automatically once published (CC0), otherwise noted, not an error.
# Scottish Premiership 2026-27 is not published by openfootball as of 19 Oct 2026 (2025-26 is), so Scotland relies on football-data's
# weekly fixtures.csv until it is.
OPENFOOTBALL_OPTIONAL = {'scotprem': ('sco.1', 'Europe/London'), 'leagueone': ('en.3', 'Europe/London'), 'leaguetwo': ('en.4', 'Europe/London'),
                         'proleague': ('be.1', 'Europe/Brussels'), 'superlig': ('tr.1', 'Europe/Istanbul')}  # 27 Oct: used once openfootball publishes them
# 4 Nov 2026: openfootball's Football.TXT season files (CC0, github.com/openfootball/europe) are used while football.json lacks a league.
# Kick-off times only (kotimes-*.txt): a time fills in an already-published date-only fixture when both sources give the same date; it never
# adds a fixture or moves a date. No round calendar is taken from them (Scottish clubs meet twice at the same ground in one season, so a
# home/away pairing does not identify a round). Rounds with no date, marked TBC, or given only one nominal date and no times are ignored.
OPENFOOTBALL_TXT = {'scotprem': 'europe/master/scotland/{of}_sco1.txt', 'superlig': 'europe/master/turkey/{of}_tr1.txt', 'proleague': 'belgium/master/{of}/be1.txt'}
LEAGUE_NAMES = {'epl': 'Premier League', 'laliga': 'La Liga', 'seriea': 'Serie A', 'bundesliga': 'Bundesliga', 'ligue1': 'Ligue 1', 'ligaportugal': 'Liga Portugal',
                'eredivisie': 'Eredivisie', 'scotprem': 'Scottish Premiership', 'mls': 'MLS', 'ucl': 'Champions League', 'uel': 'Europa League', 'uecl': 'Conference League',
                'championship': 'Championship', 'leagueone': 'League One', 'leaguetwo': 'League Two', 'proleague': 'Belgian Pro League', 'superlig': 'Süper Lig', 'eliteserien': 'Eliteserien'}
NFLV = 'https://github.com/nflverse/nflverse-data/releases/download'
VOLATILE = {'updated', 'generated'}
UA = {'User-Agent': 'PropLab owner refresh (free statistics site; sources credited)'}

def log(*a): print(*a, flush=True)
# 9 Nov 2026: downloads are retried with growing waits, and kept in a cache that survives between runs (GitHub Actions cache, see the
# workflow). Files of completed seasons barely change, so a cached copy under 7 days old is used without downloading at all; when a
# download fails (e.g. HTTP 504 from GitHub's release servers), the last good cached copy is used instead and the run says so. A file is
# only ever replaced by a complete download (written to .part first), so a failed or cut-off download can never reach the site.
CACHE = {'dir': None, 'immutable': lambda url: False, 'notes': []}
def fetch(url, dest, tries=4):
    import hashlib
    cdir = CACHE['dir']; cpath = os.path.join(cdir, hashlib.sha1(url.encode()).hexdigest()[:16] + '-' + os.path.basename(dest)) if cdir else None
    if cpath and os.path.exists(cpath) and CACHE['immutable'](url) and time.time() - os.path.getmtime(cpath) < 7 * 86400:
        shutil.copy(cpath, dest); return True, ''
    err = ''
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=120) as r, open(dest + '.part', 'wb') as f: shutil.copyfileobj(r, f)
            os.replace(dest + '.part', dest)
            if cpath:
                try: shutil.copy(dest, cpath + '.part'); os.replace(cpath + '.part', cpath)
                except OSError: pass
            return True, ''
        except Exception as e:
            err = str(e)
            try: os.remove(dest + '.part')
            except OSError: pass
            if '404' in err: break  # not published: retrying cannot help
            # 10 Nov 2026: football-data.co.uk answered one run with "certificate has expired" (its certificate itself runs to 1 Dec 2026;
            # www. now redirects to the bare domain, so one of the two names was being served an old certificate). Try the other name
            # once, still over HTTPS with full certificate checks; certificates are never ignored and plain HTTP is never used.
            if 'CERTIFICATE_VERIFY_FAILED' in err and 'football-data.co.uk/' in url:
                alt = url.replace('://www.football-data.co.uk/', '://football-data.co.uk/') if '://www.' in url else url.replace('://football-data.co.uk/', '://www.football-data.co.uk/')
                try:
                    with urllib.request.urlopen(urllib.request.Request(alt, headers=UA), timeout=120) as r, open(dest + '.part', 'wb') as f: shutil.copyfileobj(r, f)
                    os.replace(dest + '.part', dest)
                    if cpath:
                        try: shutil.copy(dest, cpath + '.part'); os.replace(cpath + '.part', cpath)
                        except OSError: pass
                    CACHE['notes'].append(f'{os.path.basename(dest)}: certificate error on {url.split("/")[2]}; downloaded from {alt.split("/")[2]} instead (certificate checked)')
                    return True, ''
                except Exception as e2:
                    err = f'{err}; {alt.split("/")[2]}: {e2}'
                    try: os.remove(dest + '.part')
                    except OSError: pass
            if i < tries - 1: time.sleep((5, 15, 45)[min(i, 2)])
    if cpath and os.path.exists(cpath) and (CACHE['immutable'](url) or time.time() - os.path.getmtime(cpath) < 3 * 86400):
        shutil.copy(cpath, dest); age = (time.time() - os.path.getmtime(cpath)) / 3600
        CACHE['notes'].append(f'{os.path.basename(dest)}: download failed ({err}); used the cached copy from {age:.0f} h ago')
        return True, ''
    return False, err
def run(cmd, **kw):
    log('$', ' '.join(cmd))
    env = {**os.environ, 'NODE_USE_ENV_PROXY': '1', 'NODE_NO_WARNINGS': '1'}  # Node's fetch uses HTTPS_PROXY when the machine has one
    p = subprocess.run(cmd, capture_output=True, text=True, env=env, **kw)
    return p.returncode, p.stdout, p.stderr
def load(p):
    try: return json.load(open(p))
    except Exception: return None
def strip(o):
    if isinstance(o, dict): return {k: strip(v) for k, v in o.items() if k not in VOLATILE}
    if isinstance(o, list): return [strip(x) for x in o]
    return o

def seasons_now(now):
    y = now.year
    eu = f'{y % 100:02d}{(y + 1) % 100:02d}' if now.month >= 7 else f'{(y - 1) % 100:02d}{y % 100:02d}'
    prev = f'{(int(eu[:2]) - 1) % 100:02d}{eu[:2]}'
    of = f'20{eu[:2]}-{eu[2:]}'
    nfl = y if now.month >= 3 else y - 1
    return eu, prev, of, nfl

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--work', required=True); ap.add_argument('--live'); ap.add_argument('--skip-nfl', action='store_true'); ap.add_argument('--skip-nba', action='store_true')
    ap.add_argument('--skip-download', action='store_true', help='reuse files already in <work>/dl'); ap.add_argument('--nfl-first-season', type=int, default=2021)  # five years of NFL history (2021 onwards) plus the current season
    ap.add_argument('--state', help='previous status file (data-refresh-status.json); default data-src/refresh-state.json')
    ap.add_argument('--status-out', help='write the new public status file here')
    ap.add_argument('--cache', default=os.environ.get('PROPLAB_CACHE'), help='download cache kept between runs (GitHub Actions cache)')
    a = ap.parse_args()
    now = datetime.datetime.now(datetime.timezone.utc); W = os.path.abspath(a.work); os.makedirs(W, exist_ok=True)
    DL, IN, SITE, OUT = (os.path.join(W, x) for x in ('dl', 'in', 'site', 'OUT'))
    for d in (DL, IN): os.makedirs(d, exist_ok=True)
    shutil.rmtree(SITE, ignore_errors=True); shutil.rmtree(OUT, ignore_errors=True); os.makedirs(OUT)
    rep = {'started': now.isoformat(timespec='seconds'), 'sources': {}, 'errors': [], 'notes': []}
    eu, prev, of, nfl_season = seasons_now(now)
    if a.cache:
        os.makedirs(a.cache, exist_ok=True); CACHE['dir'] = a.cache; nba_cur = nba_season_now(now)
        def immutable(url):  # files of seasons that are over
            m = re.search(r'_(\d{4})\.csv', url)
            if m and ('nflverse' in url): return int(m.group(1)) < nfl_season
            if m and ('sportsdataverse' in url): return int(m.group(1)) < nba_cur
            m = re.search(r'mmz4281/(\d{4})/', url)
            return bool(m) and m.group(1) not in (eu, prev)
        CACHE['immutable'] = immutable

    # 1. live site = baseline
    LIVE = os.path.abspath(a.live) if a.live else os.path.join(W, 'live')
    if not a.live:
        shutil.rmtree(LIVE, ignore_errors=True)
        rc, o, e = run(['git', 'clone', '-q', '--depth', '1', REPO, LIVE])
        if rc: sys.exit('Cannot clone the live repository: ' + e)
    rc, commit, _ = run(['git', '-C', LIVE, 'log', '-1', '--format=%h %ci']); rep['live_commit'] = commit.strip()
    shutil.copytree(LIVE, SITE, ignore=shutil.ignore_patterns('.git'))

    # 2. downloads
    def src(name, ok, detail=''):
        rep['sources'][name] = {'ok': ok, 'detail': detail, 'at': datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')}
        if not ok: rep['errors'].append(f'{name}: download failed ({detail}); its published data was kept unchanged')
    fd_files = []
    # history bootstrap (27 Oct 2026): a league added later has no published seasons yet; each missing season from HISTORY_FIRST on is
    # downloaded once and published by this run (afterwards the live files exist and only the current + previous season are refreshed)
    hist = []
    for div, lg in FD_DIVS.items():
        for y in range(HISTORY_FIRST, int('20' + prev[:2])):
            if not os.path.exists(os.path.join(LIVE, f'data-team-matches-{lg}-{y}.json')): hist.append((f'{y % 100:02d}{(y + 1) % 100:02d}', div))
    for code, div in hist:
        dest = os.path.join(DL, f'{div}-{code}.csv'); ok, err = (True, '') if a.skip_download and os.path.exists(dest) else fetch(f'https://www.football-data.co.uk/mmz4281/{code}/{div}.csv', dest)
        src(f'football-data {div} {code} (history, first publication)', ok, err)
        if ok: fd_files.append(dest)
    for fx_code, (cl, lg) in FD_EXTRA.items():  # whole file each time (small); the builder keeps 2021 onwards
        dest = os.path.join(DL, f'{fx_code}.csv'); ok, err = (True, '') if a.skip_download and os.path.exists(dest) else fetch(f'https://www.football-data.co.uk/new/{fx_code}.csv', dest)
        src(f'football-data {fx_code}.csv ({LEAGUE_NAMES[lg]}, final scores)', ok, err)
        if ok: fd_files.append(dest)
    dest = os.path.join(DL, 'new_league_fixtures.csv'); ok, err = (True, '') if a.skip_download and os.path.exists(dest) else fetch('https://www.football-data.co.uk/new_league_fixtures.csv', dest)
    src('football-data new_league_fixtures.csv', ok, err)
    if ok:
        rc, o, e = run(['node', os.path.join(PACK, 'owner-tools/fd-fixtures.mjs'), dest, os.path.join(IN, 'fixtures-fd-extra-nextround.txt')] + [f'{cl}={lg}' for cl, lg in FD_EXTRA.values()])
        if rc: rep['errors'].append('fd-fixtures (extra leagues): ' + e.strip()[:300])
    for code in (eu, prev):
        for div in FD_DIVS:
            dest = os.path.join(DL, f'{div}-{code}.csv'); ok, err = (True, '') if a.skip_download and os.path.exists(dest) else fetch(f'https://www.football-data.co.uk/mmz4281/{code}/{div}.csv', dest)
            src(f'football-data {div} {code}', ok, err)
            if ok: fd_files.append(dest)
    dest = os.path.join(DL, 'fixtures.csv'); ok, err = (True, '') if a.skip_download and os.path.exists(dest) else fetch('https://www.football-data.co.uk/fixtures.csv', dest)
    src('football-data fixtures.csv', ok, err)
    if ok:
        rc, o, e = run(['node', os.path.join(PACK, 'owner-tools/fd-fixtures.mjs'), dest, os.path.join(IN, 'fixtures-fd-nextround.txt')] + [f'{k}={v}' for k, v in FD_DIVS.items()])
        if rc: rep['errors'].append('fd-fixtures: ' + e.strip()[:300])
    def openfootball_txt(lg, tz, of):  # 4 Nov 2026: kick-off times from openfootball Football.TXT (see OPENFOOTBALL_TXT)
        path = OPENFOOTBALL_TXT[lg].format(of=of); tdest = os.path.join(DL, f'{lg}-{of}-openfootball.txt'); jdest = tdest[:-4] + '.json'
        tok, terr = (True, '') if a.skip_download and os.path.exists(tdest) else fetch(f'https://raw.githubusercontent.com/openfootball/{path}', tdest)
        if not tok and '404' in terr: rep['notes'].append(f'openfootball text {path}: not published'); return
        src(f'openfootball text {path}', tok, terr)
        if not tok: return
        rc0, o0, e0 = run(['node', os.path.join(PACK, 'owner-tools/openfootball-txt.mjs'), tdest, jdest])
        if rc0: rep['errors'].append(f'openfootball text {lg}: {e0.strip()[:300]}'); return
        rep['notes'].append(f'openfootball text {LEAGUE_NAMES[lg]}: {o0.strip()}')
        rc1, o1, e1 = run(['node', os.path.join(PACK, 'owner-tools/openfootball-fixtures.mjs'), lg, tz, jdest, os.path.join(IN, f'kotimes-{lg}-openfootball.txt'), f'openfootball {path.split("/")[-1]} (CC0)'])
        if rc1: rep['errors'].append(f'openfootball text {lg}: {e1.strip()[:300]}'); return
        # 9 Nov 2026: rounds with one date and no times become PROVISIONAL fixtures (fixtures-*-provisional.txt adds them; the site labels
        # them "Date provisional" and build-data drops each as soon as a confirmed fixture or a result for the pairing appears). Timed
        # matches stay kick-off times only (kotimes-*), as before.
        kp = os.path.join(IN, f'kotimes-{lg}-openfootball.txt'); lines = open(kp, encoding='utf-8').read().splitlines()
        prov = [l for l in lines[1:] if 'provisional date' in l]
        if prov:
            with open(os.path.join(IN, f'fixtures-{lg}-provisional.txt'), 'w', encoding='utf-8') as fh: fh.write('\n'.join([lines[0]] + prov) + '\n')
            with open(kp, 'w', encoding='utf-8') as fh: fh.write('\n'.join([lines[0]] + [l for l in lines[1:] if 'provisional date' not in l]) + '\n')
            rep['notes'].append(f'{LEAGUE_NAMES[lg]}: {len(prov)} provisional fixtures (round date only, no kick-off times)')
    for lg, (code, tz) in list(OPENFOOTBALL.items()) + list(OPENFOOTBALL_OPTIONAL.items()):
        dest = os.path.join(DL, f'{code}.json'); ok, err = (True, '') if a.skip_download and os.path.exists(dest) else fetch(f'https://raw.githubusercontent.com/openfootball/football.json/master/{of}/{code}.json', dest)
        if lg in OPENFOOTBALL_OPTIONAL and not ok and '404' in err:
            rep['notes'].append(f'openfootball {code} {of}: not published yet ({LEAGUE_NAMES[lg]} fixtures come from football-data fixtures.csv, about one week ahead)')
            if lg in OPENFOOTBALL_TXT: openfootball_txt(lg, tz, of)
            continue
        src(f'openfootball {code} {of}', ok, err)
        if not ok: continue
        rc1, _, e1 = run(['node', os.path.join(PACK, 'owner-tools/openfootball-fixtures.mjs'), lg, tz, dest, os.path.join(IN, f'fixtures-{lg}-openfootball.txt')])
        rc2, _, e2 = run(['node', os.path.join(PACK, 'owner-tools/openfootball-rounds.mjs'), lg, tz, dest, os.path.join(IN, f'rounds-{lg}-openfootball.txt')])
        if rc1 or rc2: rep['errors'].append(f'openfootball {lg}: {(e1 + e2).strip()[:300]}')
    # 2b. final scores from Wikipedia season articles (football-data.co.uk usually publishes results 1-3 days late), plus Scotland's
    #     future fixture dates (date only). Score-only records; football-data.co.uk statistics are added when it publishes.
    wrep = os.path.join(OUT, 'wikipedia-results.json')
    rc, o, e = run([sys.executable, os.path.join(PACK, 'owner-tools/wiki_results.py'), SITE, DL, IN, now.isoformat(), wrep])
    wj = load(wrep) or {}
    werr = [f"{lg}: {L['error']}" for lg, L in (wj.get('leagues') or {}).items() if L.get('error')]
    src('Wikipedia season results tables', rc == 0 and not werr, (e.strip()[-300:] if rc else '; '.join(werr))[:300])
    rep['wikipedia'] = {lg: {'added': len(L.get('added', [])), 'agree': L.get('agree', 0), 'disagree': L.get('disagree', []), 'skipped': len(L.get('skipped', [])),
                             'fixtures': L.get('fixtures_added', 0), 'updated': (L.get('updated') or [''])[0], 'error': L.get('error')} for lg, L in (wj.get('leagues') or {}).items()}
    # 2c. UEFA Champions League, Europa League and Conference League: this season's fixtures (kick-off as a UTC instant), league-phase
    #     matchdays, final scores and goal events from Wikipedia's season articles. Earlier seasons are already published and are kept as
    #     they are. A failed download writes nothing new for that competition: its published fixtures and results stay. Statistics other
    #     than goals are not available from this source.
    ucl_season = now.year if now.month >= 7 else now.year - 1
    rep['europe'] = {}
    for comp in ('ucl', 'uel', 'uecl'):
        cname = {'ucl': 'Champions League', 'uel': 'Europa League', 'uecl': 'Conference League'}[comp]
        urep = os.path.join(IN, f'{comp}-report.json')
        rc, o, e = run([sys.executable, '-I', os.path.join(PACK, 'owner-tools/ucl_wiki.py'), IN, '--comp', comp, '--cache', os.path.join(DL, comp), '--seasons', f'{ucl_season}-{ucl_season}'])
        uj = load(urep) or {}
        ust = (uj.get('seasons') or {}).get(str(ucl_season)) or {}
        umiss = [p for p in uj.get('missing_pages', []) if 'league_phase' in p or 'group_stage' in p]
        src(f'Wikipedia UEFA {cname} season articles', rc == 0 and bool(ust.get('boxes')) and not umiss, (e.strip()[-300:] if rc else ('missing: ' + ', '.join(umiss) if umiss else ('' if ust.get('boxes') else 'no matches found')))[:300])
        rep['europe'][comp] = {'name': cname, 'season': ucl_season, 'matches_listed': ust.get('boxes', 0), 'completed': ust.get('completed', 0), 'with_half_time': ust.get('with_half_time', 0), 'skipped': uj.get('skipped', [])[:20]}
        if rc != 0 or not ust.get('boxes'):  # never let an empty or failed run prune the published schedule of this competition
            for f in (f'fixtures-{comp}-wikipedia.txt', f'rounds-{comp}.txt', f'events-{comp}-{ucl_season}.json'):
                try: os.remove(os.path.join(IN, f))
                except FileNotFoundError: pass
    rep['ucl'] = rep['europe']['ucl']  # kept for older readers of the report
    # 2d. current squads (27 Oct 2026): every Premier League and MLS club's first-team squad list from its Wikipedia article, with the
    #     list's own date; a club that cannot be read keeps its previous list (owner-tools/squads_wiki.py). Changes are logged publicly.
    srep = os.path.join(OUT, 'squads-report.json')
    # 5 Nov 2026: the site refreshes six times a day; squad lists (about 50 Wikipedia pages) are read at most every 10 hours, to stay light
    # on Wikipedia. When not due, nothing is read or written and the source keeps its previous date (it is never marked as checked).
    SQN = 'Wikipedia club squad lists (Premier League, MLS)'
    _old = (load(a.state or os.path.join(PACK, 'data-src/refresh-state.json')) or {}).get('sources', {}).get(SQN) or {}
    _ls = _old.get('last_success'); _age = (now - datetime.datetime.fromisoformat(_ls.replace('Z', '+00:00'))).total_seconds() / 3600 if _ls else 99
    squads_due = _age >= 10 or os.environ.get('PROPLAB_SQUADS') == 'always'
    if not squads_due:
        rep['notes'].append(f'squad lists not read this run (last read {_age:.1f} hours ago; read at most every 10 hours)'); rep.setdefault('sources_carried', {})[SQN] = _old
    rc, o, e = (0, '', '') if not squads_due else run([sys.executable, '-I', os.path.join(PACK, 'owner-tools/squads_wiki.py'), LIVE, IN, SITE, now.isoformat(), srep, '--leagues', 'epl,mls', '--map', os.path.join(PACK, 'data-src/squads/articles.json')])
    sj = (load(srep) or {}) if squads_due else {}
    if squads_due: src(SQN, rc == 0 and bool(sj.get('leagues')), (e.strip()[-300:] if rc else ''))
    rep['squads'] = {lg: {'clubs': L.get('clubs'), 'refreshed': L.get('refreshed'), 'kept_previous': L.get('kept_previous', []), 'undated': L.get('undated', []), 'players': L.get('players')} for lg, L in (sj.get('leagues') or {}).items()}
    rep['squads_changes'] = sj.get('changes', 0); rep['squads_baseline'] = sj.get('baseline_leagues', [])
    if rc != 0:  # never let a failed run publish a partial squad file
        for f in ('epl-squads-wikipedia.txt', 'mls-squads-wikipedia.txt'):
            try: os.remove(os.path.join(IN, f))
            except FileNotFoundError: pass
    mls_season = str(now.year)
    asa_dir = os.path.join(DL, 'asa'); os.makedirs(asa_dir, exist_ok=True)
    if not (a.skip_download and os.path.exists(os.path.join(asa_dir, f'results-mls-{mls_season}.txt'))):
        rc, o, e = run(['node', os.path.join(PACK, 'owner-tools/asa-import.mjs'), asa_dir, '--seasons', mls_season, '--players-season', mls_season])
        src(f'American Soccer Analysis MLS {mls_season}', rc == 0, e.strip()[-300:] if rc else '')
    else: src(f'American Soccer Analysis MLS {mls_season}', True, 'reused')
    nfl_dir = os.path.join(DL, 'nfl'); os.makedirs(nfl_dir, exist_ok=True); nfl_ok = not a.skip_nfl
    if not a.skip_nfl:
        want = [('schedules', 'games.csv', 'games.csv')]
        for s in range(a.nfl_first_season, nfl_season + 1):
            want += [('stats_player', f'stats_player_week_{s}.csv', f'stats_player_week_{s}.csv'), ('pbp', f'play_by_play_{s}.csv.gz', f'play_by_play_{s}.csv.gz'),
                     ('weekly_rosters', f'roster_weekly_{s}.csv', f'roster_weekly_{s}.csv')]
        want += [('injuries', f'injuries_{nfl_season}.csv', f'injuries_{nfl_season}.csv')]  # official injury-report status (model availability)
        want += [('trades', 'trades.csv', 'trades.csv'), ('players', 'players.csv', 'players.csv')]  # 27 Oct: dated trades for club-change dividers
        for tag, name, local in want:
            dest = os.path.join(nfl_dir, local); ok, err = (True, '') if a.skip_download and os.path.exists(dest) else fetch(f'{NFLV}/{tag}/{name}', dest)
            src(f'nflverse {name}', ok, err); nfl_ok = nfl_ok and ok
        # snap counts (21 Oct: NFL participation for the minimum-snaps filter): optional, a failure only leaves snaps missing
        for s_ in range(a.nfl_first_season, nfl_season + 1):
            dest = os.path.join(nfl_dir, f'snap_counts_{s_}.csv'); ok, err = (True, '') if a.skip_download and os.path.exists(dest) else fetch(f'{NFLV}/snap_counts/snap_counts_{s_}.csv', dest)
            src(f'nflverse snap_counts_{s_}.csv', ok, err)
            if not ok and os.path.exists(dest): os.remove(dest)

    # 3. build football
    inputs = sorted(os.path.join(asa_dir, f) for f in os.listdir(asa_dir) if f.endswith(('.txt', '.json')))
    inputs += fd_files
    inputs += sorted(os.path.join(IN, f) for f in os.listdir(IN) if f.startswith('results-') and f.endswith('-wikipedia.txt'))  # after football-data: score-only, never replaces a published record
    inputs += sorted(os.path.join(PACK, 'data-src/events', f) for f in os.listdir(os.path.join(PACK, 'data-src/events')) if f.endswith('.json'))
    inputs += sorted(os.path.join(IN, f) for f in os.listdir(IN) if f.startswith(('events-ucl-', 'events-uel-', 'events-uecl-')) and f.endswith('.json'))  # European results + goal events
    inputs += [os.path.join(PACK, 'data-src/mls/fixtures-mls-upcoming.txt')]
    inputs += sorted(os.path.join(IN, f) for f in os.listdir(IN) if f.startswith(('fixtures-', 'rounds-', 'kotimes-')))
    inputs += sorted(os.path.join(IN, f) for f in os.listdir(IN) if f.startswith('fixture-status-'))  # after the fixtures they refer to
    inputs += sorted(os.path.join(IN, f) for f in os.listdir(IN) if f.endswith('-squads-wikipedia.txt'))  # current squads (directory)
    inputs += [os.path.join(PACK, 'data-src/player-links.json'), os.path.join(PACK, 'data-src/photos.json'), os.path.join(PACK, 'owner-tools/sources.json')]
    rc, o, e = run(['node', os.path.join(PACK, 'owner-tools/build-data.mjs'), SITE] + inputs)
    open(os.path.join(OUT, 'build-football.log'), 'w').write(o + '\n' + e)
    rep['builder_problems'] = [l for l in e.splitlines() if l.startswith('ERROR')]
    rep['builder_notes'] = [l for l in e.splitlines() if l.startswith('note') and ('removed' in l or 'not found' in l)]
    if rc not in (0, 1): rep['errors'].append(f'build-data.mjs failed (exit {rc}): {e.strip()[-400:]}')
    # 3b. build NFL
    if not a.skip_nfl and nfl_ok:
        rc, o, e = run([sys.executable, os.path.join(PACK, 'owner-tools/nfl-build.py'), nfl_dir, SITE] + [str(s) for s in range(a.nfl_first_season, nfl_season + 1)])
        open(os.path.join(OUT, 'build-nfl.log'), 'w').write(o + '\n' + e)
        if rc: rep['errors'].append(f'nfl-build.py failed (exit {rc}): {(o + e).strip()[-400:]}'); shutil.copy(os.path.join(LIVE, 'data-nfl-meta.json'), SITE)
        else:  # Milestone 5: Player Prominence ("Popular Players Only" and the Prominence sort), recomputed from the new game logs
            rc2, o2, e2 = run([sys.executable, '-I', os.path.join(PACK, 'owner-tools/nfl_prominence.py'), SITE])
            if rc2: rep['errors'].append(f'nfl_prominence.py failed (exit {rc2}): {(o2 + e2).strip()[-300:]}; players have no prominence today, so the site shows every player (Popular Players Only says it is unavailable)')
            # official NFL injury reports (nflverse injuries file, downloaded above): latest report per team, statuses exactly as published
            rc4, o4, e4 = run([sys.executable, '-I', os.path.join(PACK, 'owner-tools/nfl_trades.py'), os.path.join(nfl_dir, 'trades.csv'), os.path.join(nfl_dir, 'players.csv'), SITE])
            if rc4: rep['errors'].append(f'nfl_trades.py failed (exit {rc4}): {(o4 + e4).strip()[-300:]}; dividers fall back to "first game" dates')
            else: rep['notes'].append('NFL trades: ' + o4.strip()[-200:])
            rc3, o3, e3 = run([sys.executable, '-I', os.path.join(PACK, 'owner-tools/nfl_injuries.py'), nfl_dir, SITE, rep['sources'].get(f'nflverse injuries_{nfl_season}.csv', {}).get('at') or now.isoformat(timespec='seconds')])
            if rc3: rep['errors'].append(f'nfl_injuries.py failed (exit {rc3}): {(o3 + e3).strip()[-300:]}; the previous injury file was kept')
            else: rep['notes'].append('NFL injury reports: ' + o3.strip()[-200:])
    elif not a.skip_nfl: rep['errors'].append('NFL: not rebuilt because a download failed; published NFL data kept')
    # 3c. experimental NFL model: predictions for the coming games + the append-only forward-test log (owner-tools/nfl_model.py)
    params = os.path.join(PACK, 'owner-tools', 'model-params.json')
    if not a.skip_nfl and nfl_ok and os.path.exists(params):
        rc, o, e = run([sys.executable, os.path.join(PACK, 'owner-tools/nfl_model.py'), 'predict', '--nfl', nfl_dir, '--params', params, '--site', SITE])
        open(os.path.join(OUT, 'nfl-model.log'), 'w').write(o + '\n' + e)
        if rc:
            rep['errors'].append(f'NFL model predictions failed (exit {rc}); the published model files were kept: {(o + e).strip()[-300:]}')
            for f in os.listdir(LIVE):
                if f.startswith(('data-nfl-model', 'data-nfl-forward-')): shutil.copy(os.path.join(LIVE, f), SITE)
        else: rep['notes'].append('NFL model: ' + o.strip().splitlines()[-1] if o.strip() else 'NFL model: ran')
    # 3d. NBA (21 Oct): sportsdataverse / hoopR releases (CC BY 4.0) + the Official NBA Injury Report. Any failure keeps the published NBA data.
    if not a.skip_nba: nba_refresh(a, rep, src, DL, SITE, LIVE, OUT, now)
    # any NFL file the build did not manage to write correctly is restored from the live copy
    # 4. validate
    rc, o, e = run([sys.executable, os.path.join(PACK, 'owner-tools/validate.py'), SITE, LIVE] + ([nfl_dir] if (not a.skip_nfl and nfl_ok) else []))
    open(os.path.join(OUT, 'validation.log'), 'w').write(o + e)
    val = load(os.path.join(SITE, '.validation.json')) or {'failures': ['validator did not run: ' + e[-300:]], 'checks': 0}
    fc, ff = check_model_files(SITE, LIVE, now); val['checks'] = val.get('checks', 0) + fc; val['failures'] = list(val.get('failures', [])) + ff
    os.remove(os.path.join(SITE, '.validation.json')) if os.path.exists(os.path.join(SITE, '.validation.json')) else None
    rep['validation'] = val

    # 4b. completeness audit (owner request 20 Oct 2026): structure of every competition / season, and this season's results reconciled with
    #     openfootball (independent, CC0). Gaps never block the refresh (the data is still the best available) but are flagged in the report
    #     and the public status ("ok-with-gaps") instead of a silent success.
    ofd = os.path.join(DL, 'ofaudit'); os.makedirs(ofd, exist_ok=True)
    for lg, (code, tz) in list(OPENFOOTBALL.items()) + list(OPENFOOTBALL_OPTIONAL.items()):
        src_f = os.path.join(DL, f'{code}.json')
        if os.path.exists(src_f): shutil.copy(src_f, os.path.join(ofd, f'{of}-{code}.json'))
    rc, o, e = run(['node', os.path.join(PACK, 'owner-tools/audit_completeness.mjs'), SITE, ofd, os.path.join(OUT, 'completeness')])
    aud = load(os.path.join(OUT, 'completeness', 'completeness-report.json')) or {}
    missing = [x for x in aud.get('unresolved', [])]
    unmatched = sorted({n for c in aud.get('competitions', []) for n in (c.get('reconciliation') or {}).get('unmatched_team_names', []) if n not in {y['openfootball'] for y in (c.get('reconciliation') or {}).get('names_linked_by_fixture', [])}})
    sdiff = [dict(competition=c['competition'], season=c['season'], **d) for c in aud.get('competitions', []) for d in (c.get('reconciliation') or {}).get('score_differences', [])]
    gaps = [w for w in rep['validation'].get('warnings', []) if w.startswith(('COMPLETENESS', 'TEAM NAMES'))]
    rep['completeness'] = {'ran': rc == 0, 'missing_vs_openfootball': missing[:50], 'score_differences_vs_openfootball': sdiff[:20], 'unmatched_names': unmatched[:30], 'structure_warnings': gaps}
    if rc != 0: rep['errors'].append('completeness audit did not run: ' + (e or o).strip()[-200:])

    # 5. compare with live
    changed = []
    for f in sorted(os.listdir(SITE)):
        if not f.startswith('data-') or not f.endswith('.json') or f in ('data-manifest.json', 'data-refresh-status.json'): continue
        new, old = load(os.path.join(SITE, f)), load(os.path.join(LIVE, f))
        if old is None or strip(new) != strip(old): changed.append(f)
        else: shutil.copy(os.path.join(LIVE, f), os.path.join(SITE, f))  # unchanged data keeps its published bytes
    # 2 Nov 2026 (audit): the copy-back above restores the LIVE bytes of unchanged files, but the manifest had been stamped with the
    # rebuilt bytes' hash, so its version keys drifted from the files actually published (directory, photos, some team-match files):
    # browsers then keep serving a cached old copy. Re-stamp every manifest version from the final bytes, then decide whether the
    # manifest itself changed.
    mp = os.path.join(SITE, 'data-manifest.json'); man = load(mp)
    if man:
        import hashlib
        for e in [man.get(k) for k in ('fixtures', 'news', 'directory', 'player_index', 'photos')] + list(man.get('team_matches', [])) + list(man.get('player_matches', [])):
            if e and e.get('file') and os.path.exists(os.path.join(SITE, e['file'])): e['v'] = hashlib.sha256(open(os.path.join(SITE, e['file']), 'rb').read()).hexdigest()[:12]
        json.dump(man, open(mp, 'w'), ensure_ascii=False, separators=(',', ':'))
    if changed or strip(load(mp)) != strip(load(os.path.join(LIVE, 'data-manifest.json'))): changed.append('data-manifest.json')
    else: shutil.copy(os.path.join(LIVE, 'data-manifest.json'), mp)
    rep['changed_files'] = changed

    # 6. metrics
    rep['metrics'] = metrics(SITE, LIVE, now)
    rep['metrics']['season_gaps'] = season_gaps(SITE, DL, now)
    rep['notes'] = CACHE['notes'] + rep['notes']  # downloads that fell back to a cached copy
    rep['finished'] = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
    ok = not val['failures']
    if ok and changed:
        up = os.path.join(OUT, 'UPLOAD-TO-GITHUB'); os.makedirs(up)
        for f in changed: shutil.copy(os.path.join(SITE, f), up)
    state_old = load(a.state or os.path.join(PACK, 'data-src/refresh-state.json')) or {}
    prev_src = state_old.get('last_successful') or {k: v.get('last_success') for k, v in (state_old.get('sources') or {}).items() if v.get('last_success')}
    state = {'last_run': rep['finished'], 'last_successful': dict(prev_src)}
    for k, v in rep['sources'].items():
        if v['ok'] and ok: state['last_successful'][k] = v['at']
    json.dump(state, open(os.path.join(OUT, 'refresh-state.json'), 'w'), indent=1)
    rep['schedule_uk'] = workflow_schedule(LIVE)
    status = public_status(rep, ok, state, state_old, SITE, now)
    json.dump(status, open(os.path.join(OUT, 'data-refresh-status.json'), 'w'), indent=1, ensure_ascii=False)
    if a.status_out: shutil.copy(os.path.join(OUT, 'data-refresh-status.json'), a.status_out)
    rep['warnings'] = status['warnings']
    json.dump(rep, open(os.path.join(OUT, 'refresh-report.json'), 'w'), indent=1, default=str)
    open(os.path.join(OUT, 'REFRESH-REPORT.md'), 'w').write(report_md(rep, ok, state))
    log(open(os.path.join(OUT, 'REFRESH-REPORT.md')).read())
    sys.exit(0 if ok else 3)

SDV = 'https://github.com/sportsdataverse/sportsdataverse-data/releases/download'
def nba_season_now(now):
    """hoopR season number of the current / coming NBA season (2027 = 2026/27; a new season from August)."""
    return now.year + 1 if now.month >= 8 else now.year
def nba_refresh(a, rep, src, DL, SITE, LIVE, OUT, now):
    d = os.path.join(DL, 'nba'); os.makedirs(d, exist_ok=True); cur = nba_season_now(now); first = cur - 6
    ok_all = True
    for S in range(first, cur + 1):
        for tag, name, need in (('espn_nba_schedules', f'nba_schedule_{S}.csv', True), ('espn_nba_team_boxscores', f'team_box_{S}.csv', S < cur), ('espn_nba_player_boxscores', f'player_box_{S}.csv', S < cur)):
            dest = os.path.join(d, name); ok, err = (True, '') if a.skip_download and os.path.exists(dest) else fetch(f'{SDV}/{tag}/{name}', dest)
            if not ok and os.path.exists(dest): os.remove(dest)
            src(f'sportsdataverse {name}', ok or not need, err if ok or need else 'not published yet (season not started in the source)')
            ok_all = ok_all and (ok or not need)
    dest = os.path.join(d, f'rosters_{cur}.csv'); ok, err = (True, '') if a.skip_download and os.path.exists(dest) else fetch(f'{SDV}/espn_nba_rosters/rosters_{cur}.csv', dest); src(f'sportsdataverse rosters_{cur}.csv', ok, err)
    # quarter points: completed seasons come with the tools (data-src/nba/pbp_<S>.json, built once from the same play-by-play); the current
    # season is streamed from its play-by-play CSV every night (nothing kept but the totals)
    for S in range(first, cur):
        f = os.path.join(PACK, 'data-src', 'nba', f'pbp_{S}.json')
        if os.path.exists(f): shutil.copy(f, d)
    if not (a.skip_download and os.path.exists(os.path.join(d, f'pbp_{cur}.json'))):
        rc, o, e = run([sys.executable, '-I', os.path.join(PACK, 'owner-tools/nba_pbp.py'), f'{SDV}/espn_nba_pbp/play_by_play_{cur}.csv', os.path.join(d, f'pbp_{cur}.json')])
        nf = rc != 0 and '404' in (e or o)  # the current season's play-by-play appears once its first games are published
        src(f'sportsdataverse play_by_play_{cur}.csv', rc == 0 or nf, 'not published yet (no quarter points for this season until it is)' if nf else (e or o).strip()[-200:] if rc else '')
    if not ok_all: rep['errors'].append('NBA: not rebuilt because a download failed; published NBA data kept'); return
    # Update 67 (11 Nov 2026): games the source has not published as final yet are filled from ESPN's game summaries (same publisher and
    # ids; checked to match the source exactly on 10 Nov: 6 games, 154 player lines, 0 differences). See nba_espn_patch.py.
    if not a.skip_download:
        rc, o, e = run([sys.executable, '-I', os.path.join(PACK, 'owner-tools/nba_espn_patch.py'), d, str(cur), '--now', now.isoformat()])
        try: P = json.loads((o or '').strip().splitlines()[-1])
        except Exception: P = None
        if P is None: src('ESPN NBA results top-up', False, (e or o).strip()[-200:])
        else:
            src('ESPN NBA results top-up', not P['errors'] or bool(P['filled']), '; '.join(P['errors'])[:300])
            if P['filled']: rep['notes'].append(f"NBA: {len(P['filled'])} finished game(s) not yet in the source were filled from ESPN: " + ', '.join(f"{x['match']} ({x['date']})" for x in P['filled'])[:400])
    rc, o, e = run([sys.executable, '-I', os.path.join(PACK, 'owner-tools/nba-build.py'), d, SITE])
    open(os.path.join(OUT, 'build-nba.log'), 'w').write(o + '\n' + e)
    if rc:
        rep['errors'].append(f'nba-build.py failed (exit {rc}): {(o + e).strip()[-300:]}; published NBA data kept')
        for f in os.listdir(LIVE):
            if f.startswith('data-nba-'): shutil.copy(os.path.join(LIVE, f), SITE)
        return
    rep['notes'].append('NBA: ' + o.strip().splitlines()[-1][:300])
    rc, o, e = run([sys.executable, '-I', os.path.join(PACK, 'owner-tools/nba_injuries.py'), SITE])
    if rc:
        rep['errors'].append(f'NBA injury report: {(o + e).strip()[-200:]}; the previous injury file was kept')
        if os.path.exists(os.path.join(LIVE, 'data-nba-injuries.json')): shutil.copy(os.path.join(LIVE, 'data-nba-injuries.json'), SITE)
    else: rep['notes'].append('NBA injuries: ' + o.strip()[-200:])
    src('Official NBA Injury Report', rc == 0, (o + e).strip()[-200:] if rc else '')
    # 29 Oct: team matchup tables (defence / offence / by position, ranks 1-30) from the files just built. A failure keeps the published table.
    rc, o, e = run(['node', os.path.join(PACK, 'owner-tools/nba-matchups.mjs'), SITE])
    if rc:
        msg = next((l.strip() for l in (e + o).splitlines() if 'Error' in l), (o + e).strip()[-200:])[:200]
        rep['errors'].append(f'NBA matchups: {msg}; the previous matchup table was kept')
        if os.path.exists(os.path.join(LIVE, 'data-nba-matchups.json')): shutil.copy(os.path.join(LIVE, 'data-nba-matchups.json'), SITE)
    else: rep['notes'].append(o.strip()[-300:])
    rc, o, e = run([sys.executable, '-I', os.path.join(PACK, 'owner-tools/nba_audit.py'), SITE, os.path.join(OUT, 'nba-completeness'), '--raw', d, '--no-wiki', '--seasons', ','.join(str(s) for s in range(first, cur))])
    au = load(os.path.join(OUT, 'nba-completeness', 'nba-completeness.json')) or {}
    rep['nba_completeness'] = au.get('summary', {'ran': False})

def check_model_files(site, live, now):
    """Forward-test integrity: a saved prediction is never edited or removed, and is never added after its kick-off; outcomes appear only
    for final games. Predictions must be valid probabilities for games that have not started. Returns (checks, failures)."""
    fails = []; checks = 0
    fin = {g['id'] for g in (load(os.path.join(site, 'data-nfl-games.json')) or {'items': []})['items'] if g.get('final')}
    for f in sorted(os.listdir(live)):
        if not (f.startswith('data-nfl-forward-2') and f.endswith('.json')): continue
        old, new = load(os.path.join(live, f)) or {'entries': []}, load(os.path.join(site, f)) or {'entries': []}
        nb = {e['id']: e for e in new['entries']}
        for e in old['entries']:
            n = nb.get(e['id'])
            if not n: fails.append(f'{f}: saved prediction {e["id"]} was removed'); continue
            if {k: v for k, v in n.items() if k != 'outcome'} != {k: v for k, v in e.items() if k != 'outcome'}: fails.append(f'{f}: saved prediction {e["id"]} was changed')
            if e.get('outcome') and n.get('outcome') != e['outcome'] and not any(a['id'] == e['id'] for a in new.get('audit', [])): fails.append(f'{f}: outcome of {e["id"]} changed without an audit entry')
        checks += 1
    for f in sorted(os.listdir(site)):
        if not (f.startswith('data-nfl-forward-2') and f.endswith('.json')): continue
        d = load(os.path.join(site, f)) or {'entries': []}; olds = {e['id'] for e in (load(os.path.join(live, f)) or {'entries': []})['entries']}
        for e in d['entries']:
            if e['id'] not in olds and datetime.datetime.fromisoformat(e['created']) >= datetime.datetime.fromisoformat(e['kickoff']): fails.append(f'{f}: {e["id"]} saved after kick-off')
            if e.get('outcome') and e['game_id'] not in fin: fails.append(f'{f}: {e["id"]} graded before the game was final')
            if not (0 <= e['p_over'] <= 1): fails.append(f'{f}: {e["id"]} probability out of range')
        checks += 1
    m = load(os.path.join(site, 'data-nfl-model.json'))
    if m:
        bad = [p['id'] for p in m['predictions'] if p.get('p_over_ref') is not None and not (0 <= p['p_over_ref'] <= 1)]
        if bad: fails.append(f'data-nfl-model.json: {len(bad)} probabilities out of range')
        checks += 1
    return checks, fails[:20]

def tm_index(site):
    man = load(os.path.join(site, 'data-manifest.json')) or {}; out = {}
    for e in man.get('team_matches', []):
        d = load(os.path.join(site, e['file'])) or {'items': []}
        for r in d['items']: out[(e['league'], e['season'], r['date'], r['home'], r['away'])] = r
    return out

def metrics(site, live, now):
    m = {}
    new, old = tm_index(site), tm_index(live)
    added = [k for k in new if k not in old]; removed = [k for k in old if k not in new]
    score_fix = [k for k in new if k in old and (new[k].get('hg'), new[k].get('ag')) != (old[k].get('hg'), old[k].get('ag'))]
    stat_upd = [k for k in new if k in old and k not in score_fix and strip(new[k]) != strip(old[k])]
    m['football_new_results'] = Counter(k[0] for k in added); m['football_results_corrected'] = len(score_fix); m['football_records_updated'] = len(stat_upd)
    m['football_removed'] = len(removed); m['football_new_list'] = sorted(f'{k[0]} {k[2]} {k[3]} v {k[4]}' for k in added)[:200]
    latest = defaultdict(str)
    for k in new: latest[k[0]] = max(latest[k[0]], k[2])
    m['latest_result'] = dict(latest)
    # player rows (MLS)
    def pm(site):
        man = load(os.path.join(site, 'data-manifest.json')) or {}; o = {}
        for e in man.get('player_matches', []):
            d = load(os.path.join(site, e['file'])) or {'matches': []}
            for x in d['matches']: o[(x['date'], x['home'], x['away'])] = x
        return o
    pn, po = pm(site), pm(live)
    m['mls_player_matches_new'] = len([k for k in pn if k not in po]); m['mls_player_matches_updated'] = len([k for k in pn if k in po and strip(pn[k]) != strip(po[k])])
    m['mls_player_rows'] = sum(len(x.get('players', [])) for x in pn.values())
    # fixtures
    fn = {(f['league'], f['home'], f['away'], f['date']): f for f in (load(os.path.join(site, 'data-fixtures.json')) or {'items': []})['items']}
    fo = {(f['league'], f['home'], f['away'], f['date']): f for f in (load(os.path.join(live, 'data-fixtures.json')) or {'items': []})['items']}
    pair = lambda d: {(k[0], k[1], k[2]): v for k, v in sorted(d.items(), key=lambda kv: kv[0][3])}
    pn_, po_ = pair(fn), pair(fo)
    m['fixtures_new'] = len([k for k in pn_ if k not in po_]); m['fixtures_dropped'] = len([k for k in po_ if k not in pn_ and po_[k]['date'] >= now.strftime('%Y-%m-%d')])
    m['fixtures_revised'] = len([k for k in pn_ if k in po_ and (pn_[k]['date'], pn_[k].get('kickoff'), pn_[k].get('ko_utc')) != (po_[k]['date'], po_[k].get('kickoff'), po_[k].get('ko_utc'))])
    up = [f for f in fn.values() if f['date'] >= now.strftime('%Y-%m-%d')]
    m['fixtures_upcoming'] = Counter(f['league'] for f in up); m['fixtures_upcoming_timed'] = Counter(f['league'] for f in up if f.get('ko_utc'))
    # played fixtures (kick-off more than 3 hours ago) from the previous schedule that still have no result
    res_dates = defaultdict(list)
    for k in new: res_dates[(k[0], k[3], k[4])].append(datetime.date.fromisoformat(k[2]))
    pend = []
    for f in fo.values():
        ko = f.get('ko_utc')
        if not ko or datetime.datetime.fromisoformat(ko.replace('Z', '+00:00')) > now - datetime.timedelta(hours=3): continue
        d = datetime.date.fromisoformat(f['date'])
        if not any(abs((x - d).days) <= 1 for x in res_dates[(f['league'], f['home'], f['away'])]): pend.append(f"{f['league']} {f['date']} {f['home']} v {f['away']}")
    m['played_without_result'] = pend
    # NFL
    gn = {g['id']: g for g in (load(os.path.join(site, 'data-nfl-games.json')) or {'items': []})['items']}
    go = {g['id']: g for g in (load(os.path.join(live, 'data-nfl-games.json')) or {'items': []})['items']}
    m['nfl_new_final'] = len([i for i, g in gn.items() if g.get('final') and not go.get(i, {}).get('final')])
    m['nfl_games_revised'] = len([i for i, g in gn.items() if i in go and (g.get('ko_utc'), g.get('date'), g.get('week')) != (go[i].get('ko_utc'), go[i].get('date'), go[i].get('week'))])
    m['nfl_score_changed'] = len([i for i, g in gn.items() if i in go and go[i].get('final') and (g.get('hs'), g.get('as')) != (go[i].get('hs'), go[i].get('as'))])
    finals = [g['date'] for g in gn.values() if g.get('final')]; m['nfl_latest_final'] = max(finals) if finals else ''
    m['nfl_played_not_final'] = [i for i, g in gn.items() if not g.get('final') and g.get('ko_utc') and datetime.datetime.fromisoformat(g['ko_utc'].replace('Z', '+00:00')) < now - datetime.timedelta(hours=5)]
    def rows(site):
        meta = load(os.path.join(site, 'data-nfl-meta.json')) or {}; return sum(f.get('rows', 0) for f in meta.get('files', []))
    m['nfl_log_rows'] = rows(site); m['nfl_log_rows_before'] = rows(live)
    return m

def season_gaps(site, dl, now):
    """Matches the openfootball season schedule says were played (kick-off over 3 hours ago) that have no result in the data yet."""
    sys.path.insert(0, os.path.join(PACK, 'owner-tools'))
    from zoneinfo import ZoneInfo
    res = defaultdict(list)
    for k in tm_index(site): res[k[0]].append(k)
    # club names differ between sources: compare with the builder's own name rules (one Node call for all names)
    names = {k[3] for ks in res.values() for k in ks} | {k[4] for ks in res.values() for k in ks}
    sched = {}
    for lg, (code, tz) in OPENFOOTBALL.items():
        p = os.path.join(dl, f'{code}.json')
        if os.path.exists(p): sched[lg] = json.load(open(p)).get('matches', []); names |= {m['team1'] for m in sched[lg]} | {m['team2'] for m in sched[lg]}
    js = f"import('{os.path.join(PACK, 'owner-tools/lib/teams.js')}').then(m=>{{let s='';process.stdin.on('data',d=>s+=d).on('end',()=>process.stdout.write(JSON.stringify(Object.fromEntries(JSON.parse(s).map(n=>[n,m.normTeam(n)])))))}})"
    out = subprocess.run(['node', '-e', js], input=json.dumps(sorted(names)), capture_output=True, text=True)
    tab = json.loads(out.stdout or '{}'); nt = lambda lg, n: tab.get(n, n)
    have = defaultdict(list)
    for lg, ks in res.items():
        for k in ks: have[(lg, nt(lg, k[3]), nt(lg, k[4]))].append(datetime.date.fromisoformat(k[2]))
    gaps = []
    for lg, (code, tz) in OPENFOOTBALL.items():
        for m in sched.get(lg, []):
            try: d = datetime.date.fromisoformat(m['date'])
            except Exception: continue
            t = datetime.datetime.combine(d, datetime.time.fromisoformat(m.get('time') or '23:59'), ZoneInfo(tz))
            if t > now - datetime.timedelta(hours=3): continue
            dates = have[(lg, nt(lg, m['team1']), nt(lg, m['team2']))]
            if not any(abs((x - d).days) <= 2 for x in dates): gaps.append(f"{lg} {m['date']} {m['team1']} v {m['team2']}")
    return gaps

def freshness(site, now):
    """Freshness and consistency checks shown on Data & sources and in the report. Problems here are warnings: they do not block a
    refresh (the data is still the best available), whereas validate.py failures do.
    4 Nov 2026 (audit): counts use the actual remaining kick-off instants (ko_utc after now; a date-only fixture counts while its UK date
    is today or later), never fixtures already played, postponed or abandoned. Each data type reports its own real date (results,
    statistics, player logs, rosters, confirmed lineups, injury reports), so a regenerated file is never taken as fresh data."""
    from zoneinfo import ZoneInfo
    W = []; uk = ZoneInfo('Europe/London'); today = now.astimezone(uk).strftime('%Y-%m-%d'); nowz = now.strftime('%Y-%m-%dT%H:%M:%SZ')
    days = lambda d: (datetime.date.fromisoformat(today) - datetime.date.fromisoformat(str(d)[:10])).days
    fx = (load(os.path.join(site, 'data-fixtures.json')) or {'items': []})['items']
    man = load(os.path.join(site, 'data-manifest.json')) or {}
    res = tm_index(site); out = {'leagues': {}, 'nfl': {}, 'lineups': {}, 'rosters': {}, 'checks': {}}
    have = defaultdict(list)
    for k in res: have[(k[0], k[3], k[4])].append(k[2])
    played = lambda f: any(abs((datetime.date.fromisoformat(x) - datetime.date.fromisoformat(f['date'])).days) <= 1 for x in have[(f['league'], f['home'], f['away'])])
    off = lambda f: f.get('status') in ('postponed', 'abandoned')
    remaining = lambda f: (f['ko_utc'] > nowz if f.get('ko_utc') else f['date'] >= today) and not played(f)
    STATS = ('hs', 'hst', 'hc', 'hy', 'hf')
    pm_through = defaultdict(str)
    for e in man.get('player_matches', []): pm_through[e['league']] = max(pm_through[e['league']], e.get('through') or '')
    cur_season = {}
    for k in res: cur_season[k[0]] = max(cur_season.get(k[0], 0), k[1])
    for lg in LEAGUE_NAMES:
        r = [(k, v) for k, v in res.items() if k[0] == lg]
        mine = [f for f in fx if f['league'] == lg]; up = [f for f in mine if not off(f) and remaining(f)]
        pp = [f for f in mine if off(f) and (f.get('ko_utc') or f['date'])[:10] >= today]
        latest = max((k[2] for k, _ in r), default=None); horizon = max((f['date'] for f in up), default=None)
        stats_latest = max((k[2] for k, v in r if any(v.get(x) is not None for x in STATS)), default=None)
        cs = [v for k, v in r if k[1] == cur_season.get(lg)]
        cov = {x: (round(100 * sum(1 for v in cs if v.get(x) is not None) / len(cs)) if cs else None) for x in ('hs', 'hc', 'hy', 'hf')}
        names = {'hs': 'shots', 'hc': 'corners', 'hy': 'cards', 'hf': 'fouls'}
        unsupported = [names[x] for x, c in cov.items() if c is not None and c < 50] + ([] if pm_through.get(lg) else ['player props'])
        srcs = Counter(re.sub(r'\s*\(.*$', '', (f.get('source') or 'unknown'))[:60] for f in up)
        out['leagues'][lg] = {'name': LEAGUE_NAMES[lg], 'latest_result': latest, 'latest_team_stats': stats_latest, 'latest_player_stats': pm_through.get(lg) or None,
                              'upcoming_fixtures': len(up), 'with_kickoff_time': len([f for f in up if f.get('ko_utc')]), 'date_only': len([f for f in up if not f.get('ko_utc')]),
                              'postponed_or_abandoned': len(pp), 'fixtures_until': horizon, 'fixture_sources': dict(srcs),
                              'current_season_stat_coverage_pct': cov, 'markets_without_data': unsupported}
        if not up: W.append(f"{LEAGUE_NAMES[lg]}: no upcoming fixtures in the data (no permitted source has published them yet)")
        elif horizon < (now + datetime.timedelta(days=7)).strftime('%Y-%m-%d'): W.append(f"{LEAGUE_NAMES[lg]}: fixtures only until {horizon} (the only permitted source publishes about one week ahead)")
        if latest and stats_latest and latest > stats_latest and days(stats_latest) > 4 and (pp or up or days(latest) < 30):
            W.append(f"{LEAGUE_NAMES[lg]}: results to {latest} are score-only; match statistics only to {stats_latest} (statistics source not updated yet)")
    # results still shown as upcoming: kick-off more than 4 days ago, no result
    stale = []
    for f in fx:
        ko = f.get('ko_utc')
        if ko and not off(f) and datetime.datetime.fromisoformat(ko.replace('Z', '+00:00')) < now - datetime.timedelta(days=4) and not played(f): stale.append(f"{f['league']} {f['date']} {f['home']} v {f['away']}")
    out['played_over_4_days_ago_without_result'] = stale[:50]
    if stale: W.append(f"{len(stale)} fixture(s) kicked off over 4 days ago still have no result in the data")
    # MLS local dates: the calendar date at the stadium (data-src/mls/venue-timezones.json), from the UTC kick-off
    tzs = load(os.path.join(PACK, 'data-src/mls/venue-timezones.json')) or {'clubs': {}, 'venues': {}}
    bad, unknown, nodate = [], [], []
    for f in fx:
        if f['league'] != 'mls' or not remaining(f): continue
        lab = f"{f['date']} {f['home']} v {f['away']}"
        if not f.get('ko_utc'): nodate.append(lab); continue
        tz = tzs['venues'].get(f['venue']) if f.get('venue') else tzs['clubs'].get(f['home'])
        if not tz: unknown.append(lab); continue
        loc = datetime.datetime.fromisoformat(f['ko_utc'].replace('Z', '+00:00')).astimezone(ZoneInfo(tz)).strftime('%Y-%m-%d')
        if (f.get('local_date') or f['date']) != loc: bad.append(f"{lab}: stored {f.get('local_date') or f['date']}, stadium date {loc}")
    out['mls_local_date_mismatches'] = bad[:20]; out['mls_unknown_stadium_time_zone'] = unknown[:20]; out['mls_without_kickoff_time'] = nodate[:20]
    if bad: W.append(f"MLS: {len(bad)} fixture(s) whose stored local date does not match the kick-off at the stadium")
    if unknown: W.append(f"MLS: {len(unknown)} fixture(s) at a stadium with no known time zone (local date not worked out)")
    # NFL
    G = (load(os.path.join(site, 'data-nfl-games.json')) or {'items': []})['items']
    fin = [g for g in G if g.get('final')]; upg = sorted([g for g in G if not g.get('final') and g.get('ko_utc') and g['ko_utc'] > nowz], key=lambda g: g['ko_utc'])
    meta = load(os.path.join(site, 'data-nfl-meta.json')) or {}
    inj = load(os.path.join(site, 'data-nfl-injuries.json')) or {}
    nxt = upg[0] if upg else None
    teams = inj.get('teams') or {}
    nxt_week = nxt['week'] if nxt else None
    playing = {t for g in upg if g['week'] == nxt_week and g.get('season') == inj.get('season') for t in (g['home'], g['away'])} if nxt else set()
    reported = sorted(t for t in playing if (teams.get(t) or {}).get('week') == nxt_week)
    out['nfl'] = {'latest_final': max((g.get('local_date') or g['date'] for g in fin), default=None), 'upcoming_games': len(upg), 'player_log_rows': sum(f.get('rows', 0) for f in meta.get('files', [])),
                  'played_not_final': [g['id'] for g in G if not g.get('final') and g.get('ko_utc') and datetime.datetime.fromisoformat(g['ko_utc'].replace('Z', '+00:00')) < now - datetime.timedelta(hours=8)],
                  'injuries': {'file_written': inj.get('updated'), 'latest_report_week': inj.get('latest_week'), 'season_type': inj.get('season_type'), 'players_listed': len(inj.get('items') or []),
                               'next_game_week': nxt_week, 'teams_playing_next_week': len(playing), 'teams_with_that_weeks_report': len(reported),
                               'note': 'nflverse lists players on the official report only; a player who is absent is "not listed", never assumed healthy.'}}
    if out['nfl']['played_not_final']: W.append(f"NFL: {len(out['nfl']['played_not_final'])} game(s) played over 8 hours ago are not final in nflverse yet")
    if nxt and teams and len(reported) < len(playing) and (datetime.datetime.fromisoformat(nxt['ko_utc'].replace('Z', '+00:00')) - now).days <= 3:
        W.append(f"NFL injuries: week {nxt_week} reports in the data for {len(reported)} of {len(playing)} teams playing (the rest show their previous report)")
    # lineups: supplied by the owner, never collected automatically. Only status "confirmed" counts; the date is when it was checked.
    lu = load(os.path.join(site, 'data-lineups.json')) or {}; items = lu.get('items') or {}
    vals = [v for v in (items.values() if isinstance(items, dict) else items) if isinstance(v, dict)]
    conf = sorted(str(v.get('checked', ''))[:16] for v in vals if v.get('status') == 'confirmed' and v.get('checked'))
    keys = list(items.keys()) if isinstance(items, dict) else []
    current = [k for k in keys if (k.split(':')[1] if k.count(':') >= 1 else '') >= today and (items[k] or {}).get('status') == 'confirmed']
    out['lineups'] = {'source': 'owner-supplied team sheets (no permitted automatic source)', 'matches': len(vals), 'confirmed': len(conf),
                      'latest_confirmed_check': conf[-1] if conf else None, 'confirmed_for_today_or_later': len(current),
                      'note': 'Shown only for the match they belong to. No predicted lineups are published.'}
    # rosters: the directory file is rebuilt every night, but each club's list carries the date its source last stated it
    d = load(os.path.join(site, 'data-directory.json')) or {}; cl = d.get('clubs') or []
    for lg in sorted({c['league'] for c in cl}):
        cc = [c for c in cl if c['league'] == lg]; dated = [c['as_of'] for c in cc if c.get('as_of')]
        st = sorted(c['team'] for c in cc if not c.get('as_of') or days(c['as_of']) > 75)
        out['rosters'][lg] = {'clubs': len(cc), 'oldest_as_of': min(dated, default=None), 'newest_as_of': max(dated, default=None), 'undated': len(cc) - len(dated), 'older_than_75_days': st}
        if st: W.append(f"Squad lists ({LEAGUE_NAMES.get(lg, lg)}): {len(st)} club(s) last stated by the source over 75 days ago or undated: {', '.join(st[:6])}")
    out['rosters']['_directory_rebuilt'] = d.get('updated')
    # consistency checks of the published files (missing stays missing; unsupported markets stay unavailable)
    zero_filled = []
    for lg in LEAGUE_NAMES:
        for season in sorted({k[1] for k in res if k[0] == lg}):
            rr = [v for k, v in res.items() if k[0] == lg and k[1] == season]
            for x in ('hs', 'hc', 'hy'):
                vals_ = [v.get(x) for v in rr if v.get(x) is not None]
                if len(vals_) >= 20 and all(y == 0 for y in vals_): zero_filled.append(f'{lg} {season} {x}')
    score_only_with_stats = [f"{k[0]} {k[2]} {k[3]} v {k[4]}" for k, v in res.items() if re.search('Wikipedia', v.get('source') or '') and any(v.get(x) not in (None,) for x in STATS)]
    nf = sum(1 for f in fx if f.get('ko_utc') and f['date'] != datetime.datetime.fromisoformat(f['ko_utc'].replace('Z', '+00:00')).astimezone(uk).strftime('%Y-%m-%d'))
    out['checks'] = {'stat_columns_all_zero': zero_filled, 'score_only_records_with_statistics': score_only_with_stats[:20], 'fixtures_uk_date_not_matching_kickoff': nf,
                     'fixture_file_rows': len(fx), 'fixture_file_written': (load(os.path.join(site, 'data-fixtures.json')) or {}).get('updated')}
    if zero_filled: W.append(f"CHECK: statistic columns that are 0 for every match (a missing value may have been stored as 0): {', '.join(zero_filled[:6])}")
    if score_only_with_stats: W.append(f"CHECK: {len(score_only_with_stats)} score-only records carry statistics")
    if nf: W.append(f"CHECK: {nf} fixture(s) whose UK date does not match their kick-off time")
    return out, W

def workflow_schedule(live):
    """4 Nov 2026: the UK start times of the scheduled runs, read from the repository's workflow file (shown on Data & sources)."""
    try: txt = open(os.path.join(live, '.github/workflows/proplab-data-refresh.yml')).read()
    except Exception: return None
    return sorted(f'{int(h):02d}:{int(m):02d}' for m, h in re.findall(r"cron:\s*'(\d+)\s+(\d+)\s+\*\s+\*\s+\*'", txt)) or None

def public_status(rep, ok, state, old, site, now):
    fr, warn = freshness(site, now)
    srcs = {k: {'ok': v['ok'], 'checked': v['at'], 'last_success': state['last_successful'].get(k) or (old.get('sources', {}).get(k, {}) or {}).get('last_success'), 'detail': '' if v['ok'] else v['detail'][:200]} for k, v in rep['sources'].items()}
    for k, v in (rep.get('sources_carried') or {}).items():  # read less often than the run (5 Nov 2026): previous dates, never re-stamped
        if k not in srcs: srcs[k] = {'ok': v.get('ok', True), 'checked': v.get('checked'), 'last_success': v.get('last_success'), 'detail': 'not due this run'}
    cp = rep.get('completeness') or {}; gapn = len(cp.get('missing_vs_openfootball', [])) + len(cp.get('structure_warnings', [])) + len(cp.get('unmatched_names', []))
    warn = list(warn) + cp.get('structure_warnings', []) + ([f"{len(cp['missing_vs_openfootball'])} completed match(es) listed by openfootball are not in PropLab yet"] if cp.get('missing_vs_openfootball') else []) + ([f"club names not linked: {', '.join(cp['unmatched_names'][:5])}"] if cp.get('unmatched_names') else [])
    return {'schema': 1, 'last_run': rep['finished'], 'result': (('ok-with-gaps' if gapn else 'ok') if rep['changed_files'] else ('ok-no-changes-with-gaps' if gapn else 'ok-no-changes')) if ok else 'failed', 'completeness': cp,
            'last_success': rep['finished'] if ok else old.get('last_success'), 'changed_files': rep['changed_files'] if ok else [],
            'validation': {'checks': rep['validation'].get('checks', 0), 'failures': rep['validation'].get('failures', [])[:20]},
            'errors': rep['errors'][:30], 'notes': rep['notes'][:30], 'warnings': warn, 'sources': srcs, 'freshness': fr, 'schedule_uk': rep.get('schedule_uk'),
            'note': 'Written by the daily data refresh. Data files are only replaced when every validation check passes; otherwise the last valid data stays published.'}

def report_md(rep, ok, state):
    cp = rep.get('completeness') or {}
    comp_md = ['## Completeness (every competition / season; this season reconciled with openfootball)']
    if not cp.get('ran'): comp_md.append('- ❌ the completeness audit did not run (see errors)')
    else:
        comp_md.append(f"- {'✅' if not cp.get('missing_vs_openfootball') else '⚠️'} completed matches listed by openfootball but missing in PropLab: {len(cp.get('missing_vs_openfootball', []))}" + (': ' + '; '.join(f"{x['competition']} {x['date']} {x['home']} v {x['away']} {x['score']} ({x['cause']})" for x in cp['missing_vs_openfootball'][:10]) if cp.get('missing_vs_openfootball') else ''))
        comp_md.append(f"- score differences with openfootball (check by hand; PropLab keeps 90-minute scores): {len(cp.get('score_differences_vs_openfootball', []))}" + (': ' + '; '.join(f"{x['competition']} {x['date']} {x['home']} v {x['away']} PropLab {x['proplab']} / openfootball {x['openfootball']}" for x in cp['score_differences_vs_openfootball'][:6]) if cp.get('score_differences_vs_openfootball') else ''))
        comp_md.append(f"- {'✅' if not cp.get('unmatched_names') else '⚠️'} club names not linked to a PropLab club: {len(cp.get('unmatched_names', []))}" + (': ' + ', '.join(cp['unmatched_names'][:10]) if cp.get('unmatched_names') else ''))
        comp_md += [f'- ⚠️ {w}' for w in cp.get('structure_warnings', [])] or ['- ✅ structure: every finished season complete; no club falling behind; no stale results; no unknown club names']
    m = rep['metrics']; L = []
    L.append(f"# PropLab Data Refresh — {rep['finished'][:16].replace('T', ' ')} UTC\n")
    L.append(f"Baseline: live repository commit {rep.get('live_commit', '?')}.  Result: **{('OK, WITH GAPS FLAGGED BELOW' if (cp.get('missing_vs_openfootball') or cp.get('structure_warnings') or cp.get('unmatched_names')) else 'OK') if ok else 'VALIDATION FAILED — nothing prepared for upload'}**.\n")
    L += comp_md + ['']
    nf = m['football_new_results']; L.append('## Imported')
    L.append(f"- Newly completed football matches: **{sum(nf.values())}** ({', '.join(f'{LEAGUE_NAMES.get(k, k)} {v}' for k, v in sorted(nf.items())) or 'none'})")
    L.append(f"- Historical football scores corrected: {m['football_results_corrected']} (score conflicts are never applied automatically; see Problems)")
    L.append(f"- Existing football match records updated (statistics added or corrected, same score): {m['football_records_updated']}")
    L.append(f"- MLS player match files: {m['mls_player_matches_new']} new matches, {m['mls_player_matches_updated']} updated ({m['mls_player_rows']} player rows in total)")
    L.append(f"- NFL: {m['nfl_new_final']} newly completed games; {m['nfl_score_changed']} final scores changed; player game-log rows {m['nfl_log_rows_before']} → {m['nfl_log_rows']}")
    L.append(f"- Fixtures: {m['fixtures_new']} new, {m['fixtures_revised']} revised (date/time), {m['fixtures_dropped']} upcoming removed (moved or no longer scheduled); NFL games revised: {m['nfl_games_revised']}")
    for u in (rep.get('europe') or {}).values():
        L.append(f"- {u['name']} {u['season']}/{str(u['season'] + 1)[2:]} (Wikipedia): {u['matches_listed']} matches listed, {u['completed']} with a final score ({u['with_half_time']} with half-time score and goal times). Shots, corners, fouls and cards: not available from this source (missing, never 0)." + (f" Skipped: {'; '.join(u['skipped'][:5])}" if u.get('skipped') else ''))
    if rep.get('wikipedia'):
        L.append('\n## Final scores from Wikipedia (score only, until football-data.co.uk adds the statistics)')
        L.append('| League | Table updated to | Scores added | Agree with football-data.co.uk | Disagree | Left out | Scotland dates |\n|---|---|---|---|---|---|---|')
        for lg, w in rep['wikipedia'].items():
            L.append(f"| {LEAGUE_NAMES.get(lg, lg)} | {w['updated'] or ('ERROR: ' + str(w['error']) if w.get('error') else '-')} | {w['added']} | {w['agree']} | {len(w['disagree'])} | {w['skipped']} | {w['fixtures'] if lg == 'scotprem' else ''} |")
        dis = [f"{lg}: {d}" for lg, w in rep['wikipedia'].items() for d in w['disagree']]
        if dis: L.append('\nScore disagreements (the published football-data.co.uk score is kept): ' + '; '.join(dis[:20]))
    L.append('\n## Freshness by league')
    L.append('| League | Last result in data | Upcoming fixtures (with confirmed time) |\n|---|---|---|')
    for lg in LEAGUE_NAMES:
        L.append(f"| {LEAGUE_NAMES[lg]} | {m['latest_result'].get(lg, '-')} | {m['fixtures_upcoming'].get(lg, 0)} ({m['fixtures_upcoming_timed'].get(lg, 0)}) |")
    L.append(f"| NFL | {m['nfl_latest_final']} | – |")
    if m['played_without_result']:
        L.append(f"\n**Played but no final result yet ({len(m['played_without_result'])})** — the source has not published them; they will be picked up by a later refresh:")
        L += [f'- {x}' for x in m['played_without_result'][:40]]
    if m.get('season_gaps'):
        L.append(f"\n**Season check — played according to the openfootball schedule but no result in PropLab yet ({len(m['season_gaps'])})**:")
        L += [f'- {x}' for x in m['season_gaps'][:60]]
    if m['nfl_played_not_final']: L.append(f"\nNFL games kicked off over 5 hours ago but not final in nflverse yet: {', '.join(m['nfl_played_not_final'])}")
    if rep.get('warnings'):
        L.append('\n## Freshness warnings (shown on Data & sources; they do not block the refresh)')
        L += [f'- {x}' for x in rep['warnings']]
    if rep.get('notes'): L += [f'- Note: {x}' for x in rep['notes']]
    L.append('\n## Sources')
    for k, v in rep['sources'].items(): L.append(f"- {'✅' if v['ok'] else '❌'} {k}{' — ' + v['detail'] if v['detail'] and not v['ok'] else ''}")
    L.append('\n## Problems and checks')
    L.append(f"- Validation: {rep['validation'].get('checks', 0)} checks, {len(rep['validation']['failures'])} failures")
    L += [f'  - FAIL: {x}' for x in rep['validation']['failures']]
    L += [f'- {x}' for x in rep['errors']]
    L += [f'- Builder: {x}' for x in rep['builder_problems'][:30]]
    L += [f'- {x}' for x in rep['builder_notes'][:30]]
    L.append('- Licensing: football-data.co.uk, American Soccer Analysis, CBS Sports (MLS fixtures, manual) and Football Web Pages remain "Permission Unclear" (see DATA-LICENSING-AUDIT.md). openfootball and nflverse are openly licensed.')
    L.append('- MLS upcoming fixtures come from a manually kept file (data-src/mls/fixtures-mls-upcoming.txt) and are not refreshed automatically.')
    L.append('\n## Files to upload to GitHub')
    if not ok: L.append('None: validation failed. Fix the problems above and run again.')
    elif rep['changed_files']: L += [f'- {f}' for f in rep['changed_files']]
    else: L.append('None. No data changed since the published version.')
    return '\n'.join(L) + '\n'

if __name__ == '__main__':
    main()
