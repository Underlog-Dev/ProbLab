#!/usr/bin/env python3
"""NBA availability from the Official NBA Injury Report (PDF, published by the NBA several times each game day).

Usage: python3 nba_injuries.py <site-dir> [--pdf FILE] [--now ISO] [--out DIR]
Finds the latest published report (https://ak-static.cms.nba.com/referee/injury/Injury-Report_YYYY-MM-DD_HH_MMAM|PM.pdf, 15-minute
slots, US Eastern time), reads it with pdfplumber and writes <out>/data-nba-injuries.json:
  { schema, report (title time, ET), report_utc, fetched, url, source, items: [ { game_date, matchup, team, name, pid, status, reason } ],
    not_submitted: [ { team, matchup, game_date } ] }
Statuses are kept exactly as published (Out, Doubtful, Questionable, Probable, Available). A player who is not on the report is
"not on the report", never "fit". Players are matched to PropLab's NBA player ids by name and team (unmatched names are kept, pid null).
Needs: pip install pdfplumber (the nightly workflow installs it). Uses only the NBA's public report; no API key.
"""
import json, os, re, sys, unicodedata, urllib.request
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

URL = 'https://ak-static.cms.nba.com/referee/injury/Injury-Report_{d}_{h:02d}_{m:02d}{ap}.pdf'
UA = 'PropLab-data-refresh/1.0 (private, non-commercial statistics site; contact via GitHub underlog-dev/ProbLab)'
STATUSES = ('Out', 'Doubtful', 'Questionable', 'Probable', 'Available')
ET = ZoneInfo('America/New_York')

def norm(s):
    s = unicodedata.normalize('NFKD', s).encode('ascii', 'ignore').decode().lower()
    s = re.sub(r'\b(jr|sr|ii|iii|iv)\b\.?', '', s)
    return re.sub(r'[^a-z]', '', s)

def latest(now_utc, max_hours=48):
    t = now_utc.astimezone(ET).replace(second=0, microsecond=0); t -= timedelta(minutes=t.minute % 15)
    for _ in range(max_hours * 4):
        h12 = t.hour % 12 or 12
        u = URL.format(d=t.strftime('%Y-%m-%d'), h=h12, m=t.minute, ap='AM' if t.hour < 12 else 'PM')
        try:
            with urllib.request.urlopen(urllib.request.Request(u, headers={'User-Agent': UA}), timeout=30) as r:
                if r.status == 200: return u, r.read(), t
        except Exception: pass
        t -= timedelta(minutes=15)
    return None, None, None

def parse(pdf_bytes_or_path):
    import io, pdfplumber
    src = io.BytesIO(pdf_bytes_or_path) if isinstance(pdf_bytes_or_path, (bytes, bytearray)) else pdf_bytes_or_path
    items, nys, title = [], [], ''
    cur = {'date': None, 'time': None, 'matchup': None, 'team': None}
    prev_bounds = None
    with pdfplumber.open(src) as pdf:
        for pg in pdf.pages:
            ws = pg.extract_words(x_tolerance=1.5, keep_blank_chars=False)
            hdr = {w['text']: w['x0'] for w in ws if w['top'] < 120}
            if 'Report:' in hdr and not title: title = ' '.join(w['text'] for w in ws if abs(w['top'] - next(x['top'] for x in ws if x['text'] == 'Report:')) < 2 and w['x0'] > hdr['Report:'])
            # column starts from the header row (Game Date, Game Time, Matchup, Team, Player Name, Current Status, Reason)
            hrow = [w for w in ws if w['text'] in ('Matchup', 'Current', 'Reason') and w['top'] < 140]
            if not hrow:  # continuation page: same columns as the previous page, rows start under the title line
                if not prev_bounds: continue
                rep = [w['top'] for w in ws if w['text'] == 'Report:']
                htop = (rep[0] + 6) if rep else 0
                bounds = prev_bounds
            else:
                htop = min(w['top'] for w in hrow)
            xs = {}
            for w in ws:
                if abs(w['top'] - htop) > 3: continue
                if w['text'] == 'Game': xs.setdefault('date', w['x0']) if 'date' not in xs else xs.setdefault('time', w['x0'])
                elif w['text'] in ('Matchup', 'Team', 'Player', 'Current', 'Reason'): xs[w['text'].lower()] = w['x0']
            if hrow: bounds = sorted((v - 3, k) for k, v in xs.items()); prev_bounds = bounds
            col = lambda x: [k for v, k in bounds if x >= v][-1] if any(x >= v for v, _ in bounds) else 'date'
            lines = {}
            for w in ws:
                if w['top'] <= htop + 3 or w['text'].startswith('Page') or (w['text'] == 'of' and w['top'] > pg.height - 40): continue
                if w['top'] > pg.height - 40: continue
                key = next((k for k in lines if abs(k - w['top']) < 3), w['top']); lines.setdefault(key, []).append(w)
            rows, orphans = [], []
            for top in sorted(lines):
                cells = {}
                for w in sorted(lines[top], key=lambda w: w['x0']): cells.setdefault(col(w['x0']), []).append(w['text'])
                cells = {k: ' '.join(v) for k, v in cells.items()}
                if set(cells) <= {'reason'}: orphans.append((top, cells.get('reason', ''))); continue
                rows.append((top, cells))
            for top, c in rows:
                if c.get('date'): cur['date'] = c['date']
                if c.get('time'): cur['time'] = c['time']
                if c.get('matchup'): cur['matchup'] = c['matchup']
                if c.get('team'): cur['team'] = c['team']
                pl, stt = c.get('player', ''), c.get('current', '')
                if 'NOT YET SUBMITTED' in (pl + ' ' + stt + ' ' + c.get('reason', '')).upper():
                    nys.append({'game_date': cur['date'], 'matchup': cur['matchup'], 'team': cur['team']}); continue
                if not pl or stt not in STATUSES: continue
                last, _, first = pl.partition(',')
                items.append({'_top': top, 'game_date': cur['date'], 'time': cur['time'], 'matchup': cur['matchup'], 'team': cur['team'],
                              'name': f'{first.strip()} {last.strip()}'.strip(), 'status': stt, 'reason': c.get('reason', '').strip(), '_frag': []})
            page_items = [x for x in items if '_top' in x]
            for top, txt in orphans:  # a wrapped reason: its pieces sit just above and below the player's line
                near = min(page_items, key=lambda x: abs(x['_top'] - top), default=None)
                if near is not None and abs(near['_top'] - top) < 30: near['_frag'].append((top, txt))
            for x in page_items:
                parts = sorted(x['_frag'] + ([(x['_top'], x['reason'])] if x['reason'] else []))
                x['reason'] = ' '.join(t for _, t in parts).replace(' - ', ' – ').strip()
                del x['_top'], x['_frag']
    return title, items, nys

def main():
    site = sys.argv[1]
    a = sys.argv
    now = datetime.now(timezone.utc)
    if '--now' in a: now = datetime.fromisoformat(a[a.index('--now') + 1].replace('Z', '+00:00'))
    out = a[a.index('--out') + 1] if '--out' in a else site
    if '--pdf' in a:
        url, data, t = 'file:' + a[a.index('--pdf') + 1], open(a[a.index('--pdf') + 1], 'rb').read(), None
    else:
        url, data, t = latest(now)
        if not data: sys.exit('no NBA injury report found in the last 48 hours')
    title, items, nys = parse(data)
    players = json.load(open(os.path.join(site, 'data-nba-players.json')))['items']
    meta = json.load(open(os.path.join(site, 'data-nba-meta.json')))
    tname = {t['name']: t['abbr'] for t in meta['teams']}
    tname.update({'LA Clippers': 'LAC', 'Los Angeles Clippers': 'LAC'})
    idx = {}
    for p in players:
        idx.setdefault((norm(p['name']), p.get('team')), p['id']); idx.setdefault((norm(p['name']), None), p['id'])
    unmatched = 0
    for x in items:
        x['team'] = tname.get(x['team'], x['team'])
        x['pid'] = idx.get((norm(x['name']), x['team'])) or idx.get((norm(x['name']), None))
        if not x['pid']: unmatched += 1
        try: x['game_date'] = datetime.strptime(x['game_date'], '%m/%d/%Y').strftime('%Y-%m-%d')
        except (TypeError, ValueError): pass
    for x in nys:
        x['team'] = tname.get(x['team'], x['team'])
        try: x['game_date'] = datetime.strptime(x['game_date'], '%m/%d/%Y').strftime('%Y-%m-%d')
        except (TypeError, ValueError): pass
    rep_utc = t.astimezone(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ') if t else None
    doc = {'schema': 1, 'source': 'Official NBA Injury Report (official.nba.com)', 'url': url, 'report': title, 'report_utc': rep_utc,
           'fetched': now.strftime('%Y-%m-%dT%H:%M:%SZ'), 'items': items, 'not_submitted': nys, 'unmatched_names': unmatched}
    json.dump(doc, open(os.path.join(out, 'data-nba-injuries.json'), 'w'), separators=(',', ':'))
    print(f'{url}: {title} · {len(items)} players ({unmatched} not matched to a PropLab id) · {len(nys)} teams not yet submitted')

if __name__ == '__main__':
    main()
