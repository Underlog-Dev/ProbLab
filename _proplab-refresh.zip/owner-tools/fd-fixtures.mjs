// Converts football-data.co.uk fixtures.csv (next round of each league; dates dd/mm/yyyy, times in UK time) into a PropLab fixtures-*.txt file.
// Usage: node owner-tools/fd-fixtures.mjs <fixtures.csv> <out.txt> DIV=league [DIV=league ...]    e.g. SC0=scotprem
import fs from 'node:fs';
const [inp, outp, ...maps] = process.argv.slice(2); const M = Object.fromEntries(maps.map(x => x.split('=')));
const [h, ...rows] = fs.readFileSync(inp, 'utf8').replace(/^\uFEFF/, '').split(/\r?\n/).filter(Boolean); const H = h.split(',');
const toUtc = (date, time) => { const guess = Date.parse(`${date}T${time}:00Z`); let t = guess;
  for (let i = 0; i < 2; i++) { const p = Object.fromEntries(new Intl.DateTimeFormat('en-GB', { timeZone: 'Europe/London', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(new Date(t)).map(x => [x.type, x.value]));
    t += guess - Date.parse(`${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}:00Z`); }
  return new Date(t).toISOString().replace('.000Z', 'Z'); };
const lines = ['# league|local date (UK)|kickoff UTC|home|away|venue|source   (football-data.co.uk fixtures.csv: next round only, UK times)']; let n = 0;
for (const r of rows) { const o = Object.fromEntries(r.split(',').map((v, i) => [H[i], v])); const lg = M[o.Div]; if (!lg) continue;
  const [d, m, y] = o.Date.split('/'); const date = `${y}-${m}-${d}`; const ko = /^\d\d:\d\d$/.test(o.Time) ? toUtc(date, o.Time) : '';
  lines.push([lg, date, ko, o.HomeTeam, o.AwayTeam, '', 'football-data.co.uk fixtures'].join('|')); n++; }
fs.writeFileSync(outp, lines.join('\n') + '\n'); console.log(`${n} fixtures written`);
