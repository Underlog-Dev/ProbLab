// American Soccer Analysis (ASA) importer — private owner tool, NOT part of the public site.
// Source: https://app.americansocceranalysis.com (free public API; ASA asks for attribution, which the site shows).
// Writes builder inputs only (never the public data files directly):
//   results-mls-<season>.txt                 completed regular-season MLS results (goals) for H2H history
//   asa-players-mls-<season>.json            per-game player rows (minutes, shots, shots on target, goals, assists, key passes)
// ASA does NOT provide fouls, tackles or cards per player, so those stay blank (unknown), never 0.
// Usage: node asa-import.mjs <out-dir> [--seasons 2021,2022,2023,2024,2025] [--players-season 2026 | 2021,2022,...] [--mock <dir-with-*_payload.json>]
import fs from 'node:fs';
import path from 'node:path';
import { displayTeam } from './lib/teams.js';

const args = process.argv.slice(2); const outDir = args[0];
const opt = k => { const i = args.indexOf(k); return i > 0 ? args[i + 1] : null; };
const seasons = (opt('--seasons') || '2021,2022,2023,2024,2025').split(',').filter(Boolean);
const playersSeasons = (opt('--players-season') || '2026').split(',').filter(Boolean); // one or several seasons, e.g. 2021,2022,...,2026
const mock = opt('--mock');
if (!outDir) { console.error('Usage: node asa-import.mjs <out-dir> [--seasons ...] [--players-season 2026] [--mock dir]'); process.exit(2); }
fs.mkdirSync(outDir, { recursive: true });
const BASE = 'https://app.americansocceranalysis.com/api/v1/mls/';
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function get(endpoint, params = {}) {
  if (mock) { const f = { teams: 'teams', players: 'players', games: 'games', 'players/xgoals': 'players_xgoals' }[endpoint]; return JSON.parse(fs.readFileSync(path.join(mock, `${f}_payload.json`), 'utf8')); }
  const url = BASE + endpoint + '?' + new URLSearchParams(params);
  for (let attempt = 0; attempt < 4; attempt++) {
    const r = await fetch(url, { headers: { 'User-Agent': 'PropLab owner tool (free stats site; attribution shown)' } });
    if (r.status === 429) { await sleep(3000 * (attempt + 1)); continue; }
    if (!r.ok) throw new Error(`${url}: HTTP ${r.status}`);
    return r.json();
  }
  throw new Error(`${url}: rate limited`);
}
// ASA returns at most 10,000 rows per request; keep asking with &offset= until a page comes back short.
async function getAll(endpoint, params = {}) {
  if (mock) return get(endpoint, params);
  const out = [];
  for (let offset = 0; ; offset += 10000) {
    const page = await get(endpoint, offset ? { ...params, offset } : params);
    if (!Array.isArray(page)) throw new Error(`${endpoint}: expected a list`);
    out.push(...page);
    if (page.length < 10000) return out;
  }
}
// Calendar date in US Eastern time, matching how MLS (and CBS) list match days.
const etDate = utc => new Intl.DateTimeFormat('en-CA', { timeZone: 'America/New_York', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(String(utc).replace(' UTC', 'Z').replace(' ', 'T')));

const teams = new Map((await getAll('teams')).map(t => [t.team_id, displayTeam(t.team_name)]));
const report = { results: {}, players: {}, skipped: [] };

for (const season of [...new Set([...seasons, ...playersSeasons])]) {
  const games = (await getAll('games', { season_name: season })).filter(g => !mock || String(g.season_name) === season);
  const regular = games.filter(g => g.knockout_game === false && (mock || g.status === 'FullTime') && Number.isInteger(g.home_score) && Number.isInteger(g.away_score));
  const lines = [`# MLS ${season} regular season, from American Soccer Analysis (app.americansocceranalysis.com). date (US Eastern)|home|away|HG|AG|source`];
  for (const g of regular) {
    const h = teams.get(g.home_team_id), a = teams.get(g.away_team_id);
    if (!h || !a) { report.skipped.push(`game ${g.game_id}: unknown team id`); continue; }
    lines.push(`${etDate(g.date_time_utc)}|${h}|${a}|${g.home_score}|${g.away_score}|American Soccer Analysis`);
  }
  fs.writeFileSync(path.join(outDir, `results-mls-${season}.txt`), lines.join('\n') + '\n');
  report.results[season] = lines.length - 1;

  // Team shots per game (ASA team totals) and shots on target (sum of ASA player rows for that team and game).
  // Shots on target are only kept when the player rows add up exactly to ASA's team shot total, so the two sources agree.
  if (!mock) {
    const teamRows = await getAll('teams/xgoals', { season_name: season, split_by_games: 'true' });
    const prow = await getAll('players/xgoals', { season_name: season, split_by_games: 'true' });
    const sum = new Map(); for (const r of prow) { const k = r.game_id + '|' + r.team_id; const e = sum.get(k) || { shots: 0, sot: 0 }; e.shots += r.shots || 0; e.sot += r.shots_on_target || 0; sum.set(k, e); }
    const tshots = new Map(teamRows.map(r => [r.game_id + '|' + r.team_id, r]));
    const items = []; let sotDropped = 0;
    for (const g of regular) {
      const h = teams.get(g.home_team_id), a = teams.get(g.away_team_id); if (!h || !a) continue;
      const th = tshots.get(g.game_id + '|' + g.home_team_id), ta = tshots.get(g.game_id + '|' + g.away_team_id);
      if (!th || !ta || !Number.isInteger(th.shots_for) || !Number.isInteger(ta.shots_for)) { report.skipped.push(`team shots missing for game ${g.game_id}`); continue; }
      const ph = sum.get(g.game_id + '|' + g.home_team_id), pa = sum.get(g.game_id + '|' + g.away_team_id);
      const sotOk = ph && pa && ph.shots === th.shots_for && pa.shots === ta.shots_for;
      if (!sotOk) sotDropped++;
      items.push({ date: etDate(g.date_time_utc), home: h, away: a, hg: g.home_score, ag: g.away_score, hs: th.shots_for, as: ta.shots_for, hst: sotOk ? ph.sot : null, ast: sotOk ? pa.sot : null });
    }
    fs.writeFileSync(path.join(outDir, `teamstats-mls-${season}.json`), JSON.stringify({ format: 'proplab-teamstats', league: 'mls', season: Number(season), source: 'American Soccer Analysis (team shots; shots on target summed from player rows)', items }));
    report.teamstats = { ...(report.teamstats || {}), [season]: { games: items.length, shots_on_target_left_blank: sotDropped } };
  }

  if (!playersSeasons.includes(season)) continue;
  const players = new Map((await getAll('players')).map(p => [p.player_id, p.player_name]));
  const rows = await getAll('players/xgoals', { season_name: season, split_by_games: 'true' });
  const byGame = new Map(regular.map(g => [g.game_id, g]));
  const matches = new Map();
  for (const r of rows) {
    const g = byGame.get(r.game_id); if (!g) { report.skipped.push(`player row for game ${r.game_id}: not a completed regular-season game`); continue; }
    const name = players.get(r.player_id), team = teams.get(r.team_id);
    if (!name || !team) { report.skipped.push(`player ${r.player_id} game ${r.game_id}: unknown player or team`); continue; }
    if (!Number.isInteger(r.minutes_played) || r.minutes_played < 0 || r.minutes_played > 130) { report.skipped.push(`${name} ${r.game_id}: bad minutes`); continue; }
    if (!matches.has(r.game_id)) matches.set(r.game_id, { league: 'mls', season: Number(season), date: etDate(g.date_time_utc), home: teams.get(g.home_team_id), away: teams.get(g.away_team_id), complete: false, source: 'American Soccer Analysis (app.americansocceranalysis.com)', players: [] });
    const num = v => (Number.isInteger(v) && v >= 0 ? v : undefined);
    matches.get(r.game_id).players.push({ player_id: 'asa:' + r.player_id, team, name, position: r.general_position || '', minutes: r.minutes_played, shots: num(r.shots), shots_on_target: num(r.shots_on_target), goals: num(r.goals), assists: num(r.primary_assists), key_passes: num(r.key_passes) });
  }
  fs.writeFileSync(path.join(outDir, `asa-players-mls-${season}.json`), JSON.stringify({ format: 'proplab-football', source: 'American Soccer Analysis', matches: [...matches.values()] }));
  report.players[season] = { matches: matches.size, rows: [...matches.values()].reduce((s, m) => s + m.players.length, 0) };
}
console.log(JSON.stringify(report, null, 1));
