#!/usr/bin/env python3
"""UEFA club competitions (men: Champions League, Europa League, Conference League) from Wikipedia's season articles (CC BY-SA 4.0): fixtures, final scores and goal events.

Usage: python3 ucl_wiki.py <out-dir> [--comp ucl|uel|uecl] [--cache <dir>] [--seasons 2021-2026] [--offline]
(file names below use the --comp code; ucl is the default)

Writes into <out-dir> (inputs for build-data.mjs):
  fixtures-ucl-wikipedia.txt   current season: every main-stage match, kick-off as a UTC instant (UEFA times are CET/CEST)
  rounds-ucl.txt               league-phase matchday of each current-season match (for Current / Next Gameweek)
  events-ucl-<season>.json     completed main-stage matches of each season: 90-minute score, half-time score and goal list
  ucl-report.json              counts, skipped boxes and the reason for each

What is NOT in these articles, so never written (stays missing, never 0): shots, shots on target, corners, fouls, yellow and red cards.
Rules:
- Qualifying rounds are excluded: only the group / league phase, knockout rounds and the final.
- The 90-minute score is used, as for the domestic leagues. After extra time it is rebuilt from the goal minutes (goals after 90'+stoppage
  are left out). If the listed goals do not add up to the published score, the match keeps no goal-based figures at all (missing).
- Half-time goals come from goal minutes: 1'-45' and 45+N' are first half. Only kept when the goal list adds up to the score.
- Penalty shoot-outs never count as goals.
- Awarded results (match not played, e.g. Tottenham v Rennes, Dec 2021) are left out: no match took place.
"""
import json, os, re, sys, time, urllib.parse, urllib.request
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

UA = "PropLab-data-refresh/1.0 (private, non-commercial statistics site; contact via GitHub underlog-dev/ProbLab)"
CET = ZoneInfo("Europe/Paris")  # UEFA lists CET / CEST
UK = ZoneInfo("Europe/London")

COMPS = {
    "ucl": {"name": "UEFA Champions League", "first": 1955},
    "uel": {"name": "UEFA Europa League", "first": 2009},
    "uecl": {"name": "UEFA Conference League", "first": 2021},
}
COMP = "ucl"

def article_name(season):
    if COMP == "ucl": return "UEFA_Champions_League"
    if COMP == "uel": return "UEFA_Europa_League"
    return "UEFA_Europa_Conference_League" if season <= 2023 else "UEFA_Conference_League"  # renamed from 2024/25

def pages(season):
    y = f"{season}–{str(season + 1)[2:]}"
    first = "group_stage" if season <= 2023 else "league_phase"
    a = article_name(season)
    return [(f"{y}_{a}_{first}", "main"), (f"{y}_{a}_knockout_phase", "ko"), (f"{season + 1}_{a}_final", "final")]

def fetch(title, cache, offline):
    fn = os.path.join(cache, title.replace("–", "---").replace("/", "_") + ".txt") if cache else None
    if fn and os.path.exists(fn) and (offline or time.time() - os.path.getmtime(fn) < 3600):
        return open(fn, encoding="utf-8").read()
    if offline: return None
    url = "https://en.wikipedia.org/w/index.php?" + urllib.parse.urlencode({"title": title, "action": "raw"})
    for attempt in range(4):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": UA}), timeout=40) as r:
                txt = r.read().decode("utf-8")
            rd = re.match(r"\s*#REDIRECT\s*\[\[([^\]#|]+)", txt, re.I)
            if rd and title != rd.group(1).strip().replace(" ", "_"):
                txt = fetch(rd.group(1).strip().replace(" ", "_"), cache, offline)
                if txt is None: return None
            if fn: os.makedirs(cache, exist_ok=True); open(fn, "w", encoding="utf-8").write(txt)
            return txt
        except urllib.error.HTTPError as e:
            if e.code == 404: return None
            time.sleep(5 * (attempt + 1))
        except Exception:
            time.sleep(5 * (attempt + 1))
    return None

def link_text(s):
    s = re.sub(r"<ref[^>]*/>|<ref[^>]*>.*?</ref>|<!--.*?-->", "", s, flags=re.S)
    s = re.sub(r"\{\{(?:fbaicon|flagicon|fb|small|nowrap)\|[^{}]*\}\}", "", s)
    m = re.search(r"\[\[([^\]|]+)(?:\|([^\]]+))?\]\]", s)
    if m: return (m.group(2) or m.group(1)).strip(), m.group(1).strip()
    t = re.sub(r"\{\{[^{}]*\}\}", "", s).strip()
    return t, t

def boxes(txt):
    """Yield (matchday or None, stage, dict of fields) for every Football box in order."""
    md, stage = None, ""
    i = 0
    heads = [(m.start(), m.group(1).strip()) for m in re.finditer(r"^={2,5}\s*([^=].*?)\s*={2,5}\s*$", txt, flags=re.M)]
    for m in re.finditer(r"\{\{(?:#invoke:\s*[Ff]ootball box\s*\|\s*main|\s*[Ff]ootball box\s*(?=[\n|]))", txt):
        start = m.start(); depth, j = 0, start
        while j < len(txt):
            if txt.startswith("{{", j): depth += 1; j += 2; continue
            if txt.startswith("}}", j):
                depth -= 1; j += 2
                if depth == 0: break
                continue
            j += 1
        body = re.sub(r"<!--.*?-->", "", txt[m.end():j - 2], flags=re.S)
        hd = [h for p, h in heads if p < start]
        sec = hd[-1] if hd else ""
        mdm = next((re.search(r"Matchday\s+(\d+)", h) for h in reversed(hd) if re.search(r"Matchday\s+(\d+)", h)), None)
        f, depth, cur, buf = {}, 0, None, ""
        # split on top-level "|"
        parts, k, level = [], 0, 0
        while k < len(body):
            if body.startswith("{{", k) or body.startswith("[[", k): level += 1; buf += body[k:k + 2]; k += 2; continue
            if body.startswith("}}", k) or body.startswith("]]", k): level -= 1; buf += body[k:k + 2]; k += 2; continue
            if body[k] == "|" and level == 0: parts.append(buf); buf = ""; k += 1; continue
            buf += body[k]; k += 1
        parts.append(buf)
        for p in parts:
            if "=" in p:
                a, b = p.split("=", 1); f[a.strip()] = b.strip()
        ks = next((h for h in reversed(hd) if re.search(r"play-?off|round of|quarter|semi|final", h, re.I)), sec)
        yield (int(mdm.group(1)) if mdm else None), ks, f

def parse_date(s):
    m = re.search(r"\{\{\s*[Ss]tart date\s*\|\s*(\d{4})\s*\|\s*(\d{1,2})\s*\|\s*(\d{1,2})", s)
    return f"{int(m.group(1)):04d}-{int(m.group(2)):02d}-{int(m.group(3)):02d}" if m else None

def parse_time(s):
    s = re.sub(r"\{\{\s*(?:CEST|CET)\s*\|\s*(\d{1,2}:\d{2})\s*\}\}", r"\1", s)
    m = re.match(r"\s*(\d{1,2}):(\d{2})", s)
    return (int(m.group(1)), int(m.group(2))) if m else None

MIN = re.compile(r"^\d{1,3}(\+\d{1,2})?$")
def goals_of(s, side):
    out = []
    for line in re.split(r"\n\s*\*", "\n" + s):
        line = line.strip()
        if not line: continue
        name = link_text(line.split("{{goal")[0])[0].strip().strip("*").strip() if "{{goal" in line else ""
        for g in re.finditer(r"\{\{\s*goal\s*\|([^{}]*)\}\}", line):
            args = [a.strip() for a in g.group(1).split("|")]
            i = 0
            while i < len(args):
                mn = args[i]
                if not MIN.match(mn): i += 1; continue
                note = args[i + 1] if i + 1 < len(args) and not MIN.match(args[i + 1]) else ""
                typ = "pen" if note.lower().startswith("p") else "og" if "o.g" in note.lower() else ""
                out.append({"min": mn, "team": side, "player": name or "?", "type": typ})
                i += 2 if i + 1 < len(args) and not MIN.match(args[i + 1]) else 1
    return out

def minute_val(m):
    a, _, b = m.partition("+"); return int(a), int(b or 0)

def main():
    global COMP
    out = sys.argv[1]; args = sys.argv[2:]
    COMP = args[args.index("--comp") + 1] if "--comp" in args else "ucl"
    if COMP not in COMPS: sys.exit("unknown --comp " + COMP)
    CN = COMPS[COMP]["name"]
    cache = args[args.index("--cache") + 1] if "--cache" in args else None
    offline = "--offline" in args
    rng = args[args.index("--seasons") + 1] if "--seasons" in args else "2021-2026"
    s0, s1 = map(int, rng.split("-")); s0 = max(s0, COMPS[COMP]["first"])
    now = datetime.now(timezone.utc)
    cur_season = now.year if now.month >= 7 else now.year - 1
    os.makedirs(out, exist_ok=True)
    report = {"generated": now.strftime("%Y-%m-%dT%H:%M:%SZ"), "source": f"Wikipedia (CC BY-SA 4.0), {CN} season articles", "seasons": {}, "skipped": [], "missing_pages": []}
    fx_lines, rd_lines = [], []
    for season in range(s0, s1 + 1):
        items, seen = [], set()
        n_box = 0
        for title, kind in pages(season):
            txt = fetch(title, cache, offline)
            if txt is None:
                if not (season == cur_season and kind != "main"): report["missing_pages"].append(title)
                continue
            for md, sec, f in boxes(txt):
                n_box += 1
                d = parse_date(f.get("date", "")); t = parse_time(f.get("time", ""))
                h, hl = link_text(f.get("team1", "")); a, al = link_text(f.get("team2", ""))
                if re.match(r"(Winner|Loser|Runner-up|Match)\b", h) or re.match(r"(Winner|Loser|Runner-up|Match)\b", a):
                    report["skipped"].append(f"{title}: {d} {h} v {a} has placeholder teams; listed once both clubs are known"); continue
                if not d or not h or not a:
                    report["skipped"].append(f"{title}: box without date/teams ({d} {h} v {a})"); continue
                ko = None
                if t:
                    loc = datetime(int(d[:4]), int(d[5:7]), int(d[8:10]), t[0], t[1], tzinfo=CET)
                    ko = loc.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:00Z")
                ukd = datetime.fromisoformat(ko.replace("Z", "+00:00")).astimezone(UK).strftime("%Y-%m-%d") if ko else d
                key = (ukd, h, a)
                if key in seen: continue
                seen.add(key)
                stage = "League phase" if kind == "main" and season >= 2024 else "Group stage" if kind == "main" else "Final" if kind == "final" else (re.sub(r"\s*\(.*", "", sec).strip() or "Knockout phase")
                venue = link_text(f.get("stadium", ""))[0]
                if season == cur_season:
                    fx_lines.append(f"{COMP}|{d}|{ko or ''}|{h}|{a}|{venue}|Wikipedia: {title.replace('_', ' ')} (CC BY-SA 4.0)")
                    if md: rd_lines.append(f"{COMP}|{md}|{ukd}|{h}|{a}")
                sc = re.sub(r"<!--.*?-->", "", f.get("score", ""), flags=re.S)
                sm = re.match(r"\s*(\d{1,2})\s*[–−\-]\s*(\d{1,2})", sc)
                if not sm: continue  # not played yet
                fh, fa = int(sm.group(1)), int(sm.group(2))
                if re.search(r"awarded|\{\{\s*awd|w/o|walkover|forfeit", sc + " " + f.get("scorenote", "") + " " + f.get("result", ""), re.I):
                    report["skipped"].append(f"{season} {ukd} {h} v {a}: score {fh}-{fa} was awarded (match not played); left out"); continue
                aet = bool(re.search(r"a\.?e\.?t|\{\{\s*aet", sc + " " + f.get("aet", ""), re.I)) or f.get("aet", "").lower().startswith("y")
                g = goals_of(f.get("goals1", ""), "home") + goals_of(f.get("goals2", ""), "away")
                adds = sum(1 for x in g if x["team"] == "home") == fh and sum(1 for x in g if x["team"] == "away") == fa
                rec = {"date": ukd, "home": h, "away": a, "stage": stage, **({"matchday": md} if md else {}), "ko_utc": ko}
                if not adds:
                    if aet:
                        report["skipped"].append(f"{season} {ukd} {h} v {a}: after extra time and the goal list ({len(g)}) does not add up to {fh}-{fa}; no 90-minute score is published"); continue
                    rec.update(hg=fh, ag=fa, hthg=None, htag=None)
                    report["skipped"].append(f"{season} {ukd} {h} v {a}: goal list does not add up to {fh}-{fa}; score kept, half-time goals left missing")
                else:
                    reg = [x for x in g if minute_val(x["min"])[0] <= 90] if aet else g
                    first = lambda side: sum(1 for x in reg if x["team"] == side and minute_val(x["min"])[0] <= 45)
                    rec.update(hg=sum(1 for x in reg if x["team"] == "home"), ag=sum(1 for x in reg if x["team"] == "away"), hthg=first("home"), htag=first("away"), goals=reg)
                    if aet: rec["aet_score"] = f"{fh}-{fa}"
                items.append(rec)
        items.sort(key=lambda r: r["date"])
        json.dump({"schema": 1, "source": f"Wikipedia {CN} season articles (CC BY-SA 4.0)", "season": season, "items": items}, open(os.path.join(out, f"events-{COMP}-{season}.json"), "w"), ensure_ascii=False)
        report["seasons"][season] = {"boxes": n_box, "completed": len(items), "with_half_time": sum(1 for r in items if r.get("hthg") is not None)}
    open(os.path.join(out, f"fixtures-{COMP}-wikipedia.txt"), "w", encoding="utf-8").write("\n".join(fx_lines) + "\n")
    open(os.path.join(out, f"rounds-{COMP}.txt"), "w", encoding="utf-8").write("\n".join(rd_lines) + "\n")
    json.dump(report, open(os.path.join(out, f"{COMP}-report.json"), "w"), indent=1, ensure_ascii=False)
    print(json.dumps({k: v for k, v in report.items() if k != "skipped"}, indent=1), "\nskipped:", len(report["skipped"]))

if __name__ == "__main__":
    main()
