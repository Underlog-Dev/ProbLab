#!/usr/bin/env python3
"""Validates a built PropLab site folder before anything is uploaded.
Usage: python3 owner-tools/validate.py <built-site-dir> [<live-site-dir> [<nflverse-raw-dir>]]
Writes <built-site-dir>/.validation.json ({checks, failures, warnings}) and prints a summary. Exit 1 when a check fails.
A failure means the data must not be published as it is. Nothing is repaired here."""
import csv, datetime, json, os, sys
from collections import Counter, defaultdict
from zoneinfo import ZoneInfo

SITE = sys.argv[1]; LIVE = sys.argv[2] if len(sys.argv) > 2 else None; RAW = sys.argv[3] if len(sys.argv) > 3 else None
UK = ZoneInfo('Europe/London'); TODAY = datetime.datetime.now(UK).strftime('%Y-%m-%d')
checks, failures, warnings = [0], [], []
def check(ok, label, detail=''):
    checks[0] += 1
    if not ok: failures.append(f'{label}{": " + str(detail)[:300] if detail != "" else ""}')
def load(d, f):
    try: return json.load(open(os.path.join(d, f)))
    except FileNotFoundError: return None
def ukparts(iso):
    t = datetime.datetime.fromisoformat(iso.replace('Z', '+00:00')).astimezone(UK); return t.strftime('%Y-%m-%d'), t.strftime('%H:%M')

# every JSON file parses; the manifest only points at files that exist
bad = []
for f in os.listdir(SITE):
    if f.startswith('data-') and f.endswith('.json'):
        try: json.load(open(os.path.join(SITE, f)))
        except Exception as e: bad.append(f'{f}: {e}')
check(not bad, 'all data files are valid JSON', bad)
man = load(SITE, 'data-manifest.json') or {}
files = [man.get('fixtures', {}) and man['fixtures'].get('file')] + [e['file'] for e in man.get('team_matches', []) + man.get('player_matches', [])]
miss = [f for f in files if f and not os.path.exists(os.path.join(SITE, f))]
check(not miss, 'every file named in data-manifest.json exists', miss)

# fixtures
fx = (load(SITE, 'data-fixtures.json') or {}).get('items', [])
badt = [f for f in fx if f.get('ko_utc') and ukparts(f['ko_utc']) != (f['date'], f.get('kickoff'))]
check(not badt, 'fixtures: UK date and time agree with the UTC kick-off instant', [(f['league'], f['home'], f['away'], f['date'], f.get('kickoff'), f['ko_utc']) for f in badt[:3]])
keys = Counter((f['league'], f['date'], f['home'], f['away']) for f in fx)
check(all(v == 1 for v in keys.values()), 'fixtures: no duplicates', [k for k, v in keys.items() if v > 1][:3])
nokt = [f for f in fx if f.get('kickoff') and not f.get('ko_utc')]
check(not nokt, 'fixtures: every fixture with a kick-off time has its UTC instant', [(f['league'], f['home'], f['away']) for f in nokt[:3]])
pairs = Counter((f['league'], f['home'], f['away']) for f in fx if f['league'] not in ('scotprem', 'mls') and f['date'] >= TODAY)
check(all(v == 1 for v in pairs.values()), 'fixtures: a pairing appears at most once in leagues where clubs meet once at each ground', [k for k, v in pairs.items() if v > 1][:3])
rounds = (load(SITE, 'data-fixtures.json') or {}).get('rounds', {})
untag = [f for f in fx if f['league'] in rounds and f['date'] >= TODAY and not f.get('round')]
if untag: warnings.append(f'{len(untag)} upcoming fixtures in round-calendar leagues have no round (they only appear under All Upcoming): ' + '; '.join(f"{f['league']} {f['home']} v {f['away']}" for f in untag[:5]))

# team matches
EXP = {'epl': 38, 'laliga': 38, 'seriea': 38, 'bundesliga': 34, 'ligaportugal': 34, 'eredivisie': 34, 'scotprem': 38, 'ligue1': 38, 'mls': 34,
       'championship': 46, 'leagueone': 46, 'leaguetwo': 46, 'superlig': 38, 'proleague': 44, 'eliteserien': 32}  # 27 Oct: Belgium incl. play-offs; Norway incl. relegation play-off
def tm(d):
    out = {}
    for e in (load(d, 'data-manifest.json') or {}).get('team_matches', []):
        for r in (load(d, e['file']) or {'items': []})['items']: out[(e['league'], e['season'], r['date'], r['home'], r['away'])] = r
    return out
T = tm(SITE)
per = defaultdict(Counter); dup = []
for e in man.get('team_matches', []):
    items = (load(SITE, e['file']) or {'items': []})['items']
    k = Counter((r['date'], r['home'], r['away']) for r in items); dup += [(e['file'], x) for x, v in k.items() if v > 1]
    for r in items: per[(e['league'], e['season'])][r['home']] += 1; per[(e['league'], e['season'])][r['away']] += 1
check(not dup, 'results: no duplicated matches', dup[:3])
fut = [k for k in T if k[2] > TODAY]; check(not fut, 'results: no result dated in the future', fut[:3])
over = [(k, c, n) for k, cnt in per.items() for c, n in cnt.items() if n > EXP.get(k[0], 40)]
check(not over, 'results: no club has more league games than a season allows', over[:3])
bads = [k for k, r in T.items() if not (isinstance(r.get('hg'), int) and isinstance(r.get('ag'), int) and 0 <= r['hg'] <= 20 and 0 <= r['ag'] <= 20)]
check(not bads, 'results: every score is a whole number in range', bads[:3])
if LIVE:
    L = tm(LIVE); gone = [k for k in L if k not in T]
    check(not gone, 'results: no published historical match was removed', gone[:3])
    changed = [k for k in L if k in T and (L[k]['hg'], L[k]['ag']) != (T[k]['hg'], T[k]['ag'])]
    check(not changed, 'results: no published score was changed without review', changed[:3])

# completeness (owner request 20 Oct 2026): gaps are reported as warnings in the run report and the public status, never hidden
CUPS = ('ucl', 'uel', 'uecl')
cur = {}
for (lg, season), cnt in per.items():
    if lg not in cur or season > cur[lg]: cur[lg] = season
# a finished league season must give every club its full number of matches
full = lambda lg, cnt: 34 if lg == 'mls' else 38 if lg == 'scotprem' else 30 if lg == 'eliteserien' else (len([c for c, n in cnt.items() if n > 2]) - 1) * 2  # Eliteserien: 16 clubs (a relegation play-off adds a 17th name); clubs with 1-2 games are play-off opponents  # double round robin (Ligue 1: 18 clubs from 2023/24)
short = [(lg, s, c, n, full(lg, cnt)) for (lg, s), cnt in per.items() if lg not in CUPS and s < cur.get(lg, s) for c, n in cnt.items() if n < full(lg, cnt) and not (lg == 'eliteserien' and n <= 2)]  # Eliteserien: 1-2 games = relegation play-off opponent
if short: warnings.append(f'COMPLETENESS: {len(short)} club-seasons have fewer league matches than a full season: ' + '; '.join(f'{lg} {s} {c} {n}/{x}' for lg, s, c, n, x in short[:8]))
# known, explained exceptions (matches never played): not gaps
KNOWN_UNPLAYED = {('uecl', 2021, 'Tottenham Hotspur'), ('uecl', 2021, 'Rennes')}  # Dec 2021: awarded 0-3 to Rennes, never played
# finished European seasons: every main-stage club has its group / league-phase games
for (lg, s), cnt in per.items():
    if lg in CUPS and s < cur.get(lg, s):
        need = 6 if (s <= 2023 or lg == 'uecl') else 8
        few = [(c, n) for c, n in cnt.items() if n < need and n % 2 == 1 and (lg, s, c) not in KNOWN_UNPLAYED]  # an odd count below the group games = a missing match (knockout-only clubs play 2, 4...)
        if few: warnings.append(f'COMPLETENESS: {lg} {s}: clubs with an incomplete group / league phase: ' + ', '.join(f'{c} {n}' for c, n in few[:6]))
# current season: no club far behind the others (a missing result or an import that stopped)
for lg, s in cur.items():
    cnt = per[(lg, s)]
    if lg in CUPS or len(cnt) < 4: continue
    top = max(cnt.values()); behind = [(c, n) for c, n in cnt.items() if top - n >= 3]
    if behind: warnings.append(f'COMPLETENESS: {lg} {s}: clubs 3+ matches behind the leaders (check for missing results or postponements): ' + ', '.join(f'{c} {n}/{top}' for c, n in behind[:6]))
# fixtures that kicked off more than 36 hours ago with no published result (results are matched within a day: MLS results carry the US date)
res_idx = defaultdict(list)
for (lg, season, d, h, a_), r in T.items(): res_idx[(lg, h, a_)].append(d)
now_utc = datetime.datetime.now(datetime.timezone.utc)
stale = []
for f in fx:
    if f.get('status') in ('postponed', 'abandoned') or not f.get('ko_utc'): continue
    t = datetime.datetime.fromisoformat(f['ko_utc'].replace('Z', '+00:00'))
    if (now_utc - t).total_seconds() > 36 * 3600 and not any(abs((datetime.date.fromisoformat(d) - datetime.date.fromisoformat(f['date'])).days) <= 1 for d in res_idx[(f['league'], f['home'], f['away'])]):
        stale.append(f"{f['league']} {f['date']} {f['home']} v {f['away']}")
if stale: warnings.append(f'COMPLETENESS: {len(stale)} fixtures kicked off over 36 h ago with no published result yet: ' + '; '.join(stale[:8]))
# team names: a fixture's club must be known in that league's current season (a new spelling would otherwise split a club in two)
known = defaultdict(set)
for (lg, season, d, h, a_) in T: known[lg].update((h, a_))
unk = sorted({(f['league'], n) for f in fx for n in (f['home'], f['away']) if f['league'] not in CUPS and known.get(f['league']) and n not in known[f['league']]})
if unk: warnings.append(f'TEAM NAMES: {len(unk)} fixture club names not seen in that league\'s results (new spelling, or a promoted club before its first match): ' + ', '.join(f'{lg}: {n}' for lg, n in unk[:8]))
# a drop in a competition's match count against the published data (removal itself is a failure above)
if LIVE:
    Lc = Counter((k[0], k[1]) for k in L); Tc = Counter((k[0], k[1]) for k in T)
    drop = [(k, Lc[k], Tc.get(k, 0)) for k in Lc if Tc.get(k, 0) < Lc[k]]
    check(not drop, 'results: no competition / season has fewer matches than the published data', drop[:3])

# MLS player rows
for e in man.get('player_matches', []):
    d = load(SITE, e['file']) or {'matches': []}
    k = Counter((m['date'], m['home'], m['away']) for m in d['matches']); check(all(v == 1 for v in k.values()), f"{e['file']}: no duplicated matches")
    badm = [(m['date'], p.get('name')) for m in d['matches'] for p in m.get('players', []) if not (isinstance(p.get('minutes'), int) and 0 <= p['minutes'] <= 130)]
    check(not badm, f"{e['file']}: minutes in range", badm[:3])

# NFL
G = (load(SITE, 'data-nfl-games.json') or {}).get('items', [])
if G:
    check(len({g['id'] for g in G}) == len(G), 'NFL: game ids unique')
    check(len({g['home'] for g in G} | {g['away'] for g in G}) == 32, 'NFL: 32 teams')
    badg = [g['id'] for g in G if g.get('ko_utc') and ukparts(g['ko_utc']) != (g['date'], g['kickoff'])]
    check(not badg, 'NFL: UK date/time agree with UTC kick-off', badg[:3])
    check(all(isinstance(g.get('week'), int) for g in G), 'NFL: every game has its official week number')
    meta = load(SITE, 'data-nfl-meta.json') or {}
    logs = {}
    for f in meta.get('files', []):
        d = load(SITE, f['file']); c = d['cols']
        for r in d['rows']: row = dict(zip(c, r)); logs[(row['pid'], row['game'])] = row
        check(len(d['rows']) == f['rows'], f"NFL: {f['file']} row count matches the meta file")
    if LIVE:
        LG = {g['id']: g for g in (load(LIVE, 'data-nfl-games.json') or {'items': []})['items']}
        lost = [i for i, g in LG.items() if g.get('final') and i not in {x['id'] for x in G}]
        check(not lost, 'NFL: no completed game was removed', lost[:3])
    if RAW:
        MAP = {'pass_yds': 'passing_yards', 'rush_yds': 'rushing_yards', 'rec': 'receptions', 'rec_yds': 'receiving_yards', 'tgt': 'targets', 'fgm': 'fg_made', 'tkl': 'def_tackles_solo'}
        num = lambda v: None if v in ('', 'NA') else float(v)
        mism, tot = [], 0
        for s in meta.get('seasons', []):
            p = os.path.join(RAW, f'stats_player_week_{s}.csv')
            if not os.path.exists(p): continue
            for r in csv.DictReader(open(p)):
                row = logs.get((r['player_id'], r['game_id']))
                if not row: continue
                for a, b in MAP.items():
                    if a in row:
                        tot += 1; rv = num(r[b])
                        if (rv is None) != (row[a] is None) or (rv is not None and abs(rv - row[a]) > 1e-9): mism.append((r['player_id'], r['game_id'], a))
        check(tot > 0 and not mism, f'NFL: published player stats equal the raw nflverse weekly stats ({tot} values)', mism[:3])

# ---- data-quality checks added 26 Oct (owner request): specific, actionable messages; warnings never block publishing ----
import hashlib, glob
def warn(msg): warnings.append(msg)
# manifest content versions match the files (cache keys)
mm = []
for e in [man.get(k) for k in ('fixtures', 'news', 'directory', 'player_index', 'photos')] + man.get('team_matches', []) + man.get('player_matches', []):
    if e and e.get('v') and os.path.exists(os.path.join(SITE, e['file'])):
        if hashlib.sha256(open(os.path.join(SITE, e['file']), 'rb').read()).hexdigest()[:12] != e['v']: mm.append(e['file'])
check(not mm, 'manifest: every listed file matches its content version (browsers fetch changed files fresh)', mm[:5])
# completed games still in Upcoming: a fixture more than 1 day old with a published result under the same clubs is fine (the site hides it);
# one with NO result after 2 days is listed, so a missing result is visible
fxs = (load(SITE, 'data-fixtures.json') or {}).get('items', [])
res = defaultdict(list)
for f2 in glob.glob(os.path.join(SITE, 'data-team-matches-*.json')):
    for r in json.load(open(f2)).get('items', []): res[(r['home'].lower(), r['away'].lower())].append(r['date'])
two = (datetime.datetime.now(UK) - datetime.timedelta(days=2)).strftime('%Y-%m-%d')
stale = [f"{f['league']} {f['date']} {f['home']} v {f['away']}" for f in fxs if f['date'] < two and not any(abs((datetime.date.fromisoformat(d) - datetime.date.fromisoformat(f['date'])).days) <= 1 for d in res.get((f['home'].lower(), f['away'].lower()), []))]
if stale: warn(f'{len(stale)} fixtures are 2+ days old with no published result (shown as Awaiting result / No result yet): ' + '; '.join(stale[:6]))
# MLS (and every fixture with a kick-off instant): UK date and time equal the UTC instant in Europe/London
badtz = [f"{f['league']} {f['home']} v {f['away']}" for f in fxs if f.get('ko_utc') and (f['date'], f.get('kickoff')) != ukparts(f['ko_utc']) and f.get('kickoff')]
check(not badtz, 'fixtures: UK date and kick-off equal the UTC kick-off converted to UK time (BST/GMT)', badtz[:5])
# recent results recorded with a score but without match statistics (score-only), per league, last 14 days
cut = (datetime.datetime.now(UK) - datetime.timedelta(days=14)).strftime('%Y-%m-%d'); so = Counter(); tot = Counter()
for f2 in glob.glob(os.path.join(SITE, 'data-team-matches-*.json')):
    d = json.load(open(f2)); lg = d.get('league')
    for r in d.get('items', []):
        if r['date'] >= cut and r.get('hg') is not None: tot[lg] += 1; so[lg] += 1 if r.get('hs') is None and r.get('hc') is None else 0
for lg, n in so.items():
    if n and lg not in ('ucl', 'uel', 'uecl', 'eliteserien'): warn(f'{lg}: {n} of {tot[lg]} results in the last 14 days have a score but no shots / corners (score-only); their markets skip those matches')
# squad lists (current-club verification): clubs whose published squad list is older than 75 days or has no date
dr = load(SITE, 'data-directory.json') or {}
old = [f"{c['team']} ({c.get('as_of') or 'no date'})" for c in dr.get('clubs', []) if not c.get('as_of') or c['as_of'] < (datetime.datetime.now(UK) - datetime.timedelta(days=75)).strftime('%Y-%m-%d')]
if old: warn(f'{len(old)} club squad lists are older than 75 days or undated, so their players are shown as "played this season" or historical unless verified: ' + ', '.join(old[:10]))
# NFL weekly model coverage (the model is hidden from the site, but its files are still produced)
nm = load(SITE, 'data-nfl-model.json')
if nm:
    games = {p['game_id'] for p in nm.get('predictions', [])}
    warn(f"NFL model file: {len(nm.get('predictions', []))} predictions covering {len(games)} games, weeks {nm.get('weeks')}, generated {nm.get('generated')} (not shown on the site)")

# ---- coverage report (owner request 27 Oct, Priority 10): what the published data actually covers, stated as numbers, not pass/fail ----
cov = {'generated': man.get('generated'), 'leagues': {}, 'notes': []}
STATS = [('hs', 'shots'), ('hst', 'shots on target'), ('hc', 'corners'), ('hf', 'fouls'), ('hy', 'cards'), ('hthg', 'half-time goals')]
tmf = {}
for e in man.get('team_matches', []): tmf.setdefault(e['league'], []).append(e)
fx_by = defaultdict(list)
for f in fxs: fx_by[f['league']].append(f)
for lg, es in sorted(tmf.items()):
    e = max(es, key=lambda x: x['season']); items = (load(SITE, e['file']) or {'items': []})['items']
    n = len(items); rec = {k: sum(1 for r in items if r.get(k) is not None) for k, _ in STATS}
    up = sorted(f['date'] for f in fx_by.get(lg, []) if f['date'] >= TODAY)
    # fixtures already played (a result exists) but still in the fixture file: the site hides them from Upcoming; counted so the refresh can be checked
    done = [f for f in fx_by.get(lg, []) if f['date'] < TODAY and any(abs((datetime.date.fromisoformat(d) - datetime.date.fromisoformat(f['date'])).days) <= 1 for d in res.get((f['home'].lower(), f['away'].lower()), []))]
    unsupported = [lab for k, lab in STATS if n and rec[k] == 0]
    cov['leagues'][lg] = {'season': e['season'], 'results': n, 'latest_result': max((r['date'] for r in items), default=None), 'file_updated': e.get('updated'),
        'with_stats_pct': {lab: (round(100 * rec[k] / n, 1) if n else None) for k, lab in STATS}, 'markets_not_recorded': unsupported,
        'upcoming_fixtures': len(up), 'fixtures_through': up[-1] if up else None, 'played_fixtures_still_in_file': len(done)}
# MLS: results carry the US date, fixtures the UK date; how many played MLS fixtures matched a result on the same day vs one day apart
mm_same = mm_off = 0
for f in fx_by.get('mls', []):
    ds = res.get((f['home'].lower(), f['away'].lower()), [])
    if f['date'] in ds: mm_same += 1
    elif any(abs((datetime.date.fromisoformat(d) - datetime.date.fromisoformat(f['date'])).days) == 1 for d in ds): mm_off += 1
cov['mls_date_matching'] = {'same_date': mm_same, 'one_day_apart_us_vs_uk': mm_off}
# player-stat coverage: MLS current-season team results that also have player rows
pm = [e for e in man.get('player_matches', []) if e['league'] == 'mls']
if pm and 'mls' in tmf:
    e = max(pm, key=lambda x: x['season']); pmk = {(m['date'], m['home'], m['away']) for m in (load(SITE, e['file']) or {'matches': []})['matches']}
    te = max(tmf['mls'], key=lambda x: x['season']); titems = (load(SITE, te['file']) or {'items': []})['items']
    have = sum(1 for r in titems if any((d, r['home'], r['away']) in pmk for d in (r['date'], (datetime.date.fromisoformat(r['date']) + datetime.timedelta(days=-1)).isoformat(), (datetime.date.fromisoformat(r['date']) + datetime.timedelta(days=1)).isoformat())))
    cov['player_stats'] = {'league': 'mls', 'season': e['season'], 'team_results': len(titems), 'with_player_rows': have, 'through': e.get('through'), 'other_leagues': 'no player match logs (team markets only)'}
    if titems and have < len(titems) * 0.95: warn(f'MLS player stats cover {have} of {len(titems)} current-season results')
# lineup freshness: owner-supplied team sheets
lu = load(SITE, 'data-lineups.json') or {}
ld = sorted(k.split(':')[1] for k in (lu.get('items') or {}) if k.count(':') >= 2)
cov['lineups'] = {'team_sheets': len(ld), 'latest_match_date': ld[-1] if ld else None, 'note': 'Supplied by the owner on match days; not refreshed automatically.'}
# NFL: completed games with a score and with player logs; weekly prediction coverage of the weeks it covers
if G:
    fin = [g for g in G if g.get('final')]; noscore = [g['id'] for g in fin if g.get('hs') is None or g.get('as') is None]
    lg_games = {k[1] for k in logs} if 'logs' in dir() else set()
    nolog = [g['id'] for g in fin if g['season'] in set(meta.get('seasons', [])) and g.get('type', 'R') == 'R' and g['id'] not in lg_games]
    check(not noscore, 'NFL: every completed game has its final score', noscore[:3])
    if nolog: warn(f'NFL: {len(nolog)} completed regular-season games have no player logs: ' + ', '.join(nolog[:6]))
    cov['nfl'] = {'games': len(G), 'completed': len(fin), 'completed_without_score': len(noscore), 'completed_without_player_logs': len(nolog), 'latest_completed': max((g['date'] for g in fin), default=None)}
    if nm:
        wk = set(nm.get('weeks') or []); want = {g['id'] for g in G if g['season'] == nm.get('season') and g.get('week') in wk}
        cov['nfl']['model_predictions'] = {'weeks': sorted(wk), 'games_in_those_weeks': len(want), 'games_with_predictions': len(games & want), 'generated': nm.get('generated')}
# Phase 2 (owner request): results refreshes must also bring the player statistics. MLS: player rows lag behind the team results? NBA: every
# final game has box-score rows for both teams? (NFL: completed games without player logs are counted above.)
if 'player_stats' in cov:
    ps = cov['player_stats']
    if ps['with_player_rows'] < ps['team_results']: warn(f"PLAYER STATS: {ps['team_results'] - ps['with_player_rows']} MLS results this season have no player rows yet (team score published, player statistics not)")
nm_ = load(SITE, 'data-nba-meta.json'); NG = load(SITE, 'data-nba-games.json')
if nm_ and NG:
    gi = NG.get('items') or [dict(zip(NG['cols'], r)) for r in NG.get('rows', [])]
    cs = nm_.get('current_season'); fin = {g['id']: g for g in gi if g.get('status') == 'final' and g.get('season') == cs}
    seen = defaultdict(set)
    for f in nm_.get('files', []):
        d = load(SITE, f['file']) or {}; c = d.get('cols') or []
        if 'game' in c and 'team' in c:
            gi_, ti_ = c.index('game'), c.index('team')
            for r in d.get('rows', []):
                if r[gi_] in fin: seen[r[gi_]].add(r[ti_])
    miss = [g for g, x in fin.items() if not ({x['home'], x['away']} <= seen.get(g, set()))]
    cov['nba'] = {'season': cs, 'final_games': len(fin), 'final_games_without_box_scores_for_both_teams': len(miss), 'latest_final': max((x['date'] for x in fin.values()), default=None)}
    if miss: warn(f'PLAYER STATS: {len(miss)} completed NBA games this season have no box-score rows for one or both teams: ' + ', '.join(sorted(miss)[:6]))
# squads: list ages and the last change log
sc = load(SITE, 'data-squad-changes.json')
cov['squads'] = {'club_lists': len(dr.get('clubs', [])), 'older_than_75_days_or_undated': len(old), 'by_league': {lg: v.get('updated') for lg, v in ((man.get('directory') or {}).get('leagues') or {}).items()},
                 'last_change_log': sc and {'updated': sc.get('updated'), 'changes': len(sc.get('changes', []))}}
# manifest timestamps: every file's 'updated' date is present and not in the future; files not updated for 14+ days in a current season are listed
fut_u = [e['file'] for e in man.get('team_matches', []) + man.get('player_matches', []) if e.get('updated') and e['updated'] > TODAY]
check(not fut_u, 'manifest: no file is dated in the future', fut_u[:3])
nod = [e['file'] for e in man.get('team_matches', []) + man.get('player_matches', []) if not e.get('updated')]
check(not nod, 'manifest: every data file has an updated date', nod[:3])
two_w = (datetime.datetime.now(UK) - datetime.timedelta(days=14)).strftime('%Y-%m-%d')
idle = [f"{lg} (updated {c['file_updated']})" for lg, c in cov['leagues'].items() if c['upcoming_fixtures'] and c['file_updated'] and c['file_updated'] < two_w]
if idle: warn('Current-season files not updated for 14+ days although fixtures are scheduled: ' + ', '.join(idle))
nr = {lg: c['markets_not_recorded'] for lg, c in cov['leagues'].items() if c['markets_not_recorded']}
if nr: cov['notes'].append('Markets with no recorded value this season (the site hides those cards and says why): ' + '; '.join(f'{lg}: {", ".join(v)}' for lg, v in nr.items()))
json.dump(cov, open(os.path.join(SITE, '.coverage.json'), 'w'), indent=1)

out = {'checks': checks[0], 'failures': failures, 'warnings': warnings, 'coverage': cov}
json.dump(out, open(os.path.join(SITE, '.validation.json'), 'w'), indent=1)
print(f'validation: {checks[0]} checks, {len(failures)} failures, {len(warnings)} warnings')
for f in failures: print('FAIL', f)
for w in warnings: print('WARN', w)
print('COVERAGE (current season per league: results, % with each statistic, upcoming fixtures):')
for lg, c in cov['leagues'].items(): print(f"  {lg} {c['season']}: {c['results']} results to {c['latest_result']}; stats % {c['with_stats_pct']}; upcoming {c['upcoming_fixtures']} to {c['fixtures_through']}; played fixtures still in file {c['played_fixtures_still_in_file']}")
for k in ('mls_date_matching', 'player_stats', 'nba', 'lineups', 'nfl', 'squads'): print(f'  {k}: {cov.get(k)}')
for n_ in cov['notes']: print('  ' + n_)
sys.exit(1 if failures else 0)
