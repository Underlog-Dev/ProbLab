#!/usr/bin/env python3
"""Validates a built PropLab site folder before anything is uploaded.
Usage: python3 owner-tools/validate.py <built-site-dir> [<live-site-dir> [<nflverse-raw-dir>]]
Writes <built-site-dir>/.validation.json ({checks, failures, warnings}) and prints a summary. Exit 1 when a check fails.
A failure means the data must not be published as it is. Nothing is repaired here."""
import csv, datetime, json, os, sys
from collections import Counter, defaultdict
from zoneinfo import ZoneInfo

SITE = sys.argv[1]; LIVE = sys.argv[2] if len(sys.argv) > 2 else None; RAW = sys.argv[3] if len(sys.argv) > 3 else None
UK = ZoneInfo('Europe/London'); TODAY = datetime.datetime.now(UK).strftime('%Y-%m-%d')
checks, failures, warnings = [0], [], []
def check(ok, label, detail=''):
    checks[0] += 1
    if not ok: failures.append(f'{label}{": " + str(detail)[:300] if detail != "" else ""}')
def load(d, f):
    try: return json.load(open(os.path.join(d, f)))
    except FileNotFoundError: return None
def ukparts(iso):
    t = datetime.datetime.fromisoformat(iso.replace('Z', '+00:00')).astimezone(UK); return t.strftime('%Y-%m-%d'), t.strftime('%H:%M')

# every JSON file parses; the manifest only points at files that exist
bad = []
for f in os.listdir(SITE):
    if f.startswith('data-') and f.endswith('.json'):
        try: json.load(open(os.path.join(SITE, f)))
        except Exception as e: bad.append(f'{f}: {e}')
check(not bad, 'all data files are valid JSON', bad)
man = load(SITE, 'data-manifest.json') or {}
files = [man.get('fixtures', {}) and man['fixtures'].get('file')] + [e['file'] for e in man.get('team_matches', []) + man.get('player_matches', [])]
miss = [f for f in files if f and not os.path.exists(os.path.join(SITE, f))]
check(not miss, 'every file named in data-manifest.json exists', miss)

# fixtures
fx = (load(SITE, 'data-fixtures.json') or {}).get('items', [])
badt = [f for f in fx if f.get('ko_utc') and ukparts(f['ko_utc']) != (f['date'], f.get('kickoff'))]
check(not badt, 'fixtures: UK date and time agree with the UTC kick-off instant', [(f['league'], f['home'], f['away'], f['date'], f.get('kickoff'), f['ko_utc']) for f in badt[:3]])
keys = Counter((f['league'], f['date'], f['home'], f['away']) for f in fx)
check(all(v == 1 for v in keys.values()), 'fixtures: no duplicates', [k for k, v in keys.items() if v > 1][:3])
nokt = [f for f in fx if f.get('kickoff') and not f.get('ko_utc')]
check(not nokt, 'fixtures: every fixture with a kick-off time has its UTC instant', [(f['league'], f['home'], f['away']) for f in nokt[:3]])
pairs = Counter((f['league'], f['home'], f['away']) for f in fx if f['league'] not in ('scotprem', 'mls') and f['date'] >= TODAY)
check(all(v == 1 for v in pairs.values()), 'fixtures: a pairing appears at most once in leagues where clubs meet once at each ground', [k for k, v in pairs.items() if v > 1][:3])
rounds = (load(SITE, 'data-fixtures.json') or {}).get('rounds', {})
untag = [f for f in fx if f['league'] in rounds and f['date'] >= TODAY and not f.get('round')]
if untag: warnings.append(f'{len(untag)} upcoming fixtures in round-calendar leagues have no round (they only appear under All Upcoming): ' + '; '.join(f"{f['league']} {f['home']} v {f['away']}" for f in untag[:5]))

# team matches
EXP = {'epl': 38, 'laliga': 38, 'seriea': 38, 'bundesliga': 34, 'ligaportugal': 34, 'eredivisie': 34, 'scotprem': 38, 'ligue1': 38, 'mls': 34}
def tm(d):
    out = {}
    for e in (load(d, 'data-manifest.json') or {}).get('team_matches', []):
        for r in (load(d, e['file']) or {'items': []})['items']: out[(e['league'], e['season'], r['date'], r['home'], r['away'])] = r
    return out
T = tm(SITE)
per = defaultdict(Counter); dup = []
for e in man.get('team_matches', []):
    items = (load(SITE, e['file']) or {'items': []})['items']
    k = Counter((r['date'], r['home'], r['away']) for r in items); dup += [(e['file'], x) for x, v in k.items() if v > 1]
    for r in items: per[(e['league'], e['season'])][r['home']] += 1; per[(e['league'], e['season'])][r['away']] += 1
check(not dup, 'results: no duplicated matches', dup[:3])
fut = [k for k in T if k[2] > TODAY]; check(not fut, 'results: no result dated in the future', fut[:3])
over = [(k, c, n) for k, cnt in per.items() for c, n in cnt.items() if n > EXP.get(k[0], 40)]
check(not over, 'results: no club has more league games than a season allows', over[:3])
bads = [k for k, r in T.items() if not (isinstance(r.get('hg'), int) and isinstance(r.get('ag'), int) and 0 <= r['hg'] <= 20 and 0 <= r['ag'] <= 20)]
check(not bads, 'results: every score is a whole number in range', bads[:3])
if LIVE:
    L = tm(LIVE); gone = [k for k in L if k not in T]
    check(not gone, 'results: no published historical match was removed', gone[:3])
    changed = [k for k in L if k in T and (L[k]['hg'], L[k]['ag']) != (T[k]['hg'], T[k]['ag'])]
    check(not changed, 'results: no published score was changed without review', changed[:3])

# MLS player rows
for e in man.get('player_matches', []):
    d = load(SITE, e['file']) or {'matches': []}
    k = Counter((m['date'], m['home'], m['away']) for m in d['matches']); check(all(v == 1 for v in k.values()), f"{e['file']}: no duplicated matches")
    badm = [(m['date'], p.get('name')) for m in d['matches'] for p in m.get('players', []) if not (isinstance(p.get('minutes'), int) and 0 <= p['minutes'] <= 130)]
    check(not badm, f"{e['file']}: minutes in range", badm[:3])

# NFL
G = (load(SITE, 'data-nfl-games.json') or {}).get('items', [])
if G:
    check(len({g['id'] for g in G}) == len(G), 'NFL: game ids unique')
    check(len({g['home'] for g in G} | {g['away'] for g in G}) == 32, 'NFL: 32 teams')
    badg = [g['id'] for g in G if g.get('ko_utc') and ukparts(g['ko_utc']) != (g['date'], g['kickoff'])]
    check(not badg, 'NFL: UK date/time agree with UTC kick-off', badg[:3])
    check(all(isinstance(g.get('week'), int) for g in G), 'NFL: every game has its official week number')
    meta = load(SITE, 'data-nfl-meta.json') or {}
    logs = {}
    for f in meta.get('files', []):
        d = load(SITE, f['file']); c = d['cols']
        for r in d['rows']: row = dict(zip(c, r)); logs[(row['pid'], row['game'])] = row
        check(len(d['rows']) == f['rows'], f"NFL: {f['file']} row count matches the meta file")
    if LIVE:
        LG = {g['id']: g for g in (load(LIVE, 'data-nfl-games.json') or {'items': []})['items']}
        lost = [i for i, g in LG.items() if g.get('final') and i not in {x['id'] for x in G}]
        check(not lost, 'NFL: no completed game was removed', lost[:3])
    if RAW:
        MAP = {'pass_yds': 'passing_yards', 'rush_yds': 'rushing_yards', 'rec': 'receptions', 'rec_yds': 'receiving_yards', 'tgt': 'targets', 'fgm': 'fg_made', 'tkl': 'def_tackles_solo'}
        num = lambda v: None if v in ('', 'NA') else float(v)
        mism, tot = [], 0
        for s in meta.get('seasons', []):
            p = os.path.join(RAW, f'stats_player_week_{s}.csv')
            if not os.path.exists(p): continue
            for r in csv.DictReader(open(p)):
                row = logs.get((r['player_id'], r['game_id']))
                if not row: continue
                for a, b in MAP.items():
                    if a in row:
                        tot += 1; rv = num(r[b])
                        if (rv is None) != (row[a] is None) or (rv is not None and abs(rv - row[a]) > 1e-9): mism.append((r['player_id'], r['game_id'], a))
        check(tot > 0 and not mism, f'NFL: published player stats equal the raw nflverse weekly stats ({tot} values)', mism[:3])

out = {'checks': checks[0], 'failures': failures, 'warnings': warnings}
json.dump(out, open(os.path.join(SITE, '.validation.json'), 'w'), indent=1)
print(f'validation: {checks[0]} checks, {len(failures)} failures, {len(warnings)} warnings')
for f in failures: print('FAIL', f)
for w in warnings: print('WARN', w)
sys.exit(1 if failures else 0)
