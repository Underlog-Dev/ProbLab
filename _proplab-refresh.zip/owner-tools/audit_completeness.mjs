// Historical completeness audit (owner request 20 Oct 2026): compares PropLab's published match files with independent records.
//   node owner-tools/audit_completeness.mjs <site-dir> <openfootball-dir> <out-dir>
// <openfootball-dir> holds openfootball football.json season files named <season>-<code>.json (e.g. 2025-26-en.1.json; CC0).
// Checks, for every competition / season / team:
//   1. structure: every club has the number of completed matches its format implies (double round robin; MLS 34 regular-season games;
//      European group stage 6, league phase 8 (Conference League 6), knockout ties two legs), duplicates, missing statistics;
//   2. reconciliation with openfootball where it publishes the season: every completed match it lists must be in PropLab with the same
//      teams, date (within 1 day) and full-time score; extra PropLab matches and half-time differences are listed; club names that do
//      not map to a PropLab club are listed separately (a mapping problem, not a missing match);
//   3. cross-competition identity: European club names that look like a PropLab league club but map to a different id.
// Writes completeness-report.json (machine-readable, team by team) and completeness-report.md (summary). Exit code 0 always; the
// report says what is unresolved.
import fs from 'fs';
import path from 'path';
import { teamSlug, normName } from './lib/teams.js';

const [SITE, OF, OUT] = process.argv.slice(2);
fs.mkdirSync(OUT, { recursive: true });
const CODE = { epl: 'en.1', laliga: 'es.1', bundesliga: 'de.1', seriea: 'it.1', ligue1: 'fr.1', ligaportugal: 'pt.1', eredivisie: 'nl.1', scotprem: 'sco.1', ucl: 'uefa.cl', championship: 'en.2', leagueone: 'en.3', leaguetwo: 'en.4', proleague: 'be.1', superlig: 'tr.1' };
const NAME = { epl: 'Premier League', laliga: 'La Liga', bundesliga: 'Bundesliga', seriea: 'Serie A', ligue1: 'Ligue 1', ligaportugal: 'Liga Portugal', eredivisie: 'Eredivisie', scotprem: 'Scottish Premiership', mls: 'MLS', ucl: 'Champions League', uel: 'Europa League', uecl: 'Conference League' , championship: 'Championship', leagueone: 'League One', leaguetwo: 'League Two', proleague: 'Belgian Pro League', superlig: 'Süper Lig', eliteserien: 'Eliteserien' };
const CUPS = new Set(['ucl', 'uel', 'uecl']);
const seasonLabel = s => `${s}-${String(s + 1).slice(2)}`;
const dayDiff = (a, b) => Math.abs(Date.parse(a) - Date.parse(b)) / 864e5;
const files = fs.readdirSync(SITE).filter(f => /^data-team-matches-[a-z0-9]+-\d{4}\.json$/.test(f)).sort();
const today = process.env.PROPLAB_NOW ? process.env.PROPLAB_NOW.slice(0, 10) : new Date().toISOString().slice(0, 10);
const report = { generated: new Date().toISOString(), as_of: today, sources: { proplab: SITE, independent: 'openfootball football.json (CC0), seasons as available' }, competitions: [], unresolved: [] };
const domSlugs = new Map(); // slug -> league (domestic)

for (const f of files) {
  const [, lg, ss] = f.match(/^data-team-matches-([a-z0-9]+)-(\d{4})\.json$/); const season = Number(ss);
  const items = JSON.parse(fs.readFileSync(path.join(SITE, f))).items;
  const teams = new Map();
  for (const r of items) for (const [n, home] of [[r.home, true], [r.away, false]]) { const k = teamSlug(n); const t = teams.get(k) || { name: n, played: 0, home: 0, away: 0, no_stats: 0 }; t.played++; home ? t.home++ : t.away++; if (r.hc == null) t.no_stats++; teams.set(k, t); if (!CUPS.has(lg)) domSlugs.set(k, lg); }
  const keyCount = new Map(); for (const r of items) { const k = `${r.date}|${teamSlug(r.home)}|${teamSlug(r.away)}`; keyCount.set(k, (keyCount.get(k) || 0) + 1); }
  const dups = [...keyCount].filter(([, v]) => v > 1).map(([k]) => k);
  const complete = items.length && items.every(r => r.date < today) && season < Number(today.slice(0, 4)) - (Number(today.slice(5, 7)) >= 7 ? 0 : 1);
  // structural expectation for a finished season
  let expectPer = null;
  // 27 Oct: Belgium plays a regular season then play-offs (clubs differ), Eliteserien adds a relegation play-off: their structure is checked
  // by validate.py's per-club counts instead; EFL leagues are plain double round robins (46 games)
  if (!CUPS.has(lg) && !['proleague', 'eliteserien'].includes(lg) && season < 2026) expectPer = lg === 'mls' ? 34 : lg === 'scotprem' ? 38 : (teams.size - 1) * 2;
  const comp = { competition: lg, name: NAME[lg], season: seasonLabel(season), matches: items.length, clubs: teams.size, duplicates: dups, finished: season < 2026, structure: 'ok', teams: [] };
  for (const [slug, t] of teams) {
    const row = { team: t.name, id: slug, played: t.played, home: t.home, away: t.away, matches_without_team_statistics: t.no_stats };
    if (expectPer != null) { row.expected = expectPer; row.missing = Math.max(0, expectPer - t.played); if (t.played !== expectPer) comp.structure = 'GAPS'; }
    if (CUPS.has(lg) && season < 2026) { const min = season >= 2024 ? (lg === 'uecl' ? 6 : 8) : 6; // group / league phase games every main-stage club plays
      const enteredLate = t.played < min && t.played % 2 === 0; row.expected_min = enteredLate ? 2 : min; // clubs dropping in for the knockout play-offs play 2+
      if (t.played < row.expected_min) { row.missing = row.expected_min - t.played; comp.structure = 'GAPS'; } }
    comp.teams.push(row);
  }
  if (CUPS.has(lg) && season < 2026) { const want = { ucl: season >= 2024 ? 189 : 125, uel: season >= 2024 ? 189 : 141, uecl: season >= 2024 ? 153 : 141 }[lg];
    comp.expected_matches = want; if (items.length !== want) comp.structure = comp.structure === 'ok' ? 'COUNT DIFFERS' : comp.structure; }
  // reconciliation with openfootball
  const of = CODE[lg] && path.join(OF, `${seasonLabel(season)}-${CODE[lg]}.json`);
  if (of && fs.existsSync(of)) {
    const clean = n => String(n).replace(/\s*\([A-Z]{3}\)\s*$/, '').trim(); // European files add the country: "Aston Villa FC (ENG)"
    const om = JSON.parse(fs.readFileSync(of)).matches.filter(m => m.score && m.score.ft && m.date <= today && !/^(Winner|Loser)/.test(m.team1)).map(m => ({ ...m, team1: clean(m.team1), team2: clean(m.team2) }));
    const pl = items.map(r => ({ r, h: teamSlug(r.home), a: teamSlug(r.away), used: false }));
    // openfootball spells clubs its own way ("FC Bayern München", "Bayern München (GER)"). A name PropLab does not know is linked to the
    // PropLab club that played the same opponent within a day in the same home / away role, when one club clearly fits (listed in the report).
    const ofNames = new Set(om.flatMap(m => [m.team1, m.team2])); const link = new Map();
    for (const n of ofNames) if (teams.has(teamSlug(n))) link.set(n, teamSlug(n));
    for (let pass = 0; pass < 4; pass++) for (const n of ofNames) { if (link.has(n)) continue; const votes = new Map(); let total = 0;
      for (const m of om) { const home = m.team1 === n; if (!home && m.team2 !== n) continue; const other = link.get(home ? m.team2 : m.team1); total++;
        for (const x of pl) { if (dayDiff(x.r.date, m.date) > 1) continue; if (other && (home ? x.a : x.h) !== other) continue; const c = home ? x.h : x.a; votes.set(c, (votes.get(c) || 0) + (other ? 3 : 1)); } }
      const best = [...votes].sort((p, q) => q[1] - p[1]); if (best.length && best[0][1] >= Math.max(3, 0.5 * total * 3) && (!best[1] || best[0][1] >= 2 * best[1][1])) link.set(n, best[0][0]); }
    const inferred = [...link].filter(([n, s]) => teamSlug(n) !== s).map(([n, s]) => ({ openfootball: n, proplab: teams.get(s)?.name, id: s }));
    const missing = [], scoreDiff = [], htDiff = [], unmatched = new Set();
    for (const m of om) {
      const h = link.get(m.team1) || teamSlug(m.team1), a = link.get(m.team2) || teamSlug(m.team2);
      if (!teams.has(h)) unmatched.add(m.team1); if (!teams.has(a)) unmatched.add(m.team2);
      const cand = pl.filter(x => !x.used && x.h === h && x.a === a).sort((x, y) => dayDiff(x.r.date, m.date) - dayDiff(y.r.date, m.date))[0];
      if (!cand || dayDiff(cand.r.date, m.date) > 3) { missing.push({ date: m.date, home: m.team1, away: m.team2, score: m.score.ft.join('-'), cause: teams.has(h) && teams.has(a) ? 'missing from PropLab' : 'team name not mapped' }); continue; }
      cand.used = true;
      if (cand.r.hg !== m.score.ft[0] || cand.r.ag !== m.score.ft[1]) scoreDiff.push({ date: m.date, home: m.team1, away: m.team2, openfootball: m.score.ft.join('-'), proplab: `${cand.r.hg}-${cand.r.ag}` });
      if (m.score.ht && cand.r.hthg != null && (cand.r.hthg !== m.score.ht[0] || cand.r.htag !== m.score.ht[1])) htDiff.push({ date: m.date, home: m.team1, away: m.team2, openfootball: m.score.ht.join('-'), proplab: `${cand.r.hthg}-${cand.r.htag}` });
    }
    const ofLast = om.reduce((mx, m) => (m.date > mx ? m.date : mx), '');
    const extra = pl.filter(x => !x.used).map(x => ({ date: x.r.date, home: x.r.home, away: x.r.away, score: `${x.r.hg}-${x.r.ag}`, note: x.r.date > ofLast ? 'after the last result openfootball lists (it is behind)' : 'not listed by openfootball with a score' }));
    comp.reconciliation = { source: `openfootball football.json ${seasonLabel(season)}/${CODE[lg]}.json`, names_linked_by_fixture: inferred, independent_completed: om.length, matched: om.length - missing.length, missing, extra_in_proplab: extra, score_differences: scoreDiff, half_time_differences: htDiff, unmatched_team_names: [...unmatched] };
    for (const m of missing) report.unresolved.push({ competition: lg, season: seasonLabel(season), ...m });
  } else comp.reconciliation = { source: null, note: 'openfootball does not publish this competition / season: structural checks only' };
  report.competitions.push(comp);
}
// cross-competition identity: European names close to a domestic club but mapped elsewhere
const toks = s => new Set(normName(s).split(' ').filter(w => w.length > 3 && !['club', 'football', 'united', 'city', 'sport', 'real'].includes(w)));
const domNames = new Map();
for (const f of files) { const [, lg] = f.match(/^data-team-matches-([a-z0-9]+)-/); if (CUPS.has(lg)) continue; for (const r of JSON.parse(fs.readFileSync(path.join(SITE, f))).items) for (const n of [r.home, r.away]) domNames.set(teamSlug(n), n); }
const suspicious = new Map();
for (const f of files) { const [, lg] = f.match(/^data-team-matches-([a-z0-9]+)-/); if (!CUPS.has(lg)) continue;
  for (const r of JSON.parse(fs.readFileSync(path.join(SITE, f))).items) for (const n of [r.home, r.away]) { const s = teamSlug(n); if (domSlugs.has(s)) continue;
    for (const [ds, dn] of domNames) { const a = toks(n), b = toks(dn); if ([...a].some(w => b.has(w))) suspicious.set(n, { european_name: n, id: s, similar_domestic: dn, domestic_id: ds }); } } }
report.identity = { european_clubs_linked_to_a_league_club: [...new Set(files.filter(f => /-(ucl|uel|uecl)-/.test(f)).flatMap(f => JSON.parse(fs.readFileSync(path.join(SITE, f))).items.flatMap(r => [teamSlug(r.home), teamSlug(r.away)])))].filter(s => domSlugs.has(s)).length, suspicious_name_overlaps: [...suspicious.values()] };
fs.writeFileSync(path.join(OUT, 'completeness-report.json'), JSON.stringify(report, null, 1));
// summary
const L = [`# PropLab completeness report (as of ${today})`, '', '| Competition | Season | Matches | Clubs | Structure | Independent check | Missing | Score differences | HT differences | Extra in PropLab |', '|---|---|---|---|---|---|---|---|---|---|'];
for (const c of report.competitions) { const r = c.reconciliation; L.push(`| ${c.name} | ${c.season} | ${c.matches}${c.expected_matches ? ' / ' + c.expected_matches : ''} | ${c.clubs} | ${c.structure}${c.duplicates.length ? ' (' + c.duplicates.length + ' duplicates)' : ''} | ${r.source ? `openfootball: ${r.matched}/${r.independent_completed} matched` : 'structure only'} | ${r.missing ? r.missing.length : '-'} | ${r.score_differences ? r.score_differences.length : '-'} | ${r.half_time_differences ? r.half_time_differences.length : '-'} | ${r.extra_in_proplab ? r.extra_in_proplab.length : '-'} |`); }
L.push('', `European clubs sharing one identity with their PropLab league club: ${report.identity.european_clubs_linked_to_a_league_club}. Name overlaps to review: ${report.identity.suspicious_name_overlaps.length}.`);
L.push('', `Unresolved missing matches: ${report.unresolved.length}.`);
fs.writeFileSync(path.join(OUT, 'completeness-report.md'), L.join('\n') + '\n');
console.log(L.join('\n'));
