#!/usr/bin/env python3
"""NBA completeness audit: team by team and season by season.

Usage: python3 nba_audit.py <site-dir> <out-dir> [--wiki-cache DIR] [--no-wiki] [--seasons 2021,2022,...]
Structure checks (PropLab's own data):
  * every completed regular season: each team plays 82 games (72 in 2020/21); every game has a final score, both team box scores
    and player box scores for both teams; the players' points add up to the team score;
  * Play-In: 6 games a season; playoffs: every series ends with a team on 4 wins; one NBA Finals;
  * duplicates (same teams, same date).
Independent reconciliation (Wikipedia team-season game logs, CC BY-SA; written by editors from NBA.com box scores, not from ESPN):
  every regular-season, Play-In and playoff game in each "<season> <team> season" article's game log must be in PropLab with the same date,
  opponent, venue and final score; the listed high scorer's points must equal that player's points in PropLab's box score.
Writes nba-completeness.json (machine-readable, per team and season) and nba-completeness.md.
"""
import json, os, re, sys, time, urllib.parse, urllib.request, unicodedata
from collections import Counter, defaultdict

UA = 'PropLab-data-refresh/1.0 (private, non-commercial statistics site; contact via GitHub underlog-dev/ProbLab)'
MONTHS = {m: i + 1 for i, m in enumerate(['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'])}
WIKI_TEAM = {'LAC': 'Los Angeles Clippers'}

def norm(s):
    s = unicodedata.normalize('NFKD', s).encode('ascii', 'ignore').decode().lower()
    return re.sub(r'[^a-z]', '', re.sub(r'\b(jr|sr|ii|iii|iv)\b\.?', '', s))

def wiki(title, cache):
    fn = os.path.join(cache, re.sub(r'[^\w]+', '_', title) + '.txt') if cache else None
    if fn and os.path.exists(fn): return open(fn, encoding='utf-8').read()
    url = 'https://en.wikipedia.org/w/index.php?' + urllib.parse.urlencode({'title': title, 'action': 'raw'})
    for i in range(4):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': UA}), timeout=40) as r: t = r.read().decode('utf-8')
            if fn: open(fn, 'w', encoding='utf-8').write(t)
            time.sleep(1.5); return t
        except Exception as e:
            if '404' in str(e): return None
            time.sleep(10 * (i + 1))
    return None

def parse_log(text, season):
    """[(kind, date, opp_name, home, pf, pa, [(high scorer, pts)])] from the {{NBA game log}} tables (preseason skipped)."""
    out, seen = [], set()
    for blk in re.split(r'\n\|-', text):
        m = re.search(r'\{\{NBA game\|id=(\d{10})\|pf=(\d+)\|pa=(\d+)', blk)
        if not m: continue
        gid, pf, pa = m.group(1), int(m.group(2)), int(m.group(3))
        kind = {'002': 'R', '004': 'P', '005': 'PI', '006': 'C'}.get(gid[:3])
        if not kind or gid in seen: continue  # NBA Cup games are listed twice (season log + NBA Cup table)
        seen.add(gid)
        win = 'cfc' in blk.split('\n', 1)[0].lower(); loss = 'fcc' in blk.split('\n', 1)[0].lower() or 'fbb' in blk.split('\n', 1)[0].lower()
        swapped = (win and pf < pa) or (loss and pf > pa)  # the row colour says win / loss: points listed the wrong way round on the page
        if swapped: pf, pa = pa, pf
        cells = [c.strip() for c in re.split(r'\n\|', '\n' + blk.split('\n', 1)[1] if '\n' in blk else blk)]
        cells = [c for c in cells if c]
        di = next((i for i, c in enumerate(cells) if re.match(r'^(January|February|March|April|May|June|July|August|September|October|November|December) \d{1,2}$', c)), None)
        if di is None: continue
        mon, day = cells[di].split(); mo = MONTHS[mon]; yr = season - 1 if mo >= 8 else season
        oc = cells[di + 1]; home = not re.match(r'^(@|at\s)', oc.strip(), re.I)
        on = re.search(r'\[\[[^|\]]*\|([^\]]+)\]\]', oc) or re.search(r'\[\[([^\]]+)\]\]', oc)
        hp = cells[di + 3] if di + 3 < len(cells) else ''
        hpv = re.search(r'\((\d+)\)', hp)
        names = [x.split('|')[0] for x in re.findall(r'\[\[([^\]]+)\]\]', hp)]
        out.append({'kind': kind, 'date': f'{yr}-{mo:02d}-{int(day):02d}', 'opp': on.group(1) if on else oc, 'home': home, 'pf': pf, 'pa': pa, 'high': (names, int(hpv.group(1)) if hpv else None), 'nba_id': gid, 'wiki_swapped': swapped})
    return out

def main():
    site, outd = sys.argv[1], sys.argv[2]
    a = sys.argv
    cache = a[a.index('--wiki-cache') + 1] if '--wiki-cache' in a else None
    if cache: os.makedirs(cache, exist_ok=True)
    meta = json.load(open(os.path.join(site, 'data-nba-meta.json')))
    G = json.load(open(os.path.join(site, 'data-nba-games.json'))); gc = G['cols']
    games = [dict(zip(gc, r)) for r in G['rows']]
    teams = {t['abbr']: t['name'] for t in meta['teams']}
    cur = meta['current_season']
    seasons = [int(x) for x in a[a.index('--seasons') + 1].split(',')] if '--seasons' in a else [s for s in meta['seasons'] if s < cur]
    # player logs: points per (game, team)
    pts = defaultdict(int); played = defaultdict(set); byname = defaultdict(dict)
    P = {p['id']: p for p in json.load(open(os.path.join(site, 'data-nba-players.json')))['items']}
    # every player box score (the source CSVs: the site's log files only keep CURRENT players, so they cannot add up to a team score)
    import csv
    raw = a[a.index('--raw') + 1] if '--raw' in a else None
    if not raw: sys.exit('--raw <download-dir with player_box_<season>.csv> is required')
    esp = {'GS': 'GSW', 'NY': 'NYK', 'SA': 'SAS', 'NO': 'NOP', 'UTAH': 'UTA', 'WSH': 'WAS'}
    for S in sorted({g['season'] for g in games}):
        fn = os.path.join(raw, f'player_box_{S}.csv')
        if not os.path.exists(fn): continue
        for r in csv.DictReader(open(fn, encoding='utf-8')):
            g, t = str(r['game_id']).split('.')[0], esp.get(r['team_abbreviation'], r['team_abbreviation'])
            if str(r.get('did_not_play')).lower() == 'true': continue
            played[(g, t)].add(r['athlete_id'])
            try: v = int(float(r['points']))
            except (TypeError, ValueError): continue
            pts[(g, t)] += v; byname[(g, t)][norm(r['athlete_display_name'])] = v
    rep = {'schema': 1, 'seasons': {}, 'teams': {}, 'summary': {}}
    issues = []
    for S in seasons:
        fin = [g for g in games if g['season'] == S and g['status'] == 'final']
        reg = [g for g in fin if g['type'] == 'R']
        cnt = Counter(); [cnt.update([g['home'], g['away']]) for g in reg]
        want = 72 if S == 2021 else 82
        short = {t: cnt[t] for t in teams if cnt[t] != want}
        dup = [k for k, v in Counter((g['date'], g['home'], g['away']) for g in fin).items() if v > 1]
        nobox = [g['id'] for g in fin if not g.get('hb') or not g.get('ab')]
        nopl = [g['id'] for g in fin if not played[(g['id'], g['home'])] or not played[(g['id'], g['away'])]]
        ptsbad = [g['id'] for g in fin if played[(g['id'], g['home'])] and (pts[(g['id'], g['home'])] != g['hs'] or pts[(g['id'], g['away'])] != g['as'])]
        pi = [g for g in fin if g['type'] == 'PI']; po = [g for g in fin if g['type'] == 'P']
        series = Counter()
        for g in po: series[(frozenset((g['home'], g['away'])), g['home'] if g['hs'] > g['as'] else g['away'])] += 1
        pairs = defaultdict(dict)
        for (pair, w), n in series.items(): pairs[pair][w] = n
        badser = [sorted(p) for p, w in pairs.items() if max(w.values()) != 4]
        rep['seasons'][str(S)] = {'label': meta['season_label'][str(S)], 'regular_games': len(reg), 'expected_regular': want * 15, 'teams_not_on_expected': short, 'play_in_games': len(pi), 'playoff_games': len(po), 'playoff_series': len(pairs),
                                  'series_without_4_wins': badser, 'duplicates': dup, 'games_without_team_box': nobox, 'games_without_player_box': nopl, 'games_where_player_points_differ_from_score': ptsbad}
        for t in teams: rep['teams'].setdefault(t, {})[str(S)] = {'regular_games': cnt[t], 'expected': want}
        if short or dup or nobox or nopl or ptsbad or badser or len(pi) != 6 or len(pairs) != 15: issues.append(f'{S}: structure issue (see JSON)')
    # ---- independent: Wikipedia team-season game logs ----
    wikirep = {}
    if '--no-wiki' not in a:
        for S in seasons:
            lab = f'{S - 1}–{str(S)[2:]}'
            for t, nm in teams.items():
                title = f'{lab} {WIKI_TEAM.get(t, nm)} season'
                txt = wiki(title, cache)
                if not txt: wikirep[f'{S}|{t}'] = {'title': title, 'status': 'page not found'}; continue
                rows = parse_log(txt, S)
                mine = [g for g in games if g['season'] == S and g['status'] == 'final' and t in (g['home'], g['away'])]
                missing, score_diff, high_diff, matched = [], [], [], 0
                from datetime import date as _d
                dd = lambda a, b: abs((_d.fromisoformat(a) - _d.fromisoformat(b)).days)
                def opp_ok(g, oppname):
                    full = teams[g['away'] if g['home'] == t else g['home']].lower(); nick = full.split()[-1]; city = full.rsplit(' ', 1)[0]
                    o = re.sub(r'^(@|at)\s*', '', oppname.lower()).replace('l.a.', 'la').strip()
                    return nick in o or (city and city in o) or o in full or (o.startswith('la ') and full.startswith(('la ', 'los angeles')) and o.split()[-1] == nick)
                used = set()
                for w in rows:
                    cand = [g for g in mine if g['id'] not in used and dd(g['date'], w['date']) <= 1 and opp_ok(g, w['opp'])]
                    cand.sort(key=lambda g: (dd(g['date'], w['date']), (g['home'] == t) != w['home']))  # same date first (teams can meet on consecutive days)
                    if not cand: missing.append(w); continue
                    g = cand[0]; used.add(g['id']); matched += 1
                    mypf, mypa = (g['hs'], g['as']) if g['home'] == t else (g['as'], g['hs'])
                    if (mypf, mypa) != (w['pf'], w['pa']): score_diff.append({'date': w['date'], 'wiki': [w['pf'], w['pa']], 'proplab': [mypf, mypa], 'game': g['id']})
                    names, hv = w['high']
                    if names and hv is not None:
                        got = [byname[(g['id'], t)].get(norm(n)) for n in names]
                        if not any(x == hv for x in got if x is not None) and any(x is not None for x in got):
                            high_diff.append({'date': w['date'], 'player': names, 'wiki_points': hv, 'proplab_points': got, 'game': g['id']})
                kinds = Counter(w['kind'] for w in rows)
                wikirep[f'{S}|{t}'] = {'title': title, 'wiki_games': len(rows), 'by_type': dict(kinds), 'matched': matched, 'missing_in_proplab': missing[:10], 'n_missing': len(missing), 'score_differences': score_diff, 'high_scorer_points_differences': high_diff}
        rep['wikipedia'] = wikirep
    tot = lambda k: sum(v.get(k, 0) if isinstance(v.get(k, 0), int) else len(v.get(k, [])) for v in wikirep.values())
    rep['summary'] = {'seasons': seasons, 'structure_issues': issues, 'wiki_pages_checked': sum(1 for v in wikirep.values() if 'wiki_games' in v), 'wiki_pages_missing': [v['title'] for v in wikirep.values() if 'wiki_games' not in v],
                      'wiki_games': tot('wiki_games'), 'matched': tot('matched'), 'missing_in_proplab': tot('n_missing'), 'score_differences': tot('score_differences'), 'high_scorer_differences': tot('high_scorer_points_differences')}
    os.makedirs(outd, exist_ok=True)
    json.dump(rep, open(os.path.join(outd, 'nba-completeness.json'), 'w'), indent=1)
    s = rep['summary']
    md = [f"# NBA completeness audit\n", f"Seasons: {', '.join(meta['season_label'][str(x)] for x in seasons)}\n", '## Structure (PropLab data)\n', '| Season | Regular games | Teams not on 82 (72) | Play-In | Playoff games / series | Series not ending on 4 wins | No team box | No player box | Player points ≠ score |', '|---|---|---|---|---|---|---|---|---|']
    for S, v in rep['seasons'].items():
        md.append(f"| {v['label']} | {v['regular_games']} / {v['expected_regular']} | {v['teams_not_on_expected'] or 'none'} | {v['play_in_games']} | {v['playoff_games']} / {v['playoff_series']} | {v['series_without_4_wins'] or 'none'} | {len(v['games_without_team_box'])} | {len(v['games_without_player_box'])} | {len(v['games_where_player_points_differ_from_score'])} |")
    md += ['', '## Independent check: Wikipedia team-season game logs', '', f"Pages checked: {s['wiki_pages_checked']} (missing: {s['wiki_pages_missing'] or 'none'}). Games listed: {s['wiki_games']}; matched in PropLab: {s['matched']}; missing in PropLab: {s['missing_in_proplab']}; final-score differences: {s['score_differences']}; high-scorer points differences: {s['high_scorer_differences']}.", '']
    for k, v in sorted(wikirep.items()):
        if v.get('n_missing') or v.get('score_differences') or v.get('high_scorer_points_differences'):
            md.append(f"- {v['title']}: missing {v.get('n_missing')}, score diffs {len(v.get('score_differences', []))}, high-scorer diffs {len(v.get('high_scorer_points_differences', []))}")
    open(os.path.join(outd, 'nba-completeness.md'), 'w').write('\n'.join(md) + '\n')
    print(json.dumps(s, indent=1))

if __name__ == '__main__':
    main()
