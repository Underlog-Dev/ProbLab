#!/usr/bin/env python3
"""NBA results top-up from ESPN (Update 67, owner 11 Nov 2026).

PropLab's NBA source (sportsdataverse, built from ESPN) publishes once a day at an irregular time (12:55 UK on 10 Nov, 17:19 on 9 Nov), so
last night's games could stay "scheduled" until the next evening and bets on them stayed pending. This step runs just before nba-build.py:
for each regular-season / play-off / play-in game of the current season that has kicked off (at least 2.5 hours ago, within the last 4 days)
and is not final in the downloaded files, it reads ESPN's public game summary (site.api.espn.com, the same publisher the source is built
from, same game and player ids). Only a game ESPN marks completed is added:
  * its schedule row becomes final with the score and quarter scores;
  * one team box row per team and one player box row per player (DNPs kept as DNPs) are appended to the downloaded CSVs, in the source's
    own columns, so nba-build.py treats them exactly like the source (including its check that player points add up to the score).
Nothing is invented: a figure ESPN does not give stays empty (missing), quarter points / first-quarter rebounds and assists stay missing
until the play-by-play arrives with the next source update, and once the source has the game it is used instead (this step only fills
games the source does not have as final). Any download problem leaves that game as it was.

Usage: nba_espn_patch.py <download dir> <season> [--now ISO] [--summary-url URL-with-{id}]
Prints one JSON line: {"checked": n, "filled": [...], "not_final": [...], "errors": [...]}.
"""
import csv, json, os, sys, time, urllib.request
from datetime import datetime, timedelta, timezone

URL = 'https://site.api.espn.com/apis/site/v2/sports/basketball/nba/summary?event={id}'
UA = {'User-Agent': 'PropLab data refresh (personal research site)'}


def get(url, tries=3):
    err = ''
    for i in range(tries):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=30) as r: return json.load(r), ''
        except Exception as e:  # noqa: BLE001
            err = str(e)
            if '404' in err: break
            time.sleep((3, 10, 0)[i])
    return None, err


def split(v):
    """'14-22' -> (14, 22); '' -> (None, None)."""
    try: a, b = str(v).split('-'); return int(a), int(b)
    except Exception: return None, None


def intv(v):
    try: return int(str(v).replace('+', ''))
    except Exception: return None


def main():
    d, S = sys.argv[1], int(sys.argv[2])
    now = datetime.now(timezone.utc)
    if '--now' in sys.argv: now = datetime.fromisoformat(sys.argv[sys.argv.index('--now') + 1].replace('Z', '+00:00'))
    url = sys.argv[sys.argv.index('--summary-url') + 1] if '--summary-url' in sys.argv else URL
    sp, tp, pp = (os.path.join(d, f) for f in (f'nba_schedule_{S}.csv', f'team_box_{S}.csv', f'player_box_{S}.csv'))
    out = {'checked': 0, 'filled': [], 'not_final': [], 'errors': []}
    if not os.path.exists(sp): print(json.dumps(out)); return
    sched = list(csv.DictReader(open(sp, encoding='utf-8', newline=''))); sf = list(sched[0].keys()) if sched else []
    def rd(p): return (list(csv.DictReader(open(p, encoding='utf-8', newline=''))), None) if os.path.exists(p) else ([], None)
    trows, _ = rd(tp); prows, _ = rd(pp)
    tf = list(trows[0].keys()) if trows else ['game_id', 'season', 'season_type', 'game_date', 'team_id', 'team_abbreviation', 'team_score', 'field_goals_made', 'field_goals_attempted',
          'three_point_field_goals_made', 'three_point_field_goals_attempted', 'free_throws_made', 'free_throws_attempted', 'total_rebounds', 'offensive_rebounds', 'defensive_rebounds',
          'assists', 'steals', 'blocks', 'turnovers', 'total_turnovers', 'fouls']
    pf = list(prows[0].keys()) if prows else ['game_id', 'season', 'season_type', 'game_date', 'athlete_id', 'athlete_display_name', 'team_abbreviation', 'minutes', 'field_goals_made',
          'field_goals_attempted', 'three_point_field_goals_made', 'three_point_field_goals_attempted', 'free_throws_made', 'free_throws_attempted', 'offensive_rebounds',
          'defensive_rebounds', 'rebounds', 'assists', 'steals', 'blocks', 'turnovers', 'fouls', 'plus_minus', 'points', 'starter', 'ejected', 'did_not_play', 'reason',
          'athlete_headshot_href', 'athlete_position_abbreviation']
    have_t = {str(r.get('game_id', '')).split('.')[0] for r in trows}; have_p = {str(r.get('game_id', '')).split('.')[0] for r in prows}
    changed = False
    for r in sched:
        try: st = int(float(r.get('season_type') or 0))
        except ValueError: st = 0
        if st not in (2, 3, 5) or (r.get('type_abbreviation') or '') == 'ALLSTAR' or r.get('status_type_name') == 'STATUS_FINAL': continue
        if r.get('status_type_name') in ('STATUS_POSTPONED', 'STATUS_CANCELED'): continue
        try: ko = datetime.fromisoformat((r.get('date') or '').replace('Z', '+00:00'))
        except ValueError: continue
        if ko.tzinfo is None: ko = ko.replace(tzinfo=timezone.utc)
        if not (now - timedelta(days=4) <= ko <= now - timedelta(hours=2, minutes=30)): continue
        gid = str(r.get('game_id') or r.get('id')).split('.')[0]; out['checked'] += 1
        j, err = get(url.format(id=gid))
        if not j: out['errors'].append(f'{gid}: {err[:120]}'); continue
        try:
            comp = j['header']['competitions'][0]; stt = comp['status']['type']
            if not stt.get('completed') or stt.get('name') != 'STATUS_FINAL': out['not_final'].append(gid); continue
            side = {c['homeAway']: c for c in comp['competitors']}
            H, A = side['home'], side['away']
            if H['team']['abbreviation'] != r.get('home_abbreviation') or A['team']['abbreviation'] != r.get('away_abbreviation'):
                out['errors'].append(f'{gid}: teams do not match the schedule ({A["team"]["abbreviation"]} at {H["team"]["abbreviation"]})'); continue
            hs, as_ = int(H['score']), int(A['score'])
            lq = lambda c: '[' + ', '.join(f"{{'displayValue': '{int(float(l.get('value', l.get('displayValue'))))}', 'period': {i + 1}, 'value': {float(l.get('value', l.get('displayValue')))}}}" for i, l in enumerate(c.get('linescores') or [])) + ']'
            box = j['boxscore']; tb = {t['team']['abbreviation']: {s['name']: s.get('displayValue') for s in t.get('statistics', [])} for t in box.get('teams', [])}
            players = []
            for blk in box.get('players', []):
                ab = blk['team']['abbreviation']; stat = blk['statistics'][0]; keys = stat['keys']
                for a in stat['athletes']:
                    v = dict(zip(keys, a.get('stats') or []))
                    players.append((ab, a, v))
            pts = {ab: sum(intv(v.get('points')) or 0 for t, a, v in players if t == ab and not a.get('didNotPlay')) for ab in (H['team']['abbreviation'], A['team']['abbreviation'])}
            if pts.get(H['team']['abbreviation']) != hs or pts.get(A['team']['abbreviation']) != as_:
                out['errors'].append(f'{gid}: ESPN player points do not add up to the score yet ({pts}); left for the next run'); continue
        except (KeyError, IndexError, TypeError, ValueError) as e:
            out['errors'].append(f'{gid}: unexpected ESPN summary ({e})'); continue
        r['status_type_name'] = 'STATUS_FINAL'; r['home_score'] = str(hs); r['away_score'] = str(as_)
        if 'home_linescores' in r: r['home_linescores'] = lq(H)
        if 'away_linescores' in r: r['away_linescores'] = lq(A)
        if 'status_type_completed' in r: r['status_type_completed'] = 'TRUE'
        base = {'game_id': gid, 'season': str(S), 'season_type': str(st), 'game_date': r.get('game_date', '')}
        if gid not in have_t:
            for c, ab, sc in ((H, H['team']['abbreviation'], hs), (A, A['team']['abbreviation'], as_)):
                t = tb.get(ab, {}); fg, tp3, ft = split(t.get('fieldGoalsMade-fieldGoalsAttempted')), split(t.get('threePointFieldGoalsMade-threePointFieldGoalsAttempted')), split(t.get('freeThrowsMade-freeThrowsAttempted'))
                row = {k: '' for k in tf}; row.update(base); row.update({'team_id': c['team'].get('id', ''), 'team_abbreviation': ab, 'team_score': str(sc),
                    'field_goals_made': fg[0], 'field_goals_attempted': fg[1], 'three_point_field_goals_made': tp3[0], 'three_point_field_goals_attempted': tp3[1],
                    'free_throws_made': ft[0], 'free_throws_attempted': ft[1], 'total_rebounds': t.get('totalRebounds'), 'offensive_rebounds': t.get('offensiveRebounds'),
                    'defensive_rebounds': t.get('defensiveRebounds'), 'assists': t.get('assists'), 'steals': t.get('steals'), 'blocks': t.get('blocks'),
                    'turnovers': t.get('turnovers'), 'total_turnovers': t.get('totalTurnovers'), 'fouls': t.get('fouls')})
                trows.append({k: ('' if row.get(k) is None else row.get(k)) for k in tf})
        if gid not in have_p:
            for ab, a, v in players:
                at = a['athlete']; dnp = bool(a.get('didNotPlay')); fg, tp3, ft = split(v.get('fieldGoalsMade-fieldGoalsAttempted')), split(v.get('threePointFieldGoalsMade-threePointFieldGoalsAttempted')), split(v.get('freeThrowsMade-freeThrowsAttempted'))
                row = {k: '' for k in pf}; row.update(base)
                row.update({'athlete_id': at['id'], 'athlete_display_name': at.get('displayName', ''), 'athlete_position_abbreviation': (at.get('position') or {}).get('abbreviation', ''),
                    'athlete_headshot_href': (at.get('headshot') or {}).get('href', ''), 'team_abbreviation': ab, 'starter': 'TRUE' if a.get('starter') else 'FALSE',
                    'ejected': 'TRUE' if a.get('ejected') else 'FALSE', 'did_not_play': 'TRUE' if dnp else 'FALSE', 'reason': a.get('reason', '') if dnp else ''})
                if not dnp:
                    row.update({'minutes': intv(v.get('minutes')), 'points': intv(v.get('points')), 'rebounds': intv(v.get('rebounds')), 'offensive_rebounds': intv(v.get('offensiveRebounds')),
                        'defensive_rebounds': intv(v.get('defensiveRebounds')), 'assists': intv(v.get('assists')), 'steals': intv(v.get('steals')), 'blocks': intv(v.get('blocks')),
                        'turnovers': intv(v.get('turnovers')), 'fouls': intv(v.get('fouls')), 'plus_minus': intv(v.get('plusMinus')),
                        'field_goals_made': fg[0], 'field_goals_attempted': fg[1], 'three_point_field_goals_made': tp3[0], 'three_point_field_goals_attempted': tp3[1],
                        'free_throws_made': ft[0], 'free_throws_attempted': ft[1]})
                prows.append({k: ('' if row.get(k) is None else row.get(k)) for k in pf})
        out['filled'].append({'game': gid, 'date': r.get('game_date', ''), 'match': f"{r.get('away_abbreviation')} {as_}-{hs} {r.get('home_abbreviation')}"}); changed = True
    if changed:
        for p, rows, fields in ((sp, sched, sf), (tp, trows, tf), (pp, prows, pf)):
            with open(p + '.part', 'w', encoding='utf-8', newline='') as fh:
                w = csv.DictWriter(fh, fieldnames=fields, extrasaction='ignore'); w.writeheader(); w.writerows(rows)
            os.replace(p + '.part', p)
    print(json.dumps(out))


if __name__ == '__main__':
    main()
