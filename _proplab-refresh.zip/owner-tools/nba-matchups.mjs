// Nightly: NBA team matchup tables -> data-nba-matchups.json (owner request 29 Oct 2026). Run after nba-build.py:
//   node owner-tools/nba-matchups.mjs <site-dir> [params.json]
// Uses only PropLab's own published NBA files (games with team box totals, player logs, player positions), the same calculation as the
// backtest (site/js/nbamatchups.js): this season's completed games blended with last season's, per 100 possessions, by position group.
// Ranks 1-30 for every market: DEFENCE rank 1 = allows the least (toughest matchup), 30 = allows the most (easiest); OFFENCE rank 1 =
// produces the most. params.json (from owner-tools/nba-matchup-backtest.mjs) says for which markets the model uses the matchup.
import { readFileSync, writeFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { seasonSums, buildTable, STATS, POS, COMBOS, posGroup, K_BLEND } from '../site/js/nbamatchups.js';

const SITE = process.argv[2], PARAMS = process.argv[3] || join(dirname(fileURLToPath(import.meta.url)), 'nba-matchup-params.json');
const J = f => JSON.parse(readFileSync(join(SITE, f), 'utf8'));
const meta = J('data-nba-meta.json'), G = J('data-nba-games.json'), P = J('data-nba-players.json');
const gi = Object.fromEntries(G.cols.map((c, i) => [c, i])), bx = a => (a ? Object.fromEntries(G.box_cols.map((c, i) => [c, a[i]])) : null);
const games = G.rows.filter(r => r[gi.status] === 'final' && r[gi.type] !== 'PS' && r[gi.hs] != null).map(r => ({ id: String(r[gi.id]), season: r[gi.season], date: r[gi.date], home: r[gi.home], away: r[gi.away], hb: bx(r[gi.hb]), ab: bx(r[gi.ab]) }));
const pos = new Map(P.items.map(p => [String(p.id), p.pos]));
const rowsByGame = new Map(), want = new Set(games.map(g => g.id));
for (const f of meta.files) { if (!/^data-nba-logs-/.test(f.file)) continue; const L = J(f.file), c = Object.fromEntries(L.cols.map((k, i) => [k, i]));
  for (const a of L.rows) { const g = String(a[c.game]); if (!want.has(g) || a[c.dnp] || !(a[c.min] > 0)) continue;
    const r = { game: g, team: a[c.team], pos: pos.get(String(a[c.pid])) || '' }; for (const s of STATS) r[s] = a[c[s]] ?? 0;
    if (!rowsByGame.has(g)) rowsByGame.set(g, []); rowsByGame.get(g).push(r); } }
const S = meta.current_season, cur = seasonSums(games.filter(g => g.season === S), rowsByGame), prev = seasonSums(games.filter(g => g.season === S - 1), rowsByGame);
const T = buildTable(cur, prev); if (Object.keys(T.teams).length !== 30) console.error(`note: ${Object.keys(T.teams).length} teams in the table`);
let params = {}; try { params = JSON.parse(readFileSync(PARAMS, 'utf8')); } catch { params = {}; }
// combos and ranks
const comb = (o, key) => COMBOS[key].reduce((t, s) => t + (o[s] ?? 0), 0);
const out = { schema: 1, updated: new Date().toISOString(), season: S, season_label: meta.season_label || null, k_blend: K_BLEND, games_this_season: games.filter(g => g.season === S).length,
  method: 'Per 100 possessions (possessions = FGA + 0.44 x FTA - OREB + TOV, both teams averaged), this season blended with last season: (n x this + 10 x last) / (n + 10). Position groups G, F, C from the listed positions. Defence rank 1 = allows the least; offence rank 1 = produces the most.',
  league: { pace: T.league.pace, off: {}, def: {}, dvp: { G: {}, F: {}, C: {} } }, teams: {}, params: params.markets || {} };
const keys = Object.keys(COMBOS);
for (const k of keys) { out.league.off[k] = comb(T.league.off, k); out.league.def[k] = comb(T.league.def, k); for (const q of POS) out.league.dvp[q][k] = comb(T.league.dvp[q], k); }
const known = new Set((meta.teams || []).map(x => x.abbr || x.id || x)), teams = Object.keys(T.teams).filter(t => !known.size || known.has(t));
for (const t of teams) { const x = T.teams[t]; const o = { n: x.n, pace: x.pace, off: {}, def: {}, dvp: { G: {}, F: {}, C: {} }, rank: { off: {}, def: {}, dvp: { G: {}, F: {}, C: {} }, pace: null } };
  for (const k of keys) { o.off[k] = comb(x.off, k); o.def[k] = comb(x.def, k); for (const q of POS) o.dvp[q][k] = comb(x.dvp[q], k); } out.teams[t] = o; }
const rankBy = (get, desc) => { const L = teams.map(t => [t, get(out.teams[t])]).filter(([, v]) => Number.isFinite(v)).sort((a, b) => (desc ? b[1] - a[1] : a[1] - b[1])); const r = {}; L.forEach(([t], i) => { r[t] = i + 1; }); return r; };
for (const k of keys) {
  const ro = rankBy(o => o.off[k], true), rd = rankBy(o => o.def[k], false); for (const t of teams) { out.teams[t].rank.off[k] = ro[t]; out.teams[t].rank.def[k] = rd[t]; }
  for (const q of POS) { const rq = rankBy(o => o.dvp[q][k], false); for (const t of teams) out.teams[t].rank.dvp[q][k] = rq[t]; }
}
{ const rp = rankBy(o => o.pace, true); for (const t of teams) out.teams[t].rank.pace = rp[t]; }
// per-game ranks too (per 100 x pace / 100): what most matchup tables show, and what the figures on the plays are given in
for (const t of teams) out.teams[t].rank.pg = { off: {}, def: {}, dvp: { G: {}, F: {}, C: {} } };
for (const k of keys) {
  const f = o => o.pace / 100, ro = rankBy(o => o.off[k] * f(o), true), rd = rankBy(o => o.def[k] * f(o), false);
  for (const t of teams) { out.teams[t].rank.pg.off[k] = ro[t]; out.teams[t].rank.pg.def[k] = rd[t]; }
  for (const q of POS) { const rq = rankBy(o => o.dvp[q][k] * f(o), false); for (const t of teams) out.teams[t].rank.pg.dvp[q][k] = rq[t]; }
}
const round = v => (typeof v === 'number' ? Math.round(v * 1000) / 1000 : v);
writeFileSync(join(SITE, 'data-nba-matchups.json'), JSON.stringify(out, (k, v) => round(v)));
console.log(`NBA matchups: ${teams.length} teams, season ${S} (${out.games_this_season} games so far, blended with last season), markets in the model: ${Object.entries(out.params).filter(([, v]) => v.on).map(([k]) => k).join(', ') || 'none'}`);
