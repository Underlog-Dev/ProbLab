#!/usr/bin/env python3
"""Builds PropLab's NFL data files from nflverse releases (CC-BY 4.0, https://github.com/nflverse/nflverse-data).

Usage: python3 owner-tools/nfl-build.py <nflverse-download-dir> <out-site-dir> 2023 2024 2025 2026

Inputs in <nflverse-download-dir> (all from github.com/nflverse/nflverse-data/releases):
  stats_player_week_<season>.csv   (release "stats_player")   player game logs (regular season + postseason)
  play_by_play_<season>.csv.gz      (release "pbp")            longest completion / reception / rush, touchdown scorers, first TD scorer
  roster_weekly_<season>.csv        (release "weekly_rosters") who was on a team's active roster each week; current team and status
  games.csv                         (release "schedules")      schedule, results, kick-off times (US Eastern)

Outputs: data-nfl-meta.json, data-nfl-games.json, data-nfl-players.json, data-nfl-logs-<group>.json (qb, rb, wr, te, k, def).
Rules: a game counts for a player only when nflverse has a stat row for him in that game; nothing is estimated. Missing = null, never 0.
Every derived figure is cross-checked against the stat rows (see the printed report); disagreements are listed, not hidden.
"""
import csv, gzip, json, sys, os, collections
from datetime import datetime
from zoneinfo import ZoneInfo

SRC, OUT, *SEASONS = sys.argv[1:]
SEASONS = [int(s) for s in SEASONS]
ET, UK, UTC = ZoneInfo('America/New_York'), ZoneInfo('Europe/London'), ZoneInfo('UTC')
report = collections.defaultdict(list)

TEAMS = {  # abbreviation -> (name, conference, division). Facts, not copied artwork; no logos are used.
 'ARI': ('Arizona Cardinals', 'NFC', 'West'), 'ATL': ('Atlanta Falcons', 'NFC', 'South'), 'BAL': ('Baltimore Ravens', 'AFC', 'North'), 'BUF': ('Buffalo Bills', 'AFC', 'East'),
 'CAR': ('Carolina Panthers', 'NFC', 'South'), 'CHI': ('Chicago Bears', 'NFC', 'North'), 'CIN': ('Cincinnati Bengals', 'AFC', 'North'), 'CLE': ('Cleveland Browns', 'AFC', 'North'),
 'DAL': ('Dallas Cowboys', 'NFC', 'East'), 'DEN': ('Denver Broncos', 'AFC', 'West'), 'DET': ('Detroit Lions', 'NFC', 'North'), 'GB': ('Green Bay Packers', 'NFC', 'North'),
 'HOU': ('Houston Texans', 'AFC', 'South'), 'IND': ('Indianapolis Colts', 'AFC', 'South'), 'JAX': ('Jacksonville Jaguars', 'AFC', 'South'), 'KC': ('Kansas City Chiefs', 'AFC', 'West'),
 'LV': ('Las Vegas Raiders', 'AFC', 'West'), 'LAC': ('Los Angeles Chargers', 'AFC', 'West'), 'LA': ('Los Angeles Rams', 'NFC', 'West'), 'MIA': ('Miami Dolphins', 'AFC', 'East'),
 'MIN': ('Minnesota Vikings', 'NFC', 'North'), 'NE': ('New England Patriots', 'AFC', 'East'), 'NO': ('New Orleans Saints', 'NFC', 'South'), 'NYG': ('New York Giants', 'NFC', 'East'),
 'NYJ': ('New York Jets', 'AFC', 'East'), 'PHI': ('Philadelphia Eagles', 'NFC', 'East'), 'PIT': ('Pittsburgh Steelers', 'AFC', 'North'), 'SF': ('San Francisco 49ers', 'NFC', 'West'),
 'SEA': ('Seattle Seahawks', 'NFC', 'West'), 'TB': ('Tampa Bay Buccaneers', 'NFC', 'South'), 'TEN': ('Tennessee Titans', 'AFC', 'South'), 'WAS': ('Washington Commanders', 'NFC', 'East'),
}
GROUP = {'QB': 'qb', 'RB': 'rb', 'FB': 'rb', 'WR': 'wr', 'TE': 'te', 'K': 'k', 'DL': 'def', 'LB': 'def', 'DB': 'def',
         'DE': 'def', 'DT': 'def', 'NT': 'def', 'OLB': 'def', 'ILB': 'def', 'MLB': 'def', 'CB': 'def', 'S': 'def', 'SS': 'def', 'FS': 'def'}
def group_of(pos, pgroup):
    return GROUP.get(pos) or GROUP.get(pgroup)

def i(v):
    if v is None or v == '' or v == 'NA': return None
    try: return int(float(v))
    except ValueError: return None
def f1(v):
    if v is None or v == '' or v == 'NA': return None
    try: return round(float(v), 1)
    except ValueError: return None

# ---------- schedule ----------
games = {}
for g in csv.DictReader(open(os.path.join(SRC, 'games.csv'))):
    s = int(g['season'])
    if s not in SEASONS: continue
    if g['home_team'] not in TEAMS or g['away_team'] not in TEAMS: report['schedule'].append(f"unknown team in {g['game_id']}"); continue
    ko = None
    if g['gameday'] and g['gametime']:
        local = datetime.strptime(g['gameday'] + ' ' + g['gametime'], '%Y-%m-%d %H:%M').replace(tzinfo=ET)
        ko = local.astimezone(UTC).strftime('%Y-%m-%dT%H:%M:00Z')
    uk = datetime.strptime(ko, '%Y-%m-%dT%H:%M:00Z').replace(tzinfo=UTC).astimezone(UK) if ko else None
    hs, as_ = i(g['home_score']), i(g['away_score'])
    games[g['game_id']] = {'id': g['game_id'], 'season': s, 'week': int(g['week']), 'type': 'R' if g['game_type'] == 'REG' else 'P', 'round': g['game_type'],
                           'date': uk.strftime('%Y-%m-%d') if uk else g['gameday'], 'kickoff': uk.strftime('%H:%M') if uk else '', 'ko_utc': ko, 'local_date': g['gameday'],
                           'home': g['home_team'], 'away': g['away_team'], 'hs': hs, 'as': as_, 'final': hs is not None and as_ is not None,
                           'neutral': g['location'] == 'Neutral', 'stadium': g['stadium'] or ''}

# ---------- play-by-play: longest plays and touchdown scorers ----------
longest = collections.defaultdict(dict)      # (game, player) -> {'lcmp','lrec','lrush'}
tds = collections.Counter()                  # (game, player) -> touchdowns scored (any kind, not passing)
first_td = {}                                # game -> player id of the first touchdown scorer
pbp_rec_yds, pbp_rush_yds, pbp_pass_yds = collections.Counter(), collections.Counter(), collections.Counter()
multi_lat = set()   # games with a play of two or more laterals
for s in SEASONS:
    p = os.path.join(SRC, f'play_by_play_{s}.csv.gz')
    if not os.path.exists(p): report['pbp'].append(f'{p} missing: longest plays and TD scorers unavailable for {s}'); continue
    with gzip.open(p, 'rt') as fh:
        for r in csv.DictReader(fh):
            gid = r['game_id']
            if r['play_type'] in ('no_play', '') or r.get('two_point_attempt') == '1': continue
            if r['touchdown'] == '1' and r['td_player_id'] not in ('', 'NA'):   # counted before the aborted-play filter: a fumbled snap can still end in a TD
                tds[(gid, r['td_player_id'])] += 1
                if gid not in first_td: first_td[gid] = r['td_player_id']   # file is in play order within a game
            if r.get('aborted_play') == '1': continue
            if r['complete_pass'] == '1' and r['receiver_player_id'] not in ('', 'NA'):
                ry, py = i(r['receiving_yards']), i(r['passing_yards'])
                if ry is not None:
                    k = (gid, r['receiver_player_id']); d = longest[k]; d['lrec'] = max(d.get('lrec', -999), ry); pbp_rec_yds[k] += ry
                if py is not None and r['passer_player_id'] not in ('', 'NA'):
                    k = (gid, r['passer_player_id']); d = longest[k]; d['lcmp'] = max(d.get('lcmp', -999), py); pbp_pass_yds[k] += py
            # lateral after a catch: the official stat line credits the lateral receiver with those receiving yards (cross-check only)
            lr = r.get('lateral_receiver_player_id', '')
            if lr not in ('', 'NA', None) and i(r.get('lateral_receiving_yards', '')) is not None: pbp_rec_yds[(gid, lr)] += i(r['lateral_receiving_yards'])
            if r['desc'].count('Lateral to') >= 2: multi_lat.add(gid)   # play-by-play records only the first lateral receiver
            if r['rush_attempt'] == '1' and r['rusher_player_id'] not in ('', 'NA'):
                y = i(r['rushing_yards'])
                if y is not None:
                    k = (gid, r['rusher_player_id']); d = longest[k]; d['lrush'] = max(d.get('lrush', -999), y); pbp_rush_yds[k] += y

# ---------- weekly rosters: current team/status, and active weeks ----------
roster_active = collections.defaultdict(set)   # (season, week, team) -> set(player ids on the active roster)
current = {}                                   # player id -> latest roster row
for s in SEASONS:
    p = os.path.join(SRC, f'roster_weekly_{s}.csv')
    if not os.path.exists(p): report['rosters'].append(f'{p} missing'); continue
    for r in csv.DictReader(open(p)):
        pid = r['gsis_id']
        if not pid or pid == 'NA': continue
        wk = i(r['week'])
        if r['status'] == 'ACT': roster_active[(s, wk, r['team'])].add(pid)
        key = (s, wk or 0)
        if pid not in current or key >= current[pid]['_k']:
            current[pid] = {'_k': key, 'team': r['team'], 'pos': r['position'], 'jersey': r['jersey_number'], 'status': r['status'], 'name': r['full_name']}

# ---------- player game logs ----------
COLS = ['pid', 'game', 'team', 'opp', 'home', 'season', 'week', 'type',
        'att', 'cmp', 'pass_yds', 'pass_td', 'int', 'sacked', 'lcmp',
        'car', 'rush_yds', 'rush_td', 'lrush',
        'tgt', 'rec', 'rec_yds', 'rec_td', 'lrec',
        'tds', 'ftd',
        'fgm', 'fga', 'xpm', 'xpa', 'kpts',
        'tkl', 'ast', 'sacks', 'dint', 'pd', 'tfl', 'qbh']
has_pbp = {s: os.path.exists(os.path.join(SRC, f'play_by_play_{s}.csv.gz')) for s in SEASONS}
logs = collections.defaultdict(list); seen = set(); players = {}; check = collections.Counter(); mism = []
for s in SEASONS:
    p = os.path.join(SRC, f'stats_player_week_{s}.csv')
    for r in csv.DictReader(open(p)):
        pid, gid = r['player_id'], r['game_id']
        grp = group_of(r['position'], r['position_group'])
        if not grp: continue
        g = games.get(gid)
        if not g: report['logs'].append(f'{pid} {gid}: game not in schedule; row skipped'); continue
        if (pid, gid) in seen: report['logs'].append(f'duplicate row {pid} {gid}; second copy skipped'); continue
        seen.add((pid, gid))
        team = r['team']; home = 1 if team == g['home'] else 0 if team == g['away'] else None
        if home is None: report['logs'].append(f'{pid} {gid}: team {team} not in that game; row skipped'); continue
        lg = longest.get((gid, pid), {})
        rec, car, att = i(r['receptions']), i(r['carries']), i(r['attempts'])
        # longest plays: 0 when the player had no reception / carry / completion in a game he played (settled as 0 by sportsbooks)
        lrec = lg.get('lrec') if (rec or 0) > 0 else (0 if rec == 0 else None)
        lrush = lg.get('lrush') if (car or 0) > 0 else (0 if car == 0 else None)
        cmpn = i(r['completions']); lcmp = lg.get('lcmp') if (cmpn or 0) > 0 else (0 if cmpn == 0 else None)
        if (rec or 0) > 0 and lrec is None: lrec = None; report['pbp-gaps'].append(f'{pid} {gid}: receptions but no play-by-play reception')
        fgm, xpm = i(r['fg_made']), i(r['pat_made'])
        pbp_td = tds.get((gid, pid), 0)
        stat_td = sum(i(r[c]) or 0 for c in ('rushing_tds', 'receiving_tds', 'special_teams_tds', 'def_tds', 'fumble_recovery_tds'))
        check['td_rows'] += 1; check['td_agree'] += (pbp_td == stat_td)
        if pbp_td != stat_td and len(mism) < 30: mism.append(f'{r["player_display_name"]} {gid}: play-by-play TDs {pbp_td}, stat-row TDs {stat_td}')
        if (rec or 0) > 0:
            check['recyd_rows'] += 1; ok_ry = pbp_rec_yds.get((gid, pid), 0) == (i(r['receiving_yards']) or 0); check['recyd_agree'] += ok_ry
            if not ok_ry: check['recyd_multilat' if gid in multi_lat else 'recyd_unexplained'] += 1
        row = [pid, gid, team, r['opponent_team'], home, s, int(r['week']), 'R' if r['season_type'] == 'REG' else 'P',
               att, cmpn, i(r['passing_yards']), i(r['passing_tds']), i(r['passing_interceptions']), i(r['sacks_suffered']), lcmp,
               car, i(r['rushing_yards']), i(r['rushing_tds']), lrush,
               i(r['targets']), rec, i(r['receiving_yards']), i(r['receiving_tds']), lrec,
               pbp_td if has_pbp[s] else None,
               (1 if first_td.get(gid) == pid else 0) if has_pbp[s] and g['final'] else None,
               fgm, i(r['fg_att']), xpm, i(r['pat_att']), (3 * fgm + xpm) if fgm is not None and xpm is not None else None,
               i(r['def_tackles_solo']), i(r['def_tackle_assists']), f1(r['def_sacks']), i(r['def_interceptions']), i(r['def_pass_defended']), i(r['def_tackles_for_loss']), i(r['def_qb_hits'])]
        logs[grp].append(row)
        pl = players.setdefault(pid, {'id': pid, 'name': r['player_display_name'], 'pos': r['position'], 'group': grp, 'teams': [], 'n': 0, 'last': '', 'seasons': []})
        pl['n'] += 1
        if g['date'] >= pl['last']: pl['last'] = g['date']; pl['pos'] = r['position']; pl['group'] = grp; pl['team_last'] = team
        if team not in pl['teams']: pl['teams'].append(team)
        if s not in pl['seasons']: pl['seasons'].append(s)

# a player's group can change over the years (e.g. RB -> WR): file every row under the player's latest group
moved = 0; regroup = collections.defaultdict(list)
for grp, rows in logs.items():
    for row in rows:
        g2 = players[row[0]]['group']; regroup[g2].append(row); moved += (g2 != grp)
logs = regroup
report['notes'].append(f'{moved} rows filed under the player\'s latest position group')

# games on the active roster with no stat row: listed so the site can say how many were left out (never counted as 0)
by_pid_games = collections.defaultdict(set)
for grp, rows in logs.items():
    for row in rows: by_pid_games[row[0]].add(row[1])
team_games = collections.defaultdict(list)
for g in games.values():
    if g['final']:
        team_games[(g['season'], g['week'], g['home'])].append(g['id']); team_games[(g['season'], g['week'], g['away'])].append(g['id'])
nostat = collections.defaultdict(list)
for (s, wk, team), pids in roster_active.items():
    for gid in team_games.get((s, wk, team), []):
        for pid in pids:
            if pid in players and gid not in by_pid_games[pid]: nostat[pid].append(gid)

# ---------- directory ----------
directory = []
for pid, pl in players.items():
    cur = current.get(pid, {})
    latest_season = max(pl['seasons'])
    team = cur.get('team') if cur and cur['_k'][0] == max(SEASONS) else None   # only a current-season roster entry makes a player "current"
    directory.append({'id': pid, 'name': pl['name'], 'pos': pl['pos'], 'group': pl['group'], 'team': team or pl['team_last'], 'current': bool(team),
                      'jersey': cur.get('jersey') if team else None, 'roster_status': cur.get('status') if team else None,
                      'teams': pl['teams'], 'seasons': sorted(pl['seasons']), 'n': pl['n'], 'last': pl['last'], 'nostat': sorted(nostat.get(pid, []))})
directory.sort(key=lambda d: (d['name']))

stamp = datetime.now(UTC).strftime('%Y-%m-%dT%H:%M:%SZ')
def write(name, obj):
    with open(os.path.join(OUT, name), 'w') as fh: json.dump(obj, fh, separators=(',', ':'), ensure_ascii=False)
write('data-nfl-games.json', {'schema': 1, 'updated': stamp, 'source': 'nflverse schedules (CC-BY 4.0)', 'items': sorted(games.values(), key=lambda g: (g['ko_utc'] or g['date'], g['id']))})
write('data-nfl-players.json', {'schema': 1, 'updated': stamp, 'items': directory})
files = []
BASE = COLS[:8]
GCOLS = {'qb': ['att', 'cmp', 'pass_yds', 'pass_td', 'int', 'sacked', 'lcmp', 'car', 'rush_yds', 'rush_td', 'lrush', 'tds', 'ftd'],
         'rb': ['car', 'rush_yds', 'rush_td', 'lrush', 'tgt', 'rec', 'rec_yds', 'rec_td', 'lrec', 'tds', 'ftd'],
         'k': ['fgm', 'fga', 'xpm', 'xpa', 'kpts'],
         'def': ['tkl', 'ast', 'sacks', 'dint', 'pd', 'tfl', 'qbh', 'tds']}
GCOLS['wr'] = GCOLS['te'] = GCOLS['rb']
for grp in ['qb', 'rb', 'wr', 'te', 'k', 'def']:
    cols = BASE + GCOLS[grp]; idx = [COLS.index(c) for c in cols]
    rows = [[r[j] for j in idx] for r in sorted(logs.get(grp, []), key=lambda r: (r[0], games[r[1]]['date']))]
    write(f'data-nfl-logs-{grp}.json', {'schema': 1, 'updated': stamp, 'cols': cols, 'rows': rows})
    files.append({'group': grp, 'file': f'data-nfl-logs-{grp}.json', 'rows': len(rows), 'players': len({r[0] for r in rows})})
cov = {}
for s in SEASONS:
    gs = [g for g in games.values() if g['season'] == s]
    cov[s] = {'games': len(gs), 'played': sum(g['final'] for g in gs), 'regular': sum(g['type'] == 'R' for g in gs), 'post': sum(g['type'] == 'P' for g in gs),
              'pbp': os.path.exists(os.path.join(SRC, f'play_by_play_{s}.csv.gz'))}
write('data-nfl-meta.json', {'schema': 1, 'updated': stamp, 'seasons': SEASONS, 'teams': [{'abbr': k, 'name': v[0], 'conf': v[1], 'div': v[2]} for k, v in TEAMS.items()],
                              'files': files, 'coverage': cov,
                              'checks': {'touchdowns_agree': f"{check['td_agree']}/{check['td_rows']}", 'receiving_yards_agree': f"{check['recyd_agree']}/{check['recyd_rows']}", 'receiving_yards_differ_multi_lateral_plays': check['recyd_multilat'], 'receiving_yards_differ_unexplained': check['recyd_unexplained']},
                              'sources': [{'name': 'nflverse (nflverse-data releases)', 'url': 'https://github.com/nflverse/nflverse-data', 'licence': 'CC-BY 4.0',
                                           'used_for': 'NFL player game logs, play-by-play (longest plays, touchdown scorers), weekly rosters and schedules'}]})
print(json.dumps({'games': len(games), 'players': len(directory), 'files': files, 'coverage': cov, 'checks': dict(check)}, indent=1))
for k, v in report.items(): print(k, len(v), v[:8])
print('TD mismatches (first 30):'); print('\n'.join(mism))
