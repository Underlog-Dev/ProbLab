#!/usr/bin/env python3
"""Final scores (and, for Scotland, future fixture dates) from the English Wikipedia season articles.

Why: football-data.co.uk, PropLab's source for match statistics, usually publishes weekend results one to three days late, and
openfootball later still. Wikipedia's season articles keep a results table (Module:Sports results) that editors fill in within hours of
the final whistle. Text is CC BY-SA 4.0; a score is a fact. PropLab uses only the score from it, labels the source, and replaces the
record's statistics when football-data.co.uk publishes the match (a score that disagrees is never overwritten; it is reported).

Safety rules (a wrong score is worse than a late one):
  - a score is taken only when the cell holds nothing but "N–N" (links and references stripped); cells with notes (awarded, abandoned,
    annulled, footnotes) are skipped and reported;
  - the match date must come from PropLab's own fixture calendar (fixtures file, openfootball, football-data fixtures); the score is
    taken only after kick-off + 2h30 (or, without a kick-off time, from the following UK day);
  - both team names must map to teams PropLab already knows in that league;
  - a pair already published (any date in the season, or within 7 days for Scotland where teams meet up to 4 times) is not added again.
Every run also compares Wikipedia with football-data.co.uk for matches both have, as a running reliability check.

Usage: python3 wiki_results.py <site dir> <download dir> <inputs dir> <now ISO> <report json>
Writes <inputs dir>/results-<league>-<season>-wikipedia.txt and fixtures-scotprem-wikipedia.txt, read by build-data.mjs.
"""
import datetime, glob, json, os, re, sys, time, urllib.parse, urllib.request
from zoneinfo import ZoneInfo

UK = ZoneInfo('Europe/London')
UA = 'PropLab-data-refresh/1.0 (https://underlog-dev.github.io/ProbLab/; GitHub underlog-dev/ProbLab)'
ARTICLES = {'epl': 'Premier_League', 'laliga': 'La_Liga', 'seriea': 'Serie_A', 'bundesliga': 'Bundesliga', 'ligue1': 'Ligue_1',
            'ligaportugal': 'Primeira_Liga', 'eredivisie': 'Eredivisie', 'scotprem': 'Scottish_Premiership',
            # 27 Oct 2026: the six added leagues (Eliteserien's article is named by calendar year: "2026 Eliteserien")
            'championship': 'EFL_Championship', 'leagueone': 'EFL_League_One', 'leaguetwo': 'EFL_League_Two', 'proleague': 'Belgian_Pro_League',
            'superlig': 'Süper_Lig', 'eliteserien': 'Eliteserien'}
CALENDAR_YEAR = {'eliteserien'}
OPENFOOTBALL = {'epl': 'en.1', 'laliga': 'es.1', 'seriea': 'it.1', 'bundesliga': 'de.1', 'ligue1': 'fr.1', 'ligaportugal': 'pt.1', 'eredivisie': 'nl.1', 'scotprem': 'sco.1',
                'championship': 'en.2', 'leagueone': 'en.3', 'leaguetwo': 'en.4', 'proleague': 'be.1', 'superlig': 'tr.1'}  # a missing file is simply not used
SOURCE = 'Wikipedia season article results table (CC BY-SA 4.0); final score only'
MONTHS = {m: i for i, m in enumerate(['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'], 1)}

# ---------------------------------------------------------------- names
def norm(s):
    import unicodedata
    s = unicodedata.normalize('NFD', str(s or '')).encode('ascii', 'ignore').decode().lower()
    s = re.sub(r"['’`.]", '', s); s = re.sub(r'[^a-z0-9]+', ' ', s).strip()
    return ' '.join(w for w in s.split() if w not in {'fc', 'afc', 'cf', 'sc', 'ac', 'ssc', 'ud', 'cd', 'rcd', 'sv', 'vfl', 'vfb', 'tsg', 'fsv', 'ogc', 'rc', '1', 'f', 'c', 'a', 'cp', 'calcio', 'bc'})
EXTRA = {  # Wikipedia link text -> how PropLab names the club, only where the normal comparison does not find it
    'brighton hove albion': 'brighton', 'heart of midlothian': 'hearts', 'internazionale': 'inter', 'athletic bilbao': 'athletic club', 'inter milan': 'inter', 'espanyol de barcelona': 'espanyol',
}

def fetch(title, tries=4):
    url = 'https://en.wikipedia.org/w/index.php?title=' + urllib.parse.quote(title) + '&action=raw'
    last = ''
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers={'User-Agent': UA})
            with urllib.request.urlopen(req, timeout=40) as r: return r.read().decode('utf-8'), ''
        except Exception as e:  # 429 (rate limit) and network errors: back off and retry
            last = str(e); time.sleep(5 * (i + 1))
    return None, last

def clean(cell):
    c = re.sub(r'<ref[^>]*/>|<ref[^>]*>.*?</ref>', '', cell, flags=re.S)
    c = re.sub(r'<!--.*?-->', '', c, flags=re.S)
    c = re.sub(r'\[\[[^\]|]*\|([^\]]*)\]\]', r'\1', c); c = re.sub(r'\[\[([^\]]*)\]\]', r'\1', c)
    c = re.sub(r'\{\{\s*nowrap\s*\|(.*?)\}\}', r'\1', c)
    return c.strip()

def blocks(text):
    """Each results invocation (Module:Sports results, or Module:Sports table with its match grid) is parsed on its own: Scotland's
    post-split matches reuse the same keys in a second block."""
    starts = [m.start() for m in re.finditer(r'\{\{\s*#invoke\s*:\s*[Ss]ports (?:results|table)', text)]
    out = []
    for i, s in enumerate(starts):
        e = starts[i + 1] if i + 1 < len(starts) else len(text)
        if re.search(r'\|\s*match\d*_[^\W_]+_[^\W_]+\s*=', text[s:e]): out.append(text[s:e])
    if not out and re.search(r'\|\s*match\d*_[^\W_]+_[^\W_]+\s*=', text): out = [text]
    return out

def parse_block(b, season_start, calendar_year=False):
    """-> names {code: link text}, cells [(code_home, code_away, leg, kind, value)], update text"""
    names = {k: clean(v) for k, v in re.findall(r'\|\s*name_([^\W_]+)\s*=\s*([^\n]*)', b)}
    upd = (re.findall(r'\|\s*update\s*=\s*([^\n|]*)', b) or [''])[0].strip()
    cells = []
    for leg, h, a, v in re.findall(r'\|\s*match(\d*)_([^\W_]+)_([^\W_]+)\s*=([^\n]*)', b):
        raw = v.strip(); c = clean(raw)
        if not c: continue
        if c.lower() in ('a', '—', '–', '-', 'null', 'x') or re.fullmatch(r'\{\{\s*small\s*\|\s*(tbc|tba)\s*\}\}', c, re.I): continue  # still to be played, or not applicable
        if re.fullmatch(r'(\{\{\s*small\s*\|\s*)?(p|p[–-]p|postponed)(\s*\}\})?', c, re.I): cells.append((h, a, leg or '1', 'postponed', None)); continue
        if re.search(r'\babd\b|abandon', c, re.I): cells.append((h, a, leg or '1', 'abandoned', None)); continue
        m = re.fullmatch(r'(\d{1,2})\s*[–−-]\s*(\d{1,2})', c)
        if m: cells.append((h, a, leg or '1', 'score', (int(m.group(1)), int(m.group(2))))); continue
        d = re.fullmatch(r'\{\{\s*small\s*\|\s*(\d{1,2})\s+([A-Za-z]{3})[a-z]*\s*\}\}', c)
        if d and d.group(2).lower() in MONTHS:
            mo = MONTHS[d.group(2).lower()]; y = season_start if (calendar_year or mo >= 7) else season_start + 1
            try: cells.append((h, a, leg or '1', 'date', datetime.date(y, mo, int(d.group(1))).isoformat()))
            except ValueError: cells.append((h, a, leg or '1', 'odd', raw))
            continue
        cells.append((h, a, leg or '1', 'odd', raw))
    return names, cells, upd

def season_text(lg, season_start):
    title = (f'{season_start} {ARTICLES[lg]}' if lg in CALENDAR_YEAR else f'{season_start}–{(season_start + 1) % 100:02d} {ARTICLES[lg]}').replace('_', ' ')
    text, err = fetch(title)
    if text is None: return None, title, err
    if text.lstrip().upper().startswith('#REDIRECT'):
        t2 = re.search(r'\[\[([^\]]+)\]\]', text); text, err = fetch(t2.group(1)) if t2 else (None, 'redirect')
        if text is None: return None, title, err
    if not blocks(text):  # results kept in a separate template, e.g. {{2026–27 Bundesliga table|show_matches=only}}
        t = re.search(r'\{\{\s*(\d{4}[–-]\d{2}\s[^|}]*?table)\s*\|[^}]*show_matches', text)
        if t:
            text2, err = fetch('Template:' + t.group(1).strip())
            if text2 is None: return None, title, err
            return text2, 'Template:' + t.group(1).strip(), ''
    return text, title, ''

# ---------------------------------------------------------------- PropLab's own calendar and results
def site_teams(site, lg, season):
    teams = set()
    for f in glob.glob(os.path.join(site, f'data-team-matches-{lg}-*.json')):
        for m in (json.load(open(f)).get('matches') or json.load(open(f)).get('items') or []): teams.update((m['home'], m['away']))
    for f in (json.load(open(os.path.join(site, 'data-fixtures.json'))).get('items') or []):
        if f['league'] == lg: teams.update((f['home'], f['away']))
    return teams

def tm_items(site, lg, season):
    p = os.path.join(site, f'data-team-matches-{lg}-{season}.json')
    if not os.path.exists(p): return []
    j = json.load(open(p)); return j.get('matches') or j.get('items') or []

def calendar(site, dl, inp, lg, to_site=lambda x: None):
    """(home norm, away norm) -> list of (UK date, kick-off UTC or None) from PropLab's fixture sources."""
    cal = {}
    def add(h, a, d, ko):
        k = (norm(to_site(h) or h), norm(to_site(a) or a)); v = (d, ko or None)
        if v not in cal.setdefault(k, []): cal[k].append(v)
    for f in json.load(open(os.path.join(site, 'data-fixtures.json'))).get('items') or []:
        if f['league'] == lg: add(f['home'], f['away'], f['date'], f.get('ko_utc'))
    for p in glob.glob(os.path.join(inp, 'fixtures-*.txt')):
        if p.endswith('-wikipedia.txt'): continue
        for line in open(p):
            if line.startswith('#') or not line.strip(): continue
            x = [s.strip() for s in line.rstrip('\n').split('|')]
            if len(x) >= 5 and x[0] == lg: add(x[3], x[4], x[1], x[2] or None)
    of = os.path.join(dl, f'{OPENFOOTBALL[lg]}.json') if lg in OPENFOOTBALL else ''
    if of and os.path.exists(of):  # full season incl. played matches; date is the local date (UK for England)
        for m in json.load(open(of)).get('matches', []):
            if m.get('date') and m.get('team1') and m.get('team2'): add(m['team1'], m['team2'], m['date'], None)
    return cal

# ---------------------------------------------------------------- main
def main():
    site, dl, inp, now_s, rep_path = sys.argv[1:6]
    now = datetime.datetime.fromisoformat(now_s.replace('Z', '+00:00')); today = now.astimezone(UK).date()
    season = today.year if today.month >= 7 else today.year - 1
    rep = {'leagues': {}, 'source': SOURCE}
    season0 = season
    for lg in ARTICLES:
        season = today.year if lg in CALENDAR_YEAR else season0
        L = rep['leagues'][lg] = {'added': [], 'skipped': [], 'agree': 0, 'disagree': [], 'fixtures_added': 0}
        text, title, err = season_text(lg, season)
        if text is None: L['error'] = f'{title}: {err}'; continue
        L['article'] = title
        teams = site_teams(site, lg, season); tnorm = {norm(t): t for t in teams}
        def to_site(name):
            n = norm(name)
            if n in tnorm: return tnorm[n]
            n = EXTRA.get(n, n)
            if n in tnorm: return tnorm[n]
            w = set(n.split())  # one name's words all inside the other's ("AZ" / "AZ Alkmaar"), and only one such club
            c = [t for k, t in tnorm.items() if k and (w <= set(k.split()) or set(k.split()) <= w)]
            return c[0] if len(c) == 1 else None
        cal = calendar(site, dl, inp, lg, to_site)
        pub = tm_items(site, lg, season)
        pub_by_pair = {}
        for m in pub: pub_by_pair.setdefault((norm(m['home']), norm(m['away'])), []).append(m)
        lines, fx_lines, st_lines = [], [], []
        for bi, b in enumerate(blocks(text)):
            names, cells, upd = parse_block(b, season, lg in CALENDAR_YEAR)
            L.setdefault('updated', []).append(upd)
            for h, a, leg, kind, val in cells:
                H, A = to_site(names.get(h, h)), to_site(names.get(a, a))
                label = f'{names.get(h, h)} v {names.get(a, a)}'
                if not H or not A:
                    if kind != 'date': L['skipped'].append(f'{label}: team not recognised'); continue
                    continue
                key = (norm(H), norm(A))
                if kind == 'odd': L['skipped'].append(f'{label}: cell "{val[:60]}" is not a plain score (note, award or annulment); left out'); continue
                past = [d for d, ko in cal.get(key, []) if datetime.date.fromisoformat(d) < today and (today - datetime.date.fromisoformat(d)).days <= 30
                        and not any(o.get('date') == d for o in pub_by_pair.get(key, []))]
                if kind in ('postponed', 'abandoned') or (kind == 'date' and lg != 'scotprem' and datetime.date.fromisoformat(val) > today):  # Scotland: teams meet up to 4 times, a later meeting's date proves nothing
                    for d in past:  # PropLab still lists it on a date that has passed, without a result
                        st_lines.append(f"{lg}|{d}|{H}|{A}|{'abandoned' if kind == 'abandoned' else 'postponed'}|{val if kind == 'date' else ''}")
                        L.setdefault('status', []).append(f"{d} {H} v {A}: {'abandoned' if kind == 'abandoned' else 'postponed'}{' (Wikipedia now lists ' + val + ')' if kind == 'date' else ''}")
                if kind in ('postponed', 'abandoned'): continue
                if kind == 'date':
                    if lg == 'scotprem' and datetime.date.fromisoformat(val) >= today: fx_lines.append(f'scotprem|{val}||{H}|{A}||Wikipedia season article (CC BY-SA 4.0), date only: kick-off time to be confirmed')
                    continue
                hg, ag = val
                olds = pub_by_pair.get(key, [])
                if olds:  # already published: reliability check against football-data.co.uk / ASA, never a change
                    for o in olds:
                        if o.get('hg') is None: continue
                        if (o['hg'], o['ag']) == (hg, ag): L['agree'] += 1
                        elif lg != 'scotprem': L['disagree'].append(f"{H} v {A}: Wikipedia {hg}-{ag}, published {o['hg']}-{o['ag']} ({o['date']})")
                    if lg != 'scotprem' or any(o.get('hg') == hg and o.get('ag') == ag for o in olds): continue
                # the date: from PropLab's calendar, the latest listed meeting that has already been played
                cands = sorted(cal.get(key, []), key=lambda x: x[0])
                played = []
                for d, ko in cands:
                    dd = datetime.date.fromisoformat(d)
                    if ko: ok = datetime.datetime.fromisoformat(ko.replace('Z', '+00:00')) + datetime.timedelta(hours=2, minutes=30) <= now
                    else: ok = dd < today
                    if ok and (today - dd).days <= 45: played.append(d)
                if lg == 'scotprem': played = [d for d in played if not any(abs((datetime.date.fromisoformat(o['date']) - datetime.date.fromisoformat(d)).days) <= 7 for o in olds)]
                if not played: L['skipped'].append(f'{H} v {A} {hg}-{ag}: no played date in PropLab\'s calendar (within 45 days); left out'); continue
                if len(set(played)) > 1 and lg != 'scotprem': L['skipped'].append(f'{H} v {A}: more than one possible date {played}; left out'); continue
                d = played[-1]
                lines.append(f'{d}|{H}|{A}|{hg}|{ag}|{SOURCE}'); L['added'].append(f'{d} {H} {hg}-{ag} {A}')
        if lines:
            open(os.path.join(inp, f'results-{lg}-{season}-wikipedia.txt'), 'w').write(f'# {lg} {season}: final scores from {title} ({SOURCE}). date|home|away|HG|AG|source\n' + '\n'.join(sorted(set(lines))) + '\n')
        if st_lines:
            open(os.path.join(inp, f'fixture-status-{lg}-wikipedia.txt'), 'w').write('# league|date|home|away|status|new date (from Wikipedia)\n' + '\n'.join(sorted(set(st_lines))) + '\n')
        if fx_lines:
            open(os.path.join(inp, 'fixtures-scotprem-wikipedia.txt'), 'w').write('# league|local date (UK)|kickoff UTC (blank = time not yet set)|home|away|venue|source\n' + '\n'.join(sorted(set(fx_lines))) + '\n')
            L['fixtures_added'] = len(set(fx_lines))
        time.sleep(1)  # be gentle with Wikipedia
    json.dump(rep, open(rep_path, 'w'), indent=1, ensure_ascii=False)
    for lg, L in rep['leagues'].items():
        print(f"{lg}: {'ERROR ' + L['error'] if 'error' in L else ''} added {len(L['added'])}, agree {L['agree']}, disagree {len(L['disagree'])}, skipped {len(L['skipped'])}, fixtures {L['fixtures_added']}, status {len(L.get('status', []))}")

if __name__ == '__main__':
    main()
