#!/usr/bin/env python3
"""Builds PropLab's NBA data files from sportsdataverse / hoopR NBA data (CC BY 4.0, source ESPN):
https://github.com/sportsdataverse/sportsdataverse-data/releases (tags espn_nba_schedules, espn_nba_team_boxscores,
espn_nba_player_boxscores, espn_nba_rosters, espn_nba_pbp).

Usage: python3 nba-build.py <download-dir> <site-dir> [--now ISO]
<download-dir> holds, for every season S (hoopR numbering: 2026 = the 2025/26 season):
  nba_schedule_S.csv, team_box_S.csv, player_box_S.csv, pbp_S.json (from nba_pbp.py), and rosters_<current>.csv.
Writes into <site-dir>:
  data-nba-meta.json      teams, seasons, files, sources, build time
  data-nba-games.json     every regular-season, NBA Cup final, Play-In and playoff game (preseason and All-Star games are not
                          imported): UTC tip-off, official (US) game date, score, quarter scores, team box totals
  data-nba-players.json   every player with a box-score line in the seasons held, his current team (latest box score, else the
                          published roster), his teams by date, last season's averages and the Popular Players flag
  data-nba-logs-<TEAM>.json  the complete game logs (all seasons, whichever team) of the players currently on that team's roster
                          (data-nba-logs-FA.json: players on no current roster)
Rules: nothing is filled in. A DNP is stored as a DNP (no statistics). Minutes the source did not record stay null. Quarter
points come from play-by-play and are kept only when they add up to the player's box-score points.
"""
import csv, json, os, sys, ast, re
from collections import defaultdict, Counter
from datetime import datetime, timezone, timedelta

ESPN2NBA = {'GS': 'GSW', 'NY': 'NYK', 'SA': 'SAS', 'NO': 'NOP', 'UTAH': 'UTA', 'WSH': 'WAS'}
TEAMS = {  # NBA tricode -> (name, conference, division). Conference / division alignment unchanged since 2004/05.
  'ATL': ('Atlanta Hawks', 'East', 'Southeast'), 'BOS': ('Boston Celtics', 'East', 'Atlantic'), 'BKN': ('Brooklyn Nets', 'East', 'Atlantic'),
  'CHA': ('Charlotte Hornets', 'East', 'Southeast'), 'CHI': ('Chicago Bulls', 'East', 'Central'), 'CLE': ('Cleveland Cavaliers', 'East', 'Central'),
  'DAL': ('Dallas Mavericks', 'West', 'Southwest'), 'DEN': ('Denver Nuggets', 'West', 'Northwest'), 'DET': ('Detroit Pistons', 'East', 'Central'),
  'GSW': ('Golden State Warriors', 'West', 'Pacific'), 'HOU': ('Houston Rockets', 'West', 'Southwest'), 'IND': ('Indiana Pacers', 'East', 'Central'),
  'LAC': ('LA Clippers', 'West', 'Pacific'), 'LAL': ('Los Angeles Lakers', 'West', 'Pacific'), 'MEM': ('Memphis Grizzlies', 'West', 'Southwest'),
  'MIA': ('Miami Heat', 'East', 'Southeast'), 'MIL': ('Milwaukee Bucks', 'East', 'Central'), 'MIN': ('Minnesota Timberwolves', 'West', 'Northwest'),
  'NOP': ('New Orleans Pelicans', 'West', 'Southwest'), 'NYK': ('New York Knicks', 'East', 'Atlantic'), 'OKC': ('Oklahoma City Thunder', 'West', 'Northwest'),
  'ORL': ('Orlando Magic', 'East', 'Southeast'), 'PHI': ('Philadelphia 76ers', 'East', 'Atlantic'), 'PHX': ('Phoenix Suns', 'West', 'Pacific'),
  'POR': ('Portland Trail Blazers', 'West', 'Northwest'), 'SAC': ('Sacramento Kings', 'West', 'Pacific'), 'SAS': ('San Antonio Spurs', 'West', 'Southwest'),
  'TOR': ('Toronto Raptors', 'East', 'Atlantic'), 'UTA': ('Utah Jazz', 'West', 'Northwest'), 'WAS': ('Washington Wizards', 'East', 'Southeast'),
}
ROUND = {'RD16': 'First Round', 'QTR': 'Conference Semifinals', 'SEMI': 'Conference Finals', 'FINAL': 'NBA Finals'}
LOG_COLS = ['pid', 'game', 'team', 'min', 'pts', 'reb', 'oreb', 'dreb', 'ast', 'stl', 'blk', 'tov', 'pf', 'fgm', 'fga', 'tpm', 'tpa', 'ftm', 'fta', 'pm', 'st', 'q1', 'q2', 'q3', 'q4', 'ot', 'reb1h', 'ast1h', 'dnp']
STATS = [('pts', 'points'), ('reb', 'rebounds'), ('oreb', 'offensive_rebounds'), ('dreb', 'defensive_rebounds'), ('ast', 'assists'), ('stl', 'steals'), ('blk', 'blocks'),
         ('tov', 'turnovers'), ('pf', 'fouls'), ('fgm', 'field_goals_made'), ('fga', 'field_goals_attempted'), ('tpm', 'three_point_field_goals_made'),
         ('tpa', 'three_point_field_goals_attempted'), ('ftm', 'free_throws_made'), ('fta', 'free_throws_attempted'), ('pm', 'plus_minus')]

def tri(a): a = (a or '').strip(); return ESPN2NBA.get(a, a)
def num(x):
    if x is None: return None
    x = str(x).strip()
    if x == '' or x.lower() in ('nan', 'na', 'none', '--'): return None
    try: f = float(x)
    except ValueError: return None
    return int(f) if f == int(f) else round(f, 1)
def truthy(x): return str(x).strip().lower() in ('true', '1', 't', 'yes')
def linescores(s):
    """'[{'displayValue': '23', 'period': 1, 'value': 23.0} ...]' (R list printed by the source) -> [23, 19, ...]"""
    if not s or s in ('NA', 'nan'): return None
    vals = re.findall(r"'value':\s*([0-9.]+)", s)
    return [int(float(v)) for v in vals] if vals else None
def rd(path): return list(csv.DictReader(open(path, encoding='utf-8', newline='')))

def main():
    dl, site = sys.argv[1], sys.argv[2]
    now = datetime.now(timezone.utc)
    if '--now' in sys.argv: now = datetime.fromisoformat(sys.argv[sys.argv.index('--now') + 1].replace('Z', '+00:00'))
    seasons = sorted(int(f[13:17]) for f in os.listdir(dl) if f.startswith('nba_schedule_') and f.endswith('.csv'))
    cur = max(seasons)
    games, gix = [], {}
    problems = []
    # ---------------- games ----------------
    for S in seasons:
        for r in rd(os.path.join(dl, f'nba_schedule_{S}.csv')):
            st, ab = num(r.get('season_type')), r.get('type_abbreviation') or ''
            h, a = tri(r.get('home_abbreviation')), tri(r.get('away_abbreviation'))
            if st not in (2, 3, 5) or ab == 'ALLSTAR': continue  # preseason (1) and All-Star games are not NBA team history
            stat = r.get('status_type_name') or ''
            if h not in TEAMS or a not in TEAMS:
                continue  # e.g. an NBA Cup final whose teams are not known yet
            typ = 'P' if st == 3 else 'PI' if st == 5 else ('C' if ab == 'CC' else 'R')
            gid = str(r.get('game_id') or r.get('id')).split('.')[0]
            final = stat == 'STATUS_FINAL'
            hs, as_ = (num(r.get('home_score')), num(r.get('away_score'))) if final else (None, None)
            hq, aq = (linescores(r.get('home_linescores')), linescores(r.get('away_linescores'))) if final else (None, None)
            if final and hq and aq and (sum(hq) != hs or sum(aq) != as_): problems.append(f'{gid}: quarter scores do not add up to the final score (quarters dropped)'); hq = aq = None
            g = {'id': gid, 'season': S, 'type': typ, 'date': (r.get('game_date') or '')[:10], 'ko_utc': (r.get('date') or '').replace('Z', ':00Z') if truthy(r.get('time_valid')) else None,
                 'home': h, 'away': a, 'status': 'final' if final else 'postponed' if stat == 'STATUS_POSTPONED' else 'canceled' if stat == 'STATUS_CANCELED' else 'scheduled',
                 'hs': hs, 'as': as_}
            if g['ko_utc'] and len(g['ko_utc']) == 17: g['ko_utc'] = g['ko_utc'][:16] + ':00Z'
            if hq and aq: g['hq'], g['aq'] = hq, aq
            if typ in ('P', 'PI'): g['round'] = r.get('notes_headline') or ROUND.get(ab, 'Playoffs')
            if typ == 'C': g['round'] = 'NBA Cup Championship'
            if truthy(r.get('neutral_site')): g['neutral'] = 1
            if gid in gix: continue
            gix[gid] = g; games.append(g)
    # historical postponed fixtures were replayed under a new game id: drop the stale postponed copies of past seasons
    games = [g for g in games if not (g['status'] in ('postponed', 'canceled') and g['season'] < cur)]
    gix = {g['id']: g for g in games}
    # ---------------- team box totals ----------------
    TB = [('reb', 'total_rebounds'), ('oreb', 'offensive_rebounds'), ('ast', 'assists'), ('stl', 'steals'), ('blk', 'blocks'), ('tov', 'total_turnovers'), ('pf', 'fouls'),
          ('fgm', 'field_goals_made'), ('fga', 'field_goals_attempted'), ('tpm', 'three_point_field_goals_made'), ('tpa', 'three_point_field_goals_attempted'), ('ftm', 'free_throws_made'), ('fta', 'free_throws_attempted')]
    for S in seasons:
        p = os.path.join(dl, f'team_box_{S}.csv')
        if not os.path.exists(p): continue
        for r in rd(p):
            g = gix.get(str(r['game_id']).split('.')[0])
            if not g or g['status'] != 'final': continue
            t = tri(r.get('team_abbreviation'))
            side = 'hb' if t == g['home'] else 'ab' if t == g['away'] else None
            if not side: continue
            g[side] = [num(r.get(c)) for _, c in TB]
    TB_COLS = [k for k, _ in TB]
    # ---------------- player logs ----------------
    pbp = {}
    for S in seasons:
        f = os.path.join(dl, f'pbp_{S}.json')
        if os.path.exists(f): pbp.update(json.load(open(f))['games'])
    players = {}
    logs = defaultdict(list)
    q_ok = q_bad = 0
    for S in seasons:
        p = os.path.join(dl, f'player_box_{S}.csv')
        if not os.path.exists(p): continue
        for r in rd(p):
            gid = str(r['game_id']).split('.')[0]; g = gix.get(gid)
            if not g or g['status'] != 'final': continue
            pid = str(r['athlete_id']).split('.')[0]; t = tri(r.get('team_abbreviation'))
            if t not in (g['home'], g['away']): continue
            pl = players.setdefault(pid, {'id': pid, 'name': r.get('athlete_display_name') or '', 'pos': r.get('athlete_position_abbreviation') or '', 'headshot': r.get('athlete_headshot_href') or ''})
            if S >= max(s for s in seasons if s <= S): pl['name'] = r.get('athlete_display_name') or pl['name']
            dnp = truthy(r.get('did_not_play'))
            row = {'pid': pid, 'game': gid, 'team': t}
            if dnp:
                row['dnp'] = (r.get('reason') or 'DNP').strip().title()[:60] or 'DNP'
                for k in LOG_COLS[3:-1]: row[k] = None
            else:
                row['min'] = num(r.get('minutes'))
                for k, c in STATS: row[k] = num(r.get(c))
                row['st'] = 1 if truthy(r.get('starter')) else 0
                q = pbp.get(gid, {}).get(pid)
                if q is not None and row['pts'] is not None and sum(q[:5]) == row['pts']:
                    row.update({'q1': q[0], 'q2': q[1], 'q3': q[2], 'q4': q[3], 'ot': q[4], 'reb1h': q[5], 'ast1h': q[6]}); q_ok += 1
                elif q is None and row['pts'] == 0 and gid in pbp:
                    row.update({'q1': 0, 'q2': 0, 'q3': 0, 'q4': 0, 'ot': 0, 'reb1h': None, 'ast1h': None}); q_ok += 1  # played, scored nothing: quarter points are 0 (rebounds / assists unknown)
                else:
                    if gid in pbp: q_bad += 1
                    for k in ('q1', 'q2', 'q3', 'q4', 'ot', 'reb1h', 'ast1h'): row[k] = None
                row['dnp'] = None
            logs[pid].append(row)
    # ---------------- player box integrity: a team's player lines must add up to its score ----------------
    # Some source games carry player lines with every statistic 0 (e.g. the 2021 Play-In): those are not real figures, so every
    # statistic of that team's players in that game becomes missing (never 0). A game where one player's line is absent (the sum is
    # short but not 0) keeps the lines that exist and is listed in the meta file.
    tsum = defaultdict(int); tn = defaultdict(int)
    for rows in logs.values():
        for x in rows:
            if not x.get('dnp') and x.get('pts') is not None: tsum[(x['game'], x['team'])] += x['pts']; tn[(x['game'], x['team'])] += 1
    zeroed, short_box = [], []
    for (gid, t), n in tn.items():
        g = gix[gid]; score = g['hs'] if t == g['home'] else g['as']
        if score and tsum[(gid, t)] == 0: zeroed.append(f'{gid}:{t}')
        elif score and tsum[(gid, t)] != score: short_box.append({'game': gid, 'team': t, 'date': g['date'], 'player_points': tsum[(gid, t)], 'score': score})
    zs = set(zeroed)
    for rows in logs.values():
        for x in rows:
            if f"{x['game']}:{x['team']}" in zs and not x.get('dnp'):
                for k in LOG_COLS[3:-1]: x[k] = None
                x['bad_source'] = 1
    # ---------------- current teams, team history, new-team flag ----------------
    roster = {}
    rp = os.path.join(dl, f'rosters_{cur}.csv')
    if os.path.exists(rp):
        for r in rd(rp):
            pid = str(r['athlete_id']).split('.')[0]; t = tri(r.get('team_abbreviation'))
            if t in TEAMS: roster[pid] = t
            players.setdefault(pid, {'id': pid, 'name': r.get('display_name') or r.get('full_name') or '', 'pos': r.get('position_abbreviation') or '', 'headshot': r.get('headshot_href') or ''})
    for pid, pl in players.items():
        rows = sorted((x for x in logs.get(pid, [])), key=lambda x: (gix[x['game']]['date'], x['game']))
        stints = []
        for x in rows:
            d = gix[x['game']]['date']
            if stints and stints[-1]['team'] == x['team']: stints[-1]['to'] = d
            else: stints.append({'team': x['team'], 'from': d, 'to': d})
        last_box = rows[-1]['team'] if rows else None
        last_cur = next((x['team'] for x in reversed(rows) if gix[x['game']]['season'] == cur), None)
        team = last_cur or roster.get(pid) or None  # this season's box score beats the published roster
        pl['team'] = team
        pl['current'] = bool(team and (last_cur or pid in roster))
        pl['stints'] = stints[-8:]
        pl['seasons'] = sorted({gix[x['game']]['season'] for x in rows})
        # NEW TEAM: verified by the box scores (his last game for another team) and his current team (this season's box score or roster)
        prev = next((x for x in reversed(rows) if x['team'] != team and not (gix[x['game']]['season'] == cur and last_cur is None)), None) if team else None
        if team and prev and prev['team'] != team:
            pd_ = gix[prev['game']]['date']
            first_new = next((gix[x['game']]['date'] for x in rows if x['team'] == team and gix[x['game']]['date'] > pd_), None)
            # recent window: he has not played a game for his current team before this season (joined in the offseason or this
            # season). A trade in the middle of last season is not "new" any more: he played the rest of that season for his team.
            first_new_season = gix[next(x['game'] for x in rows if x['team'] == team and gix[x['game']]['date'] > pd_)]['season'] if first_new else None
            recent = gix[prev['game']]['season'] >= cur - 1 and (first_new is None or first_new_season == cur)
            if recent:
                pl['new_team'] = {'from': prev['team'], 'last_game_for_old': pd_, 'first_game_for_new': first_new,
                                  'evidence': 'box scores' + (' + current roster' if pid in roster and roster[pid] == team else '')}
        pl['logs_file'] = team if pl['current'] and team else 'FA'
    # ---------------- last completed season averages (regular season only) ----------------
    prev_season = max((s for s in seasons if s < cur), default=None)
    AVG = ['min', 'pts', 'reb', 'oreb', 'dreb', 'ast', 'stl', 'blk', 'tov', 'pf', 'tpm', 'tpa', 'fgm', 'fga', 'ftm', 'fta', 'q1', 'reb1h', 'ast1h']
    for pid, pl in players.items():
        for key, S in (('base', prev_season), ('now', cur), ('base2', prev_season - 1 if prev_season else None)):
            rows = [x for x in logs.get(pid, []) if not x.get('dnp') and gix[x['game']]['season'] == S and gix[x['game']]['type'] == 'R']
            if not rows: continue
            out = {'season': S, 'gp': len(rows)}
            for k in AVG:
                v = [x[k] for x in rows if x.get(k) is not None]
                out[k] = round(sum(v) / len(v), 2) if v else None
                if v and len(v) != len(rows): out[k + '_n'] = len(v)
            h1 = [x['q1'] + x['q2'] for x in rows if x.get('q1') is not None]
            out['h1'] = round(sum(h1) / len(h1), 2) if h1 else None
            pl[key] = out
    # ---------------- Popular Players (rule-based, documented on the site) ----------------
    by_team = defaultdict(list)
    for pid, pl in players.items():
        if not pl['current'] or not pl['team']: continue
        b, n = pl.get('base'), pl.get('now')
        why = None
        b2 = pl.get('base2')  # two seasons ago: a star who missed most of last season injured is still a commonly researched player
        for src, mingp in ((n, 5), (b, 20), (b2 if not b or b['gp'] < 20 else None, 40)):
            if not src or src['gp'] < mingp: continue
            lab = f"{'this season' if src is n else str(src['season'] - 1) + '/' + str(src['season'])[2:]}"
            if (src.get('pts') or 0) >= 15: why = f"{src['pts']:.1f} points a game ({lab})"; break
            if (src.get('reb') or 0) >= 9: why = f"{src['reb']:.1f} rebounds a game ({lab})"; break
            if (src.get('ast') or 0) >= 6: why = f"{src['ast']:.1f} assists a game ({lab})"; break
        pl['notable'] = bool(why); pl['prom_why'] = why or ''
        src = n if n and n['gp'] >= 5 else b
        pl['prom'] = round((src.get('pts') or 0) + 1.2 * (src.get('reb') or 0) + 1.5 * (src.get('ast') or 0), 1) if src and src['gp'] >= 5 else None
        by_team[pl['team']].append(pl)
    for t, ps in by_team.items():  # every team has at least its leading scorer marked popular
        if not any(p['notable'] for p in ps):
            best = max((p for p in ps if p.get('prom') is not None), key=lambda p: p['prom'], default=None)
            if best: best['notable'] = True; src = best.get('now') if best.get('now') and best['now']['gp'] >= 5 else best.get('base'); best['prom_why'] = f"{t}'s leading scorer ({src['pts']:.1f} points a game)"
    # ---------------- write ----------------
    os.makedirs(site, exist_ok=True)
    stamp = now.strftime('%Y-%m-%dT%H:%M:%SZ')
    games.sort(key=lambda g: (g['date'], g.get('ko_utc') or '', g['id']))
    gcols = ['id', 'season', 'type', 'date', 'ko_utc', 'home', 'away', 'status', 'hs', 'as', 'hq', 'aq', 'hb', 'ab', 'round', 'neutral']
    json.dump({'schema': 1, 'updated': stamp, 'cols': gcols, 'box_cols': TB_COLS, 'rows': [[g.get(c) for c in gcols] for g in games]}, open(os.path.join(site, 'data-nba-games.json'), 'w'), separators=(',', ':'))
    files = []
    groups = defaultdict(list)
    for pid, pl in players.items():
        # players on no current roster: only those who played in the last two seasons keep a log file (they may sign again)
        if pl['logs_file'] == 'FA' and not any(s >= cur - 1 for s in pl.get('seasons', [])): pl['logs_file'] = None; continue
        groups[pl['logs_file']].append(pid)
    for grp, pids in sorted(groups.items()):
        rows = [[x.get(c) for c in LOG_COLS] for pid in pids for x in logs.get(pid, [])]
        if not rows and grp == 'FA': continue
        fn = f'data-nba-logs-{grp}.json'
        json.dump({'schema': 1, 'updated': stamp, 'cols': LOG_COLS, 'rows': rows}, open(os.path.join(site, fn), 'w'), separators=(',', ':'))
        files.append({'group': grp, 'file': fn, 'players': len(pids), 'rows': len(rows)})
    for pl in players.values(): pl.pop('base2', None)
    pk = ['id', 'name', 'pos', 'team', 'current', 'seasons', 'stints', 'new_team', 'base', 'now', 'notable', 'prom', 'prom_why', 'logs_file', 'headshot']
    json.dump({'schema': 1, 'updated': stamp, 'items': [{k: p.get(k) for k in pk if p.get(k) is not None} for p in sorted(players.values(), key=lambda p: p['name'])]},
              open(os.path.join(site, 'data-nba-players.json'), 'w'), separators=(',', ':'))
    meta = {'schema': 1, 'updated': stamp, 'current_season': cur, 'seasons': seasons, 'season_label': {str(s): f'{s - 1}/{str(s)[2:]}' for s in seasons},
            'teams': [{'abbr': k, 'name': v[0], 'conf': v[1], 'div': v[2]} for k, v in sorted(TEAMS.items())], 'files': files,
            'counts': {'games': len(games), 'final': sum(g['status'] == 'final' for g in games), 'players': len(players),
                       'player_games': sum(len(v) for v in logs.values()), 'quarter_points_ok': q_ok, 'quarter_points_dropped': q_bad},
            'problems': problems[:50], 'player_box_all_zero_dropped': zeroed, 'player_box_short': short_box,
            'sources': [{'name': 'sportsdataverse / hoopR NBA data (ESPN), CC BY 4.0', 'url': 'https://github.com/sportsdataverse/sportsdataverse-data/releases'},
                        {'name': 'Official NBA Injury Report', 'url': 'https://official.nba.com/nba-injury-report-2026-27-season/'}]}
    json.dump(meta, open(os.path.join(site, 'data-nba-meta.json'), 'w'), indent=1)
    print(json.dumps(meta['counts']), 'files', len(files), 'problems', len(problems))

if __name__ == '__main__':
    main()
