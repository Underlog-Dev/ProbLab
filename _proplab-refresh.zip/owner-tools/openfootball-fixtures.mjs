// Converts an openfootball/football.json season file (CC0) into a PropLab fixtures-*.txt file.
// Usage: node owner-tools/openfootball-fixtures.mjs <league-key> <source-timezone> <in.json> <out.txt>
//   e.g. node owner-tools/openfootball-fixtures.mjs laliga Europe/Madrid es.1.json data-src/laliga/fixtures-laliga-openfootball.txt
// openfootball gives local kick-off times; they are converted to UTC here (the site shows UK time). Matches without a time keep a blank kick-off ("TBC").
// Only matches without a recorded score are written: results come from football-data.co.uk.
import fs from 'node:fs';
const [lg, tz, inp, outp] = process.argv.slice(2);
if (!lg || !tz || !inp || !outp) { console.error('usage: <league> <tz> <in.json> <out.txt>'); process.exit(1); }
const j = JSON.parse(fs.readFileSync(inp, 'utf8'));
// UTC instant for a wall-clock time in tz (two-pass offset correction handles DST changes)
const toUtc = (date, time) => { const guess = Date.parse(`${date}T${time}:00Z`); let t = guess;
  for (let i = 0; i < 2; i++) { const p = Object.fromEntries(new Intl.DateTimeFormat('en-GB', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(new Date(t)).map(x => [x.type, x.value]));
    const shown = Date.parse(`${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}:00Z`); t += guess - shown; }
  return new Date(t).toISOString().replace('.000Z', 'Z'); };
const ukDate = iso => new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/London' }).format(new Date(iso));
const lines = [`# league|local date (UK)|kickoff UTC (blank = time not yet set)|home|away|venue|source   (openfootball/football.json ${j.name || ''}, CC0; ${tz} times converted to UTC)`];
// Provisional times: before TV selections are announced, a schedule often lists every match of a round at the same default time
// (e.g. all ten Premier League games at 15:00). Such a round's times are not confirmed kick-offs, so they are written as TBC (blank).
const byRound = new Map(); for (const m of j.matches || []) { if (m.score?.ft) continue; if (!byRound.has(m.round)) byRound.set(m.round, []); byRound.get(m.round).push(m.time || ''); }
const provisional = new Set([...byRound].filter(([, t]) => t.length >= 6 && t[0] && t.every(x => x === t[0])).map(([r]) => r));
let n = 0, tbc = 0, prov = 0;
for (const m of j.matches || []) { if (m.score?.ft) continue;
  const time = provisional.has(m.round) ? '' : m.time; if (m.time && !time) prov++;
  const ko = time ? toUtc(m.date, time) : ''; if (!ko) tbc++;
  lines.push([lg, ko ? ukDate(ko) : m.date, ko, m.team1, m.team2, '', 'openfootball football.json (CC0)'].join('|')); n++; }
fs.writeFileSync(outp, lines.join('\n') + '\n'); console.log(`${n} fixtures written (${tbc} without a confirmed kick-off time, of which ${prov} had only a provisional round-wide default time)`);
