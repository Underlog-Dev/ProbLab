// Converts an openfootball Football.TXT season file (CC0, e.g. github.com/openfootball/europe scotland/2026-27_sco1.txt) into the
// openfootball/football.json shape read by openfootball-fixtures.mjs and openfootball-rounds.mjs. Used only when football.json has not
// published that league yet.
// Usage: node owner-tools/openfootball-txt.mjs <in.txt> <out.json>
// Nothing is guessed: a round whose matches have no date line, a round marked "TBC", and a round given as one nominal date with no
// kick-off times at all (a placeholder "matchweek date", not a real schedule) are left out and counted, never written.
import fs from 'node:fs';
const [inp, outp] = process.argv.slice(2);
if (!inp || !outp) { console.error('usage: <in.txt> <out.json>'); process.exit(1); }
const MON = { Jan: 1, Feb: 2, Mar: 3, Apr: 4, May: 5, Jun: 6, Jul: 7, Aug: 8, Sep: 9, Oct: 10, Nov: 11, Dec: 12 };
const lines = fs.readFileSync(inp, 'utf8').split(/\r?\n/);
let name = '', year = null, prevMon = 0, date = null, time = null, round = null;
const rounds = []; // { round, tbc, dates:Set, timed, matches:[] }
for (const raw of lines) {
  const l = raw.replace(/\s+$/, ''); if (!l.trim()) continue;
  if (l.startsWith('= ')) { name = l.slice(2).trim(); continue; }
  const hy = l.match(/^#\s*Dates\s+\w{3}\s+\w{3}\s+\d{1,2}\s+(\d{4})/); if (hy) { year = Number(hy[1]); continue; }
  if (l.trim().startsWith('#')) continue;
  const rh = l.match(/^\s*▪\s*(.+)$/);
  if (rh) { round = { round: rh[1].replace(/\(.*?\)/g, '').trim(), tbc: /TBC|TBD|to be confirmed/i.test(rh[1]), dates: new Set(), timed: 0, matches: [] }; rounds.push(round); date = null; time = null; continue; }
  const dl = l.match(/^\s*(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)\w*\.?\s+([A-Z][a-z]{2})\w*\s+(\d{1,2})(?:\s+(\d{4}))?\s*$/);
  if (dl && MON[dl[1]]) { const mo = MON[dl[1]]; if (dl[3]) year = Number(dl[3]); else if (year && mo < prevMon) year++; prevMon = mo;
    date = year ? `${year}-${String(mo).padStart(2, '0')}-${String(Number(dl[2])).padStart(2, '0')}` : null; time = null; if (round && date) round.dates.add(date); continue; }
  const t = l.trim(); if (!round || t.startsWith('(') || t.startsWith('[')) continue; // goal scorers, notes
  const mm = t.match(/^(?:(\d{1,2}[:.]\d{2})\s+)?(.+?)\s+(?:v|vs\.?|-|(\d+)-(\d+)(?:\s*\(\d+-\d+\))?)\s+(.+?)$/);
  if (!mm) continue;
  if (mm[1]) { time = mm[1].replace('.', ':').padStart(5, '0'); }
  let away = mm[5].trim(), ft = mm[3] != null ? [Number(mm[3]), Number(mm[4])] : null;
  const tail = away.match(/^(.*?)\s+(\d+)-(\d+)(?:\s*\(\d+-\d+\))?$/); if (tail) { away = tail[1].trim(); ft = [Number(tail[2]), Number(tail[3])]; } // "Home v Away 3-0" style
  away = away.replace(/\s*\(\*\)$/, '');
  if (time) round.timed++;
  round.matches.push({ round: round.round, date, ...(time ? { time } : {}), team1: mm[2].trim(), team2: away, ...(ft ? { score: { ft } } : {}) });
}
const out = [], left = { undated: 0, tbc: 0, nominal: 0 };
for (const r of rounds) {
  if (r.tbc) { left.tbc += r.matches.length; continue; }
  if (r.matches.some(m => !m.date)) { left.undated += r.matches.filter(m => !m.date).length; r.matches = r.matches.filter(m => m.date); }
  if (r.dates.size === 1 && r.timed === 0 && r.matches.length >= 4) { left.nominal += r.matches.length; continue; } // one placeholder date, no times
  out.push(...r.matches);
}
fs.writeFileSync(outp, JSON.stringify({ name, source: 'openfootball Football.TXT (CC0)', matches: out, left_out: left }));
console.log(`${out.length} matches written; left out: ${left.undated} without a date, ${left.tbc} in rounds marked TBC, ${left.nominal} in rounds given only one nominal date and no kick-off times`);
