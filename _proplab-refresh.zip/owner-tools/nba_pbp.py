#!/usr/bin/env python3
"""Per-player quarter scoring from NBA play-by-play (sportsdataverse / hoopR, CC BY 4.0, source ESPN).

Usage: python3 nba_pbp.py <play_by_play_<season>.csv | URL> <out.json>
Streams the CSV (a season is ~290 MB; nothing is kept in memory but the totals) and writes
  { "schema": 1, "season": <hoopR season>, "games": { "<game_id>": { "<athlete_id>": [q1, q2, q3, q4, ot, reb1h, ast1h, reb1q, ast1q, reb, ast] } } }
q1..q4 / ot = points the player scored in that period (field goals and free throws credited to him on scoring plays);
reb1h / ast1h = his rebounds and assists in the first half (quarters 1-2); reb1q / ast1q = in the first quarter (2 Nov 2026);
reb / ast = his whole-game rebounds and assists in the play-by-play, so the build can check them against the box score (a first-quarter
figure is used only when the play-by-play's whole-game count equals the box score, otherwise it is missing, never 0).
The site only uses a player's quarter figures for a game when q1+q2+q3+q4+ot equals his box-score points for that game; otherwise
the game's quarter figures are treated as missing (never 0). Team rebounds (no athlete) are ignored.
"""
import csv, io, json, sys, urllib.request
from collections import defaultdict

def rows_of(src):
    if src.startswith('http'):
        r = urllib.request.urlopen(urllib.request.Request(src, headers={'User-Agent': 'PropLab data refresh'}), timeout=600)
        return csv.DictReader(io.TextIOWrapper(r, encoding='utf-8', newline=''))
    return csv.DictReader(open(src, encoding='utf-8', newline=''))

def main():
    src, out = sys.argv[1], sys.argv[2]
    g = defaultdict(lambda: defaultdict(lambda: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]))
    season = None; n = 0
    for r in rows_of(src):
        n += 1
        gid = r.get('game_id') or ''
        if not gid: continue
        season = season or r.get('season')
        try: per = int(float(r.get('period_number') or r.get('period') or 0))
        except ValueError: continue
        if per < 1: continue
        a1 = (r.get('athlete_id_1') or '').split('.')[0]
        txt = (r.get('type_text') or '')
        if (r.get('scoring_play') or '').lower() == 'true' and a1:
            try: pts = int(float(r.get('score_value') or 0))
            except ValueError: pts = 0
            if pts > 0: g[gid][a1][min(per, 5) - 1] += pts
            a2 = (r.get('athlete_id_2') or '').split('.')[0]
            # an assisted field goal names the passer second ("X makes ... (Y assists)")
            if a2 and 'assist' in (r.get('text') or '').lower():
                x = g[gid][a2]; x[10] += 1
                if per <= 2: x[6] += 1
                if per == 1: x[8] += 1
        elif 'Rebound' in txt and a1 and 'team' not in txt.lower():
            x = g[gid][a1]; x[9] += 1
            if per <= 2: x[5] += 1
            if per == 1: x[7] += 1
    json.dump({'schema': 1, 'season': int(season) if season else None, 'rows_read': n, 'games': {k: dict(v) for k, v in g.items()}}, open(out, 'w'), separators=(',', ':'))
    print(f'{src}: {n} plays, {len(g)} games -> {out}')

if __name__ == '__main__':
    main()
