#!/usr/bin/env python3
"""International football (Update 81, owner request 13 Nov 2026): national-team fixtures, results, team statistics and per-player
match statistics from ESPN's public JSON (site.api.espn.com, the same free source PropLab already uses for NBA scores). No key, no
login, no scraping of web pages. StatsHub could not be used: it has no public API, download or reuse licence ("All rights reserved").

Usage: espn_intl.py <site dir> <cache dir> [--now ISO] [--first-year 2024] [--workers 6]

Writes into <site dir> (run BEFORE build-data.mjs, which carries these files over and builds the player index from them):
  data-matches-intl-<year>.json       player match logs (schema 1, as MLS), one file per calendar year
  data-team-matches-intl-<year>.json  team match records (schema 1)
  data-fixtures.json                  every league 'intl' fixture is replaced with ESPN's current schedule (next 21 days)
  data-manifest.json                  team_matches / player_matches entries for intl

Rules (as everywhere in PropLab): missing stays missing, never 0. A player statistic is only stored for a team in a match when the
players' numbers add up to the team's own total for that match (shots, shots on target, fouls, cards, offsides, saves, goals); in
small friendlies ESPN often records no player numbers at all, and then only the appearance and minutes are kept. Minutes are worked out
from ESPN's substitution and red-card events (90, or 120 after extra time); when those events are missing, minutes stay blank.
Only players who actually played are stored (unused substitutes are not appearances). Each finished match is downloaded once.
"""
import argparse, datetime, gzip, json, os, re, sys, time, urllib.request
from concurrent.futures import ThreadPoolExecutor
from zoneinfo import ZoneInfo

BASE = 'https://site.api.espn.com/apis/site/v2/sports/soccer'
# ESPN competition code -> (label shown on the site, competitive?)
COMPS = {
    'uefa.nations': ('UEFA Nations League', True),
    'fifa.world': ('World Cup', True),
    'fifa.worldq.uefa': ('World Cup qualifying (UEFA)', True),
    'fifa.worldq.conmebol': ('World Cup qualifying (CONMEBOL)', True),
    'fifa.worldq.concacaf': ('World Cup qualifying (CONCACAF)', True),
    'fifa.worldq.caf': ('World Cup qualifying (CAF)', True),
    'fifa.worldq.afc': ('World Cup qualifying (AFC)', True),
    'uefa.euro': ('European Championship', True),
    'uefa.euroq': ('European Championship qualifying', True),
    'conmebol.america': ('Copa América', True),
    'concacaf.nations.league': ('CONCACAF Nations League', True),
    'concacaf.gold': ('Gold Cup', True),
    'caf.nations': ('Africa Cup of Nations', True),
    'fifa.friendly': ('International friendly', False),
}
UA = {'User-Agent': 'PropLab data refresh (personal, non-commercial; github.com)', 'Accept-Encoding': 'gzip'}
UK = ZoneInfo('Europe/London')
# venue country -> time zone, for the fixture's local date (only countries with one zone; otherwise no local date is stored)
TZ = {'England': 'Europe/London', 'Scotland': 'Europe/London', 'Wales': 'Europe/London', 'Northern Ireland': 'Europe/London', 'Republic of Ireland': 'Europe/Dublin', 'Ireland': 'Europe/Dublin',
      'Netherlands': 'Europe/Amsterdam', 'Germany': 'Europe/Berlin', 'France': 'Europe/Paris', 'Spain': 'Europe/Madrid', 'Italy': 'Europe/Rome', 'Belgium': 'Europe/Brussels', 'Switzerland': 'Europe/Zurich',
      'Austria': 'Europe/Vienna', 'Czechia': 'Europe/Prague', 'Czech Republic': 'Europe/Prague', 'Slovakia': 'Europe/Bratislava', 'Poland': 'Europe/Warsaw', 'Hungary': 'Europe/Budapest', 'Slovenia': 'Europe/Ljubljana',
      'Croatia': 'Europe/Zagreb', 'Serbia': 'Europe/Belgrade', 'Bosnia-Herzegovina': 'Europe/Sarajevo', 'Montenegro': 'Europe/Podgorica', 'North Macedonia': 'Europe/Skopje', 'Albania': 'Europe/Tirane', 'Kosovo': 'Europe/Belgrade',
      'Greece': 'Europe/Athens', 'Bulgaria': 'Europe/Sofia', 'Romania': 'Europe/Bucharest', 'Moldova': 'Europe/Chisinau', 'Ukraine': 'Europe/Kyiv', 'Belarus': 'Europe/Minsk', 'Lithuania': 'Europe/Vilnius', 'Latvia': 'Europe/Riga',
      'Estonia': 'Europe/Tallinn', 'Finland': 'Europe/Helsinki', 'Sweden': 'Europe/Stockholm', 'Norway': 'Europe/Oslo', 'Denmark': 'Europe/Copenhagen', 'Iceland': 'Atlantic/Reykjavik', 'Faroe Islands': 'Atlantic/Faroe',
      'Portugal': 'Europe/Lisbon', 'Andorra': 'Europe/Andorra', 'Gibraltar': 'Europe/Gibraltar', 'Malta': 'Europe/Malta', 'Cyprus': 'Asia/Nicosia', 'Türkiye': 'Europe/Istanbul', 'Turkey': 'Europe/Istanbul', 'Georgia': 'Asia/Tbilisi',
      'Armenia': 'Asia/Yerevan', 'Azerbaijan': 'Asia/Baku', 'Israel': 'Asia/Jerusalem', 'Luxembourg': 'Europe/Luxembourg', 'Liechtenstein': 'Europe/Vaduz', 'San Marino': 'Europe/San_Marino', 'Kazakhstan': 'Asia/Almaty',
      'Morocco': 'Africa/Casablanca', 'Egypt': 'Africa/Cairo', 'Saudi Arabia': 'Asia/Riyadh', 'Qatar': 'Asia/Qatar', 'Japan': 'Asia/Tokyo', 'South Korea': 'Asia/Seoul', 'Argentina': 'America/Argentina/Buenos_Aires',
      'Uruguay': 'America/Montevideo', 'Paraguay': 'America/Asuncion', 'Colombia': 'America/Bogota', 'Peru': 'America/Lima', 'Ecuador': 'America/Guayaquil', 'Venezuela': 'America/Caracas', 'Bolivia': 'America/La_Paz',
      'Chile': 'America/Santiago', 'Costa Rica': 'America/Costa_Rica', 'Panama': 'America/Panama', 'Jamaica': 'America/Jamaica', 'Honduras': 'America/Tegucigalpa', 'Guatemala': 'America/Guatemala', 'El Salvador': 'America/El_Salvador'}

def log(*a): print(*a, file=sys.stderr, flush=True)

def get(url, tries=3):
    err = None
    for i in range(tries):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=60) as r:
                b = r.read(); b = gzip.decompress(b) if r.headers.get('Content-Encoding') == 'gzip' else b
                return json.loads(b)
        except Exception as e:  # noqa: BLE001
            err = e
            if '400' in str(e) or '404' in str(e): break
            time.sleep(2 + 4 * i)
    raise RuntimeError(f'{url}: {err}')

def num(v):
    try: return float(v)
    except (TypeError, ValueError): return None

def uk_date_time(iso):
    d = datetime.datetime.fromisoformat(iso.replace('Z', '+00:00')).astimezone(UK); return d.strftime('%Y-%m-%d'), d.strftime('%H:%M')

def pos_of(p):
    n = ((p.get('position') or {}).get('name') or '').lower(); a = ((p.get('position') or {}).get('abbreviation') or '').upper()
    if 'goalkeeper' in n or a == 'G': return 'G'
    if 'substitute' in n or a == 'SUB': return None
    if 'defender' in n or 'back' in n or a in ('D', 'CD', 'LB', 'RB'): return 'D'
    if 'midfield' in n or a.startswith('M') or a in ('DM', 'AM'): return 'M'
    if 'forward' in n or 'striker' in n or 'wing' in n or a.startswith('F') or a in ('CF', 'ST', 'LW', 'RW'): return 'F'
    return None

def minute(ev):
    m = re.match(r"\s*(\d+)", ((ev.get('clock') or {}).get('displayValue') or ''))
    return int(m.group(1)) if m else None

# player stat -> (ESPN player stat, ESPN team stat it must add up to, 'own' = same team / 'opp' = the opponent's)
CHECKS = [('shots', 'totalShots', 'totalShots', 'own'), ('shots_on_target', 'shotsOnTarget', 'shotsOnTarget', 'own'),
          ('fouls_committed', 'foulsCommitted', 'foulsCommitted', 'own'), ('fouls_drawn', 'foulsSuffered', 'foulsCommitted', 'opp'),
          ('yellow_cards', 'yellowCards', 'yellowCards', 'own'), ('red_cards', 'redCards', 'redCards', 'own'),
          ('offsides', 'offsides', 'offsides', 'own'), ('saves', 'saves', 'saves', 'own')]

def parse_summary(s, comp, eid):
    """One finished match -> (team record, player match record) or None when ESPN has no line-ups for it."""
    hc = s['header']['competitions'][0]
    comps = {c['homeAway']: c for c in hc['competitors']}
    if 'home' not in comps or 'away' not in comps: return None
    H, A = comps['home']['team']['displayName'], comps['away']['team']['displayName']
    ko = hc['date'] if hc['date'].count(':') == 2 else hc['date'].replace('Z', ':00Z')
    date, _ = uk_date_time(ko)
    tstats = {}
    for t in (s.get('boxscore') or {}).get('teams', []):
        tstats[t.get('homeAway') or ('home' if t['team']['displayName'] == H else 'away')] = {x['name']: num(x.get('displayValue')) for x in t.get('statistics', [])}
    score = {k: num(comps[k].get('score')) for k in ('home', 'away')}
    ht = {k: [num(l.get('displayValue')) for l in comps[k].get('linescores', [])] for k in ('home', 'away')}
    ref = next((o.get('displayName') for o in (s.get('gameInfo') or {}).get('officials', []) if (o.get('position') or {}).get('name') == 'Referee'), None)
    recorded = {k: bool(tstats.get(k)) and ((tstats[k].get('totalPasses') or 0) > 0 or (tstats[k].get('foulsCommitted') or 0) > 0) for k in ('home', 'away')}
    def T(side, name): v = tstats.get(side, {}).get(name); return int(v) if recorded[side] and v is not None else None
    team = {'date': date, 'ko_utc': ko, 'ko_source': 'ESPN', 'home': H, 'away': A, 'referee': ref,
            'hg': int(score['home']) if score['home'] is not None else None, 'ag': int(score['away']) if score['away'] is not None else None,
            'hthg': None, 'htag': None,
            'hs': T('home', 'totalShots'), 'as': T('away', 'totalShots'), 'hst': T('home', 'shotsOnTarget'), 'ast': T('away', 'shotsOnTarget'),
            'hf': T('home', 'foulsCommitted'), 'af': T('away', 'foulsCommitted'), 'hc': T('home', 'wonCorners'), 'ac': T('away', 'wonCorners'),
            'hy': T('home', 'yellowCards'), 'ay': T('away', 'yellowCards'), 'hr': T('home', 'redCards'), 'ar': T('away', 'redCards'),
            'source': 'ESPN', 'comp': comp, 'eid': eid, **({'neutral': True} if hc.get('neutralSite') else {})}
    # half-time score: the first-half line, only when both are present and consistent with the final score (ESPN's lines are sometimes partial)
    if ht['home'] and ht['away'] and ht['home'][0] is not None and ht['away'][0] is not None and team['hg'] is not None and team['ag'] is not None \
            and 0 <= ht['home'][0] <= team['hg'] and 0 <= ht['away'][0] <= team['ag']: team['hthg'], team['htag'] = int(ht['home'][0]), int(ht['away'][0])
    rosters = s.get('rosters') or []
    if not rosters or not any(r.get('roster') for r in rosters): return team, None
    # minutes from the substitution / red-card events
    kev = s.get('keyEvents') or []
    full = 120 if any((e.get('period') or {}).get('number', 0) > 2 and (e.get('type') or {}).get('type') not in ('end-regular-time',) for e in kev if (e.get('type') or {}).get('type') in ('substitution', 'goal', 'yellow-card', 'red-card', 'start-extra-time', 'end-extra-time')) else 90
    sub_in, sub_out, sent = {}, {}, {}
    nsubs = 0
    for e in kev:
        ty = (e.get('type') or {}).get('type'); ps = [((x.get('athlete') or {}).get('id')) for x in e.get('participants') or []]
        if ty == 'substitution' and len(ps) >= 2 and minute(e) is not None: sub_in[ps[0]] = minute(e); sub_out[ps[1]] = minute(e); nsubs += 1
        if ty in ('red-card', 'yellow-red-card') and ps and minute(e) is not None: sent[ps[0]] = minute(e)
    pm = {'date': date, 'ko_utc': ko, 'home': H, 'away': A, 'referee': ref, 'complete': True, 'source': 'ESPN', 'comp': comp, 'eid': eid, 'players': []}
    for r in rosters:
        side = r.get('homeAway'); tname = r['team']['displayName']; opp = 'away' if side == 'home' else 'home'
        played = [p for p in r.get('roster', []) if p.get('starter') or p.get('subbedIn')]
        n_in = sum(1 for p in played if p.get('subbedIn'))
        ok_minutes = n_in == sum(1 for p in played if p.get('subbedIn') and str(p['athlete']['id']) in sub_in)
        stats = {str(p['athlete']['id']): {x['name']: num(x.get('value')) for x in p.get('stats', [])} for p in played}
        good = {}
        for key, pst, tst, who in CHECKS:
            tot = T(side if who == 'own' else opp, tst)
            # ESPN leaves a goalkeeper's outfield numbers (offsides) and outfield players' saves blank: those blanks are not gaps
            grp = [p for p in played if (pos_of(p) == 'G') == (key == 'saves')] if key == 'saves' else played
            vals = [stats[str(p['athlete']['id'])].get(pst) for p in grp if not (pos_of(p) == 'G' and stats[str(p['athlete']['id'])].get(pst) is None)]
            ok = recorded[side] and tot is not None and len(vals) >= len(grp) - 1 and all(v is not None for v in vals)
            if ok and key == 'fouls_drawn':  # fouls drawn never match the opponent's fouls exactly (handballs, fouls on no one): within 3
                good[key] = abs(int(sum(vals)) - tot) <= 3 and (sum(vals) > 0 or tot == 0)
            else: good[key] = ok and int(sum(vals)) == tot
        # goals: the players' goals add up to the team's score less own goals by the opponent
        og_opp = sum((stats_o.get('ownGoals') or 0) for rr in rosters if rr.get('homeAway') == opp for stats_o in [{x['name']: num(x.get('value')) for x in p.get('stats', [])} for p in rr.get('roster', [])])
        g_vals = [stats[str(p['athlete']['id'])].get('totalGoals') for p in played]
        good['goals'] = recorded[side] and score[side] is not None and all(v is not None for v in g_vals) and int(sum(g_vals) + og_opp) == int(score[side])
        good['assists'] = good['goals'] and good['shots']
        for p in played:
            aid = str(p['athlete']['id']); st = stats[aid]
            row = {'team': tname, 'name': p['athlete'].get('displayName') or p['athlete'].get('fullName'), 'position': pos_of(p), 'started': bool(p.get('starter')), 'spid': f'espn:{aid}'}
            if ok_minutes:
                start = 0 if p.get('starter') else sub_in.get(aid)
                end = sent.get(aid, sub_out.get(aid, full))
                if start is not None and end is not None and end >= start: row['minutes'] = max(1, min(130, end - start)) if not p.get('starter') else min(130, end - start)
            for key, pst, _t, _w in CHECKS:
                if good[key] and st.get(pst) is not None and not (key == 'saves' and row['position'] != 'G'): row[key] = int(st[pst])
            if good['goals'] and st.get('totalGoals') is not None: row['goals'] = int(st['totalGoals'])
            if good['assists'] and st.get('goalAssists') is not None: row['assists'] = int(st['goalAssists'])
            pm['players'].append(row)
    return team, pm

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('site'); ap.add_argument('cache'); ap.add_argument('--now'); ap.add_argument('--first-year', type=int, default=2024)
    ap.add_argument('--workers', type=int, default=6); ap.add_argument('--days-ahead', type=int, default=21)
    a = ap.parse_args()
    now = datetime.datetime.fromisoformat(a.now) if a.now else datetime.datetime.now(datetime.timezone.utc)
    if now.tzinfo is None: now = now.replace(tzinfo=datetime.timezone.utc)
    os.makedirs(a.cache, exist_ok=True)
    years = list(range(a.first_year, now.year + 1)) + ([now.year + 1] if now.month == 12 else [])
    rd = lambda f: json.load(open(os.path.join(a.site, f))) if os.path.exists(os.path.join(a.site, f)) else None
    # what is already stored (each finished match is downloaded once)
    tm, pm = {}, {}
    for y in years:
        for it in (rd(f'data-team-matches-intl-{y}.json') or {}).get('items', []):
            if it.get('eid'): tm[it['eid']] = (y, it)
        for m in (rd(f'data-matches-intl-{y}.json') or {}).get('matches', []):
            if m.get('eid'): pm[m['eid']] = (y, m)
    events, fx, failed, req = {}, [], [], 0
    for comp in COMPS:
        for y in years:
            cp = os.path.join(a.cache, f'sb-{comp}-{y}.json')
            if y < now.year - 0 and os.path.exists(cp) and all(e['status']['type']['completed'] or e['status']['type']['state'] == 'post' for e in json.load(open(cp)).get('events', [])):
                d = json.load(open(cp))
            else:
                try: d = get(f'{BASE}/{comp}/scoreboard?dates={y}&limit=1000'); req += 1; json.dump(d, open(cp, 'w'))
                except Exception as e: failed.append(str(e)); continue  # noqa: BLE001
            for e in d.get('events', []): events[e['id']] = (comp, e)
    today_uk = now.astimezone(UK).date()
    todo = []
    for eid, (comp, e) in events.items():
        st = e['status']['type']; c = e['competitions'][0]
        if st.get('completed'):
            if eid not in tm or (eid not in pm and not tm[eid][1].get('_nolineup')): todo.append((eid, comp))
        elif st.get('state') == 'pre' and st.get('name') not in ('STATUS_POSTPONED', 'STATUS_CANCELED', 'STATUS_ABANDONED'):
            ko = e['date'] if e['date'].count(':') == 2 else e['date'].replace('Z', ':00Z')
            dt = datetime.datetime.fromisoformat(ko.replace('Z', '+00:00'))
            if not (now - datetime.timedelta(hours=3) <= dt <= now + datetime.timedelta(days=a.days_ahead)): continue
            cc = {x['homeAway']: x['team']['displayName'] for x in c['competitors']}
            if 'home' not in cc or 'away' not in cc or 'TBD' in (cc['home'], cc['away']): continue
            date, kt = uk_date_time(ko); ven = c.get('venue') or {}; country = (ven.get('address') or {}).get('country')
            f = {'league': 'intl', 'date': date, 'kickoff': kt, 'ko_utc': ko, 'home': cc['home'], 'away': cc['away'], 'referee': '', 'venue': ven.get('fullName') or '',
                 'source': f'ESPN ({COMPS[comp][0]})', 'comp': comp}
            if c.get('neutralSite'): f['neutral'] = True
            if country in TZ:
                f['local_tz'] = TZ[country]; ld = dt.astimezone(ZoneInfo(TZ[country])).strftime('%Y-%m-%d')
                if ld != date: f['local_date'] = ld
            fx.append(f)
    log(f'intl: {len(events)} events listed ({req} scoreboard requests); {len(todo)} finished matches to download; {len(fx)} upcoming fixtures')
    def one(x):
        eid, comp = x; cp = os.path.join(a.cache, f'sum-{eid}.json.gz')
        try:
            if os.path.exists(cp): s = json.load(gzip.open(cp, 'rt'))
            else:
                s = get(f'{BASE}/{comp}/summary?event={eid}'); json.dump(s, gzip.open(cp, 'wt'))
            return eid, comp, parse_summary(s, comp, eid), None
        except Exception as e: return eid, comp, None, str(e)  # noqa: BLE001
    got = 0
    with ThreadPoolExecutor(a.workers) as ex:
        for eid, comp, res, err in ex.map(one, todo):
            if err or not res: failed.append(err or f'{eid}: unreadable'); continue
            team, pmr = res; y = int(team['date'][:4]); got += 1
            if pmr is None: team['_nolineup'] = True
            tm[eid] = (y, team)
            if pmr and pmr['players']: pm[eid] = (y, pmr)
    # substitutes' positions: the position they most often start in
    from collections import Counter
    pos = {}
    for _, m in pm.values():
        for p in m['players']:
            if p.get('position'): pos.setdefault(p['spid'], Counter())[p['position']] += 1
    for _, m in pm.values():
        for p in m['players']:
            if not p.get('position') and p['spid'] in pos: p['position'] = pos[p['spid']].most_common(1)[0][0]
    stamp = now.strftime('%Y-%m-%d')
    man = rd('data-manifest.json') or {}
    man['team_matches'] = [e for e in man.get('team_matches', []) if e.get('league') != 'intl']
    man['player_matches'] = [e for e in man.get('player_matches', []) if e.get('league') != 'intl']
    for y in years:
        items = sorted((it for yy, it in tm.values() if yy == y), key=lambda r: (r['date'], r.get('ko_utc') or '', r['home']))
        if items:
            old = rd(f'data-team-matches-intl-{y}.json'); upd = old.get('updated') if old and old.get('items') == items else stamp
            json.dump({'schema': 1, 'league': 'intl', 'season': y, 'updated': upd, 'items': items}, open(os.path.join(a.site, f'data-team-matches-intl-{y}.json'), 'w'), ensure_ascii=False, separators=(',', ':'))
            man['team_matches'].append({'league': 'intl', 'season': y, 'file': f'data-team-matches-intl-{y}.json', 'count': len(items), 'through': items[-1]['date'], 'updated': upd})
        ms = sorted((m for yy, m in pm.values() if yy == y), key=lambda r: (r['date'], r.get('ko_utc') or '', r['home']))
        if ms:
            old = rd(f'data-matches-intl-{y}.json'); upd = old.get('updated') if old and old.get('matches') == ms else stamp
            json.dump({'schema': 1, 'league': 'intl', 'season': y, 'updated': upd, 'source': 'ESPN', 'matches': ms}, open(os.path.join(a.site, f'data-matches-intl-{y}.json'), 'w'), ensure_ascii=False, separators=(',', ':'))
            man['player_matches'].append({'league': 'intl', 'season': y, 'file': f'data-matches-intl-{y}.json', 'matches': len(ms), 'rows': sum(len(m['players']) for m in ms), 'through': ms[-1]['date'], 'updated': upd})
    json.dump(man, open(os.path.join(a.site, 'data-manifest.json'), 'w'), ensure_ascii=False, separators=(',', ':'))
    fxd = rd('data-fixtures.json') or {'schema': 1, 'updated': stamp, 'items': []}
    if not failed or fx:  # a failed listing never wipes the published international fixtures
        keep = [f for f in fxd.get('items', []) if f.get('league') != 'intl']
        fxd['items'] = sorted(keep + fx, key=lambda f: (f['date'], f.get('kickoff') or '')); fxd['updated'] = stamp
        json.dump(fxd, open(os.path.join(a.site, 'data-fixtures.json'), 'w'), ensure_ascii=False, separators=(',', ':'))
    rows = sum(len(m['players']) for _, m in pm.values())
    withstats = sum(1 for _, m in pm.values() for p in m['players'] if 'shots' in p)
    print(json.dumps({'events': len(events), 'downloaded': got, 'team_matches': len(tm), 'player_matches': len(pm), 'player_rows': rows, 'rows_with_shots': withstats,
                      'fixtures': len(fx), 'failed': len(failed), 'failures': failed[:5]}))
    sys.exit(1 if failed and not got and not fx else 0)

if __name__ == '__main__': main()
