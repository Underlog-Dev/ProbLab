#!/usr/bin/env python3
"""NFL injury / availability reports for the site (Milestone 5).

Usage: python3 nfl_injuries.py <nflverse-download-dir> <site-dir> [<fetched-at ISO>]
Reads injuries_<season>.csv (nflverse "injuries" release: the official NFL injury reports, CC BY 4.0), games.csv and the site's
data-nfl-players.json, and writes <site-dir>/data-nfl-injuries.json:
  { schema, updated (when the source file was fetched), source, season, latest_week, items: [ {pid, name, team, pos, week, status,
    injury, practice, game_id} ] }
Only the LATEST published report for each team is kept (one week per team), with the game it was published for. Statuses are kept exactly
as published (Out, Doubtful, Questionable). Players with no game status on that report are listed only if they appear on it (status "").
The site decides "current" vs "stale": a report is current for a game only when it was published for that game.
Injured Reserve and other roster designations come from data-nfl-players.json (weekly rosters: RES, PUP, NON, SUS...).
Nothing is inferred: a player missing from the report is "not on the latest report", never "healthy".
"""
import csv, json, os, sys
from datetime import datetime, timezone

def main():
    dl, site = sys.argv[1], sys.argv[2]
    fetched = sys.argv[3] if len(sys.argv) > 3 else datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    files = sorted(f for f in os.listdir(dl) if f.startswith('injuries_') and f.endswith('.csv'))
    if not files: sys.exit('no injuries_<season>.csv in ' + dl)
    fn = files[-1]; season = int(fn[9:13])
    rows = list(csv.DictReader(open(os.path.join(dl, fn), encoding='utf-8')))
    games = {}
    for g in csv.DictReader(open(os.path.join(dl, 'games.csv'), encoding='utf-8')):
        if g.get('season') == str(season): games[(g['week'], g['game_type'], g['home_team'])] = g['game_id']; games[(g['week'], g['game_type'], g['away_team'])] = g['game_id']
    latest = {}
    for r in rows:
        try: wk = int(r['week'])
        except ValueError: continue
        key = (r['team'], r['game_type']); t = latest.get(r['team'])
        if t is None or (r['season_type'] == 'POST', wk) > t: latest[r['team']] = (r['season_type'] == 'POST', wk)
    items = []
    for r in rows:
        t = latest.get(r['team']); wk = int(r['week']) if r['week'].isdigit() else None
        if t is None or (r['season_type'] == 'POST', wk) != t: continue
        items.append({'pid': r['gsis_id'], 'name': r['full_name'], 'team': r['team'], 'pos': r['position'], 'week': wk, 'season_type': r['season_type'],
                      'status': r['report_status'] or '', 'injury': ', '.join(x for x in (r['report_primary_injury'], r['report_secondary_injury']) if x) or r['practice_primary_injury'] or '',
                      'practice': r['practice_status'] or '', 'game_id': games.get((r['week'], r['game_type'], r['team']))})
    items.sort(key=lambda x: (x['team'], {'Out': 0, 'Doubtful': 1, 'Questionable': 2}.get(x['status'], 3), x['name']))
    out = {'schema': 1, 'updated': fetched, 'source': 'Official NFL injury reports via nflverse (CC BY 4.0)', 'season': season,
           'latest_week': max((x['week'] for x in items if x['week']), default=None), 'items': items}
    json.dump(out, open(os.path.join(site, 'data-nfl-injuries.json'), 'w'), separators=(',', ':'), ensure_ascii=False)
    print(json.dumps({'season': season, 'latest_week': out['latest_week'], 'items': len(items), 'teams': len(latest)}))

if __name__ == '__main__':
    main()
