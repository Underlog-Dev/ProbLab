#!/usr/bin/env python3
"""NFL injury / availability reports for the site (Milestone 5).

Usage: python3 nfl_injuries.py <nflverse-download-dir> <site-dir> [<fetched-at ISO>]
Reads injuries_<season>.csv (nflverse "injuries" release: the official NFL injury reports, CC BY 4.0), games.csv and the site's
data-nfl-players.json, and writes <site-dir>/data-nfl-injuries.json:
  { schema, updated (when the source file was fetched), source, season, latest_week, items: [ {pid, name, team, pos, week, status,
    injury, practice, game_id} ] }
Each team's own latest report is kept (reports come out team by team through the week). teams{} records each team's report week and game.
An older report never replaces a newer published one (checked team by team). Statuses are kept exactly
as published (Out, Doubtful, Questionable). Players with no game status on that report are listed only if they appear on it (status "").
The site decides "current" vs "stale": a report is current for a game only when it was published for that game.
Injured Reserve and other roster designations come from data-nfl-players.json (weekly rosters: RES, PUP, NON, SUS...).
Nothing is inferred: a player missing from the report is "not on the latest report", never "healthy".
"""
import csv, json, os, sys
from datetime import datetime, timezone

def main():
    dl, site = sys.argv[1], sys.argv[2]
    fetched = sys.argv[3] if len(sys.argv) > 3 else datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    files = sorted(f for f in os.listdir(dl) if f.startswith('injuries_') and f.endswith('.csv'))
    if not files: sys.exit('no injuries_<season>.csv in ' + dl)
    fn = files[-1]; season = int(fn[9:13])
    rows = list(csv.DictReader(open(os.path.join(dl, fn), encoding='utf-8')))
    games = {}
    for g in csv.DictReader(open(os.path.join(dl, 'games.csv'), encoding='utf-8')):
        if g.get('season') == str(season): games[(g['week'], g['game_type'], g['home_team'])] = g['game_id']; games[(g['week'], g['game_type'], g['away_team'])] = g['game_id']
    # Each team's own latest report (owner audit, 4 Nov). The source only lists players who ARE on a report, so a team whose newest report
    # lists nobody cannot be told apart from a team whose report is not out yet: its older report is kept and the site marks it as
    # published for an earlier game. Reports come out team by team during the week, so the league's newest week is not every team's.
    def rank(st, wk): return (1 if st == 'POST' else 0, wk)
    wk_rows = [(r, int(r['week'])) for r in rows if str(r.get('week', '')).isdigit()]
    if not wk_rows: sys.exit('the injuries file has no report weeks')
    top = max(rank(r['season_type'], w) for r, w in wk_rows); top_st = 'POST' if top[0] else 'REG'
    latest = {}
    for r, w in wk_rows:
        k = rank(r['season_type'], w)
        if r['team'] not in latest or k > latest[r['team']]: latest[r['team']] = k
    items = []
    for r, wk in wk_rows:
        t = latest.get(r['team'])
        if t is None or rank(r['season_type'], wk) != t: continue
        items.append({'pid': r['gsis_id'], 'name': r['full_name'], 'team': r['team'], 'pos': r['position'], 'week': wk, 'season_type': r['season_type'],
                      'status': r['report_status'] or '', 'injury': ', '.join(x for x in (r['report_primary_injury'], r['report_secondary_injury']) if x) or r['practice_primary_injury'] or '',
                      'practice': r['practice_status'] or '', 'game_id': games.get((r['week'], r['game_type'], r['team']))})
    # an older report never replaces a newer one already published, team by team (a stale or partial source file)
    try: prev = json.load(open(os.path.join(site, 'data-nfl-injuries.json'), encoding='utf-8'))
    except Exception: prev = None
    kept = []
    if prev and prev.get('season') == season:
        pw = {}
        for x in prev.get('items', []):
            if x.get('week') is not None: pw[x['team']] = max(pw.get(x['team'], (0, 0)), rank(x.get('season_type') or 'REG', x['week']))
        for t, k in pw.items():
            if k > latest.get(t, (-1, -1)): items = [x for x in items if x['team'] != t] + [x for x in prev['items'] if x['team'] == t]; latest[t] = k; kept.append(t)
    teams = {t: {'week': k[1], 'season_type': 'POST' if k[0] else 'REG', 'game_id': next((x['game_id'] for x in items if x['team'] == t), None), 'listed': sum(1 for x in items if x['team'] == t)} for t, k in sorted(latest.items())}
    items.sort(key=lambda x: (x['team'], {'Out': 0, 'Doubtful': 1, 'Questionable': 2}.get(x['status'], 3), x['name']))
    out = {'schema': 1, 'updated': fetched, 'source': 'Official NFL injury reports via nflverse (CC BY 4.0)', 'season': season, 'season_type': 'POST' if max(latest.values())[0] else 'REG',
           'latest_week': max(latest.values())[1], 'teams': teams, 'items': items}

    json.dump(out, open(os.path.join(site, 'data-nfl-injuries.json'), 'w'), separators=(',', ':'), ensure_ascii=False)
    print(json.dumps({'season': season, 'latest_week': out['latest_week'], 'items': len(items), 'teams': len(teams), 'teams_on_latest_week': sum(1 for v in teams.values() if v['week'] == out['latest_week']), 'kept_newer_published': kept}))

if __name__ == '__main__':
    main()
