#!/usr/bin/env python3
"""NFL Player Prominence (Milestone 5) for the "Popular Players Only" filter and the "Prominence" sort.

Usage: python3 nfl_prominence.py <site-dir>
Reads data-nfl-players.json and data-nfl-logs-{qb,rb,wr,te}.json in <site-dir> and adds three fields to every player in
data-nfl-players.json (rewritten in place):
  prom       production per game, half-PPR style, from the better of this season (2+ games) and last season (4+ games, x0.9);
             null when neither season has enough regular-season games
  notable    true for a player on a current roster who is an established part of his offence (see RULES); false otherwise
  prom_why   one short reason, shown on the site ("2025: 27% of DAL targets")

This is NOT a measure of public popularity (no legitimate free source of that exists). It is a transparent, data-driven prominence
ranking that changes as rosters and roles change: it is recomputed from the published game logs by every nightly refresh.
No position quotas: every player who meets a rule is notable, however many a team has.

RULES (regular season only; shares are of the player's own team's totals in that season):
  QB      50%+ of his team's pass attempts
  RB      30%+ of his team's carries, or 15%+ of carries together with 10%+ of targets
  WR, TE  13%+ of his team's targets
  any     production of 12+ points per game (an established star whatever his share, e.g. after a trade)
  A rule can be met this season (2+ games) or last season (6+ games), so a star who started this season injured stays notable.
  Kickers and defensive players are never marked notable (they stay available when the filter is off).
"""
import json, os, sys, collections

def main():
    site = sys.argv[1]
    P = json.load(open(os.path.join(site, 'data-nfl-players.json')))
    seasons = sorted({s for p in P['items'] for s in p.get('seasons', [])}); cur = max(seasons); prev = cur - 1
    stat = collections.defaultdict(lambda: collections.Counter())       # (pid, season, team) -> totals
    team = collections.defaultdict(lambda: collections.Counter())       # (season, team) -> totals
    for grp in ('qb', 'rb', 'wr', 'te'):
        fn = os.path.join(site, f'data-nfl-logs-{grp}.json')
        if not os.path.exists(fn): continue
        d = json.load(open(fn)); ci = {c: i for i, c in enumerate(d['cols'])}
        g = lambda r, c: (r[ci[c]] or 0) if c in ci else 0
        for r in d['rows']:
            s = r[ci['season']]
            if s not in (cur, prev) or r[ci['type']] != 'R': continue
            k = (r[ci['pid']], s, r[ci['team']]); c = stat[k]
            c['g'] += 1
            for col in ('att', 'car', 'tgt', 'rec', 'pass_yds', 'rush_yds', 'rec_yds', 'pass_td', 'rush_td', 'rec_td', 'int'):
                v = g(r, col); c[col] += v; team[(s, r[ci['team']])][col] += v
    best = {}
    for (pid, s, tm), c in stat.items():
        pts = 0.04 * c['pass_yds'] + 4 * c['pass_td'] - 2 * c['int'] + 0.1 * (c['rush_yds'] + c['rec_yds']) + 6 * (c['rush_td'] + c['rec_td']) + 0.5 * c['rec']
        T = team[(s, tm)]
        sh = {k: (c[k] / T[k] if T[k] else 0.0) for k in ('att', 'car', 'tgt')}
        best.setdefault(pid, []).append({'s': s, 'team': tm, 'g': c['g'], 'ppg': pts / c['g'], 'sh': sh})
    n_notable = 0
    for p in P['items']:
        recs = best.get(p['id'], [])
        cands = [(r['ppg'] if r['s'] == cur else r['ppg'] * 0.9, r) for r in recs if (r['s'] == cur and r['g'] >= 2) or (r['s'] == prev and r['g'] >= 4)]
        p['prom'] = round(max(c[0] for c in cands), 1) if cands else None
        why, ok = '', False
        if p.get('current') and p.get('roster_status') not in ('CUT', 'RET') and p.get('group') in ('qb', 'rb', 'wr', 'te'):  # released / retired players never
            for r in sorted(recs, key=lambda r: -r['s']):
                if not ((r['s'] == cur and r['g'] >= 2) or (r['s'] == prev and r['g'] >= 6)): continue
                sh, grp = r['sh'], p['group']
                if grp == 'qb' and sh['att'] >= 0.5: ok, why = True, f"{r['s']}: {round(100 * sh['att'])}% of {r['team']} pass attempts"
                elif grp == 'rb' and (sh['car'] >= 0.30 or (sh['car'] >= 0.15 and sh['tgt'] >= 0.10)): ok, why = True, f"{r['s']}: {round(100 * sh['car'])}% of {r['team']} carries" + (f", {round(100 * sh['tgt'])}% of targets" if sh['tgt'] >= 0.10 else '')
                elif grp in ('wr', 'te') and sh['tgt'] >= 0.13: ok, why = True, f"{r['s']}: {round(100 * sh['tgt'])}% of {r['team']} targets"
                elif r['ppg'] >= 12: ok, why = True, f"{r['s']}: {r['ppg']:.1f} production points per game"
                if ok: break
        p['notable'] = ok; p['prom_why'] = why if ok else ''
        n_notable += ok
    P['prominence'] = {'season': cur, 'previous': prev, 'notable': n_notable, 'method': 'owner-tools/nfl_prominence.py (regular-season usage shares and production; not public popularity)'}
    json.dump(P, open(os.path.join(site, 'data-nfl-players.json'), 'w'), separators=(',', ':'), ensure_ascii=False)
    print(json.dumps(P['prominence']))

if __name__ == '__main__':
    main()
