#!/usr/bin/env python3
"""NFL trade dates for the club-change dividers (owner request 27 Oct 2026).

Source: nflverse trades.csv (trade_id, season, trade_date, gave, received, pfr_id, pfr_name; CC BY 4.0 like the rest of nflverse), joined to
nflverse players.csv (pfr_id -> gsis_id, the id PropLab's NFL player files use). Only trades of players (not picks) from 2021 on are kept.
The site shows a trade date on a divider ONLY when a record here says the player went from the old team to the new team between his last
game for the old team and his first for the new one; signings, waivers and releases have no dated record here, so those dividers say
"first game for" with the date of that game (never an invented date).

Usage: python3 nfl_trades.py <trades.csv> <players.csv> <site dir>   -> writes <site dir>/data-nfl-trades.json
"""
import csv, json, os, sys, datetime

def main():
    tr, pl, site = sys.argv[1:4]
    gsis = {}
    for r in csv.DictReader(open(pl, encoding='utf-8')):
        if r.get('pfr_id') and r.get('gsis_id'): gsis[r['pfr_id']] = (r['gsis_id'], r.get('display_name') or '')
    items, unmatched = [], 0
    for r in csv.DictReader(open(tr, encoding='utf-8')):
        if not r.get('pfr_id') or not (r.get('season') or '0').isdigit() or int(r['season']) < 2021 or not r.get('trade_date'): continue
        g = gsis.get(r['pfr_id'])
        if not g: unmatched += 1; continue
        # in trades.csv 'gave' is the team that gave the player away and 'received' the team that got him
        items.append({'pid': g[0], 'name': r.get('pfr_name') or g[1], 'date': r['trade_date'], 'from': r['gave'], 'to': r['received'], 'trade_id': r['trade_id']})
    items.sort(key=lambda x: (x['date'], x['name']))
    out = {'schema': 1, 'updated': datetime.date.today().isoformat(), 'source': 'nflverse trades.csv + players.csv (CC BY 4.0)', 'note': 'Player trades only; signings, waivers and releases are not in this source.',
           'latest_trade': items[-1]['date'] if items else None, 'items': items}
    json.dump(out, open(os.path.join(site, 'data-nfl-trades.json'), 'w'), separators=(',', ':'))
    # the site fetches the trades file only when the NFL meta file names it (no failed request on a site without it)
    mp = os.path.join(site, 'data-nfl-meta.json')
    if os.path.exists(mp):
        meta = json.load(open(mp)); meta['trades'] = {'file': 'data-nfl-trades.json', 'updated': out['updated'], 'count': len(items)}
        json.dump(meta, open(mp, 'w'), separators=(',', ':'))
    print(f'{len(items)} player trades since 2021 (latest {out["latest_trade"]}); {unmatched} without a gsis id were left out')

if __name__ == '__main__': main()
