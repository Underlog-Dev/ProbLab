#!/usr/bin/env python3
"""Nightly squad refresh (owner request 27 Oct 2026): current first-team squads from each club's English Wikipedia article.

Why: the player directory decides who is offered as a CURRENT squad member (site/js/fbscan.js membership). It used to be filled by hand and
went stale. This step re-reads every club's "First-team squad" list each night, with the list's own "updated" date, and records changes.

Source: the club's own article (e.g. "Arsenal F.C."), section "First-team squad" / "Current squad", templates {{Fs player|...|pos=..|
name=[[...]]}} (CC BY-SA 4.0: names and positions are facts; the site credits Wikipedia and links each club's article). Read with the raw
endpoint, one request per club, one second apart, with the user agent the Wikimedia policy asks for; a 429 / 5xx is retried with back-off.

Safety (a wrong squad is worse than an old one):
  - a club whose article cannot be read, has no squad list, or gives fewer than MIN_PLAYERS players keeps its PREVIOUS list (and its old
    date), and the problem is reported; a whole league never disappears because of one bad night;
  - the list date is the article's own {{updated|...}} / "As of" date; when the article gives none the list is marked undated (the site
    then shows the list as old / unverified);
  - a name listed at two clubs is a conflict: the directory builder drops both and reports it (never guessed).
Changes (joined, left, moved between covered clubs, loan status) are compared with the published directory and appended to
data-squad-changes.json (public; last 400 days kept). A player who leaves a list is recorded as "left the squad list (reason not recorded)":
released, retired, sold abroad or loaned out are not told apart because the list does not say which.

Usage: python3 squads_wiki.py <live site dir> <inputs dir> <site out dir> <now ISO> <report json> [--leagues epl,mls] [--map data-src/squads/articles.json]
Writes <inputs dir>/<league>-squads-wikipedia.txt (read by build-data.mjs) and <site out dir>/data-squad-changes.json.
"""
import datetime, json, os, re, sys, time, urllib.parse, urllib.request

UA = 'PropLab-data-refresh/1.0 (https://underlog-dev.github.io/ProbLab/; GitHub underlog-dev/ProbLab)'
MIN_PLAYERS = 15
NIGHTLY_SOURCE = 'Wikipedia club articles (refreshed nightly)'
POS = {'GK': 'G', 'DF': 'D', 'MF': 'M', 'FW': 'F'}
MONTHS = {m: i for i, m in enumerate(['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'], 1)}

def fetch_raw(title, tries=5):
    url = 'https://en.wikipedia.org/w/index.php?' + urllib.parse.urlencode({'title': title.replace(' ', '_'), 'action': 'raw', 'redirect': 'no'})
    err = ''
    for i in range(tries):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': UA}), timeout=60) as r: return r.read().decode('utf-8'), ''
        except urllib.error.HTTPError as e:
            err = f'HTTP {e.code}'
            if e.code == 404: return None, err
            wait = int(e.headers.get('Retry-After') or 0) or 5 * (i + 1) ** 2
            time.sleep(min(wait, 120))
        except Exception as e:
            err = str(e); time.sleep(5 * (i + 1))
    return None, err

def norm(s):
    import unicodedata
    s = unicodedata.normalize('NFD', str(s or '')).encode('ascii', 'ignore').decode().lower()
    return re.sub(r'[^a-z0-9]+', ' ', re.sub(r"['’`.]", '', s)).strip()

def parse_date(s):
    s = re.sub(r'\[\[|\]\]', '', s or '').strip()
    m = re.search(r'(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})', s) or None
    if m and m.group(2).lower() in MONTHS: return f'{int(m.group(3)):04d}-{MONTHS[m.group(2).lower()]:02d}-{int(m.group(1)):02d}'
    m = re.search(r'([A-Za-z]+)\s+(\d{1,2}),\s*(\d{4})', s)
    if m and m.group(1).lower() in MONTHS: return f'{int(m.group(3)):04d}-{MONTHS[m.group(1).lower()]:02d}-{int(m.group(2)):02d}'
    m = re.search(r'(\d{4})-(\d{2})-(\d{2})', s)
    return f'{m.group(1)}-{m.group(2)}-{m.group(3)}' if m else None

def link_text(v):
    v = re.sub(r'<ref[^>]*/>|<ref.*?</ref>|<!--.*?-->', '', v, flags=re.S)
    m = re.search(r'\[\[([^\]|]+)(?:\|([^\]]+))?\]\]', v)
    t = (m.group(2) or m.group(1)) if m else v
    t = re.sub(r'\{\{[^}]*\}\}', '', t); t = re.sub(r"''+", '', t)
    return re.sub(r'\s*\((?:footballer|soccer|born \d{4}|[^)]*footballer[^)]*)\)\s*$', '', t).strip()

def template_args(body):
    """Splits a template body on top-level pipes (links and nested templates kept whole)."""
    out, depth, cur = [], 0, ''
    i = 0
    while i < len(body):
        two = body[i:i + 2]
        if two in ('[[', '{{'): depth += 1; cur += two; i += 2; continue
        if two in (']]', '}}'): depth -= 1; cur += two; i += 2; continue
        if body[i] == '|' and depth == 0: out.append(cur); cur = ''; i += 1; continue
        cur += body[i]; i += 1
    out.append(cur)
    args = {}
    for a in out[1:]:
        if '=' in a: k, v = a.split('=', 1); args[k.strip().lower()] = v.strip()
    return args

def squad(text, want=None):
    """-> (players [{name, pos, loan_from}], as_of or None, why-not). A section that only transcludes another article's
    section ({{#section-h:Article|Heading}}) returns why = 'follow:Article|Heading'."""
    heads = [m for m in re.finditer(r'^(={2,4})\s*([^=\n]+?)\s*\1\s*$', text, re.M)]
    start = None
    for m in heads:
        h = m.group(2).lower()
        if want and h == want.lower(): start = m; break
        if not want and re.search(r'(first[- ]team|current|senior)\s+squad|^squad$|^players$|^current roster$|^roster$|first[- ]team players', h): start = m; break
    if not start: return [], None, 'no squad section'
    lvl = len(start.group(1)); end = len(text)
    for m in heads:
        if m.start() > start.start() and len(m.group(1)) <= lvl: end = m.start(); break
    sec = text[start.end():end]
    tr = re.search(r'\{\{\s*#section-h\s*:\s*([^|}]+)\|([^}]+)\}\}', sec)
    if tr and not re.search(r'\{\{\s*(?:Fs player|Football squad player)', sec, re.I): return [], None, f'follow:{tr.group(1).strip()}|{tr.group(2).strip()}'
    # stop before an "out on loan" sub-list inside the same section
    cut = re.search(r"^(?:={2,5}\s*|'''\s*|;\s*)?(out on loan|players out on loan|on loan|loaned out)", sec, re.I | re.M)
    if cut: sec = sec[:cut.start()]
    upd = re.search(r'\{\{\s*(?:updated|update|as of)\s*\|([^}]*)\}\}', sec, re.I) or re.search(r'[Aa]s of\s+([0-9]{1,2}\s+[A-Za-z]+\s+[0-9]{4}|[A-Za-z]+\s+[0-9]{1,2},\s*[0-9]{4})', sec)
    as_of = parse_date(upd.group(1).replace('|', ' ')) if upd else None
    players = []
    for m in re.finditer(r'\{\{\s*(?:Fs player|Football squad player|fs player)\s*(\|.*?)\}\}\s*$', sec, re.I | re.M | re.S):
        a = template_args('x' + m.group(1))
        name = link_text(a.get('name', ''))
        if not name or len(name) < 2: continue
        other = a.get('other', '') + ' ' + a.get('note', '')
        if re.search(r'on loan (?:to|at|with)\b|^\s*at\s+\[\[[^\]]+\]\][^|]*\buntil\b', other.strip(), re.I): continue  # loaned OUT: he plays for the other club; not a current squad member here
        lf = re.search(r'on loan from\s+(?:\[\[([^\]|]+)(?:\|([^\]]+))?\]\]|([A-Z][\w .\'-]+))', other, re.I)
        loan = (lf.group(2) or lf.group(1) or lf.group(3)).strip() if lf else None
        players.append({'name': name, 'pos': POS.get(a.get('pos', '').upper()[:2], 'M') if a.get('pos') else 'M', 'loan_from': loan})
    if not players: return [], as_of, 'no Fs player templates in the squad section'
    return players, as_of, ''

def main():
    live, inp, site_out, now_s, rep_path = sys.argv[1:6]
    leagues = ['epl', 'mls']; amap = {}
    if '--leagues' in sys.argv: leagues = sys.argv[sys.argv.index('--leagues') + 1].split(',')
    if '--map' in sys.argv:
        try: amap = json.load(open(sys.argv[sys.argv.index('--map') + 1]))
        except Exception: amap = {}
    now = datetime.datetime.fromisoformat(now_s.replace('Z', '+00:00')); today = now.date().isoformat()
    old = {}
    try: old = json.load(open(os.path.join(live, 'data-directory.json')))
    except Exception: pass
    old_items, old_clubs = old.get('items', []), old.get('clubs', [])
    rep = {'run': now_s, 'leagues': {}}
    new_by_name = {}
    for lg in leagues:
        clubs = [c for c in old_clubs if (c.get('league') or 'epl') == lg]
        for t, title in (amap.get(lg) or {}).items():  # promoted / new clubs, and article corrections
            if not any(norm(c['team']) == norm(t) for c in clubs): clubs.append({'team': t, 'source': 'https://en.wikipedia.org/wiki/' + title})
        L = rep['leagues'][lg] = {'clubs': 0, 'refreshed': 0, 'kept_previous': [], 'undated': [], 'players': 0}
        lines = [f'# {lg} first-team squads from Wikipedia club articles (CC BY-SA 4.0), refreshed {today} by owner-tools/squads_wiki.py']
        for c in clubs:
            team = c['team']; title = (amap.get(lg) or {}).get(team)
            if not title:
                t0 = urllib.parse.unquote(c.get('source', '').rsplit('/wiki/', 1)[-1]).replace('_', ' ')
                m = re.match(r'^\d{4}(?:[–-]\d{2,4})?\s+(.+?)\s+season$', t0)  # a season article -> the club's own article
                title = m.group(1) if m else t0
            L['clubs'] += 1
            text, err = fetch_raw(title); time.sleep(1.0)
            if text and text.lstrip().upper().startswith('#REDIRECT'):
                t2 = re.search(r'\[\[([^\]|#]+)', text); text, err = fetch_raw(t2.group(1)) if t2 else (None, 'redirect'); time.sleep(1.0)
            players, as_of, why = squad(text) if text else ([], None, err or 'not read')
            if why.startswith('follow:'):  # the club article shows its season article's roster section: read that
                t2, h2 = why[7:].split('|', 1); text2, err2 = fetch_raw(t2); time.sleep(1.0)
                players, as_of, why = squad(text2, h2) if text2 else ([], None, err2 or 'not read'); title = t2 if players else title
            if len(players) < MIN_PLAYERS:
                prev = [i for i in old_items if i.get('league') == lg and norm(i['team']) == norm(team)]
                L['kept_previous'].append(f'{team} ({title}): {why or f"only {len(players)} players"}; previous list of {c.get("as_of") or "unknown date"} kept ({len(prev)} players)')
                lines.append(f"## {team} | {c.get('as_of') or ''} | {urllib.parse.unquote(c.get('source', '').rsplit('/wiki/', 1)[-1]) or title.replace(' ', '_')}")
                for i in prev: lines.append(f"{({'GK': 'G', 'DF': 'D', 'MF': 'M', 'FW': 'F'}).get(i.get('pos'), 'M')} {i['name']}" + (f" | loan:{i['loan_from']}" if i.get('loan_from') else ''))
                for i in prev: new_by_name.setdefault((lg, norm(i['name'])), []).append({'name': i['name'], 'team': team, 'loan_from': i.get('loan_from')})
                continue
            L['refreshed'] += 1; L['players'] += len(players)
            if not as_of: L['undated'].append(team)
            lines.append(f"## {team} | {as_of or ''} | {title.replace(' ', '_')}")
            for p in players:
                lines.append(f"{p['pos']} {p['name']}" + (f" | loan:{p['loan_from']}" if p['loan_from'] else ''))
                new_by_name.setdefault((lg, norm(p['name'])), []).append({'name': p['name'], 'team': team, 'loan_from': p['loan_from']})
        open(os.path.join(inp, f'{lg}-squads-wikipedia.txt'), 'w').write('\n'.join(lines) + '\n')
    # changes against the published directory
    changes = []
    old_by = {}
    for i in old_items:
        if i.get('league') in leagues: old_by.setdefault((i['league'], norm(i['name'])), []).append(i)
    baseline = {lg for lg in leagues if (old.get('leagues', {}).get(lg, {}).get('source') or '') != NIGHTLY_SOURCE}  # first run on this source: no change log
    rep['baseline_leagues'] = sorted(baseline)
    for k, olds in old_by.items():
        if k[0] in baseline: continue
        news = new_by_name.get(k, [])
        for o in olds:
            if any(norm(n['team']) == norm(o['team']) for n in news):
                n = next(n for n in news if norm(n['team']) == norm(o['team']))
                if bool(n.get('loan_from')) != bool(o.get('loan_from')): changes.append({'date': today, 'league': k[0], 'player': o['name'], 'from': o['team'], 'to': o['team'], 'kind': 'loan status changed'})
                continue
            if news: changes.append({'date': today, 'league': k[0], 'player': o['name'], 'from': o['team'], 'to': news[0]['team'], 'kind': 'moved (now in the new club\'s squad list)'})
            else: changes.append({'date': today, 'league': k[0], 'player': o['name'], 'from': o['team'], 'to': None, 'kind': 'left the squad list (reason not recorded)'})
    for k, news in new_by_name.items():
        if k not in old_by and k[0] not in baseline:
            for n in news: changes.append({'date': today, 'league': k[0], 'player': n['name'], 'from': None, 'to': n['team'], 'kind': 'joined the squad list'})
    rep['changes'] = len(changes); rep['change_sample'] = changes[:40]
    # public, append-only history (400 days)
    hist = {'schema': 1, 'items': []}
    try: hist = json.load(open(os.path.join(live, 'data-squad-changes.json')))
    except Exception: pass
    cutoff = (now.date() - datetime.timedelta(days=400)).isoformat()
    seen = {(c['date'], c['league'], c['player'], c.get('from'), c.get('to')) for c in hist.get('items', [])}
    items = [c for c in hist.get('items', []) if c['date'] >= cutoff] + [c for c in changes if (c['date'], c['league'], c['player'], c.get('from'), c.get('to')) not in seen]
    if old_items:  # the very first run has nothing to compare with: no change list is invented
        json.dump({'schema': 1, 'updated': today, 'source': 'Wikipedia club articles (CC BY-SA 4.0), compared night by night', 'note': 'A player leaving a list may have been sold, released, retired or loaned out: the list does not say which.', 'items': items}, open(os.path.join(site_out, 'data-squad-changes.json'), 'w'), indent=0, ensure_ascii=False)
    json.dump(rep, open(rep_path, 'w'), indent=1, ensure_ascii=False)
    print(json.dumps({lg: {k: (v if not isinstance(v, list) else len(v)) for k, v in L.items()} for lg, L in rep['leagues'].items()}), 'changes', len(changes))

if __name__ == '__main__': main()
