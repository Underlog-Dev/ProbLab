#!/usr/bin/env bash
# PropLab daily data refresh, run by GitHub Actions (.github/workflows/proplab-data-refresh.yml) from the repository root.
#   ci-refresh.sh <tools dir>          (the unpacked _proplab-refresh.zip)
# 1. Skips a scheduled catch-up run when today's refresh (UK date) already succeeded.
# 2. Runs owner-tools/refresh.py with the checked-out repository as the baseline (downloads, builds, validates, compares).
# 3. Only if validation passed: copies the changed data files into the repository. The status file is always updated.
# 4. Refuses to commit anything that is not a data-*.json file (the workflow never changes the site's code).
# 5. Commits and pushes. Exit code: 0 = OK or skipped; 3 = refresh/validation failed (published data left unchanged);
#    4 = refused non-data files; 5 = the push to GitHub failed (nothing was published).
set -uo pipefail
REPO="$PWD"; TOOLS="$(cd "$1" && pwd)"; WORK="${RUNNER_TEMP:-/tmp}/proplab-work"; EVENT="${GITHUB_EVENT_NAME:-manual}"; FORCE="${FORCE:-false}"
SUMMARY="${GITHUB_STEP_SUMMARY:-/dev/null}"; STATUS="$REPO/data-refresh-status.json"

# 5 Nov 2026: six scheduled runs a day; only the 23:47 catch-up run is skipped, when a run has already succeeded since 22:30 that evening.
# (PROPLAB_SCHEDULE = the cron line that started this run, from the workflow.) An older workflow without it keeps the old rule.
CATCHUP="${PROPLAB_SCHEDULE-legacy}"
if [ "$EVENT" = "schedule" ] && [ "$FORCE" != "true" ] && { [ "$CATCHUP" = "legacy" ] || [ "$CATCHUP" = "47 23 * * *" ]; }; then
  if python3 - "$STATUS" <<'PY'
import json, sys, datetime
from zoneinfo import ZoneInfo
try: s = json.load(open(sys.argv[1]))
except Exception: sys.exit(1)
ls = s.get('last_success'); uk = ZoneInfo('Europe/London')
if not ls: sys.exit(1)
done = datetime.datetime.fromisoformat(ls.replace('Z', '+00:00')).astimezone(uk)
import os
now = datetime.datetime.fromisoformat(os.environ['PROPLAB_NOW']).astimezone(uk) if os.environ.get('PROPLAB_NOW') else datetime.datetime.now(uk)  # PROPLAB_NOW: tests only
# "today's refresh" = a successful run since 20:00 UK today (a late 23:xx run counts for the same evening)
cut = now.replace(hour=22, minute=30, second=0, microsecond=0) if os.environ.get('PROPLAB_SCHEDULE') else now.replace(hour=20, minute=0, second=0, microsecond=0)
sys.exit(0 if done > cut - (datetime.timedelta(days=1) if now.hour < 3 else datetime.timedelta(0)) else 1)
PY
  then echo "Today's refresh already succeeded; nothing to do."; echo "Skipped: today's refresh already succeeded." >> "$SUMMARY"; exit 0; fi
fi

rm -rf "$WORK"; mkdir -p "$WORK"
# Python packages for the experimental NFL model (owner-tools/nfl_model.py); a failed install only stops the model step
# pdfplumber reads the Official NBA Injury Report (PDF); a failed install only stops the NBA injury step (the previous file is kept)
if [ -z "${PROPLAB_SKIP_PIP:-}" ]; then  # PROPLAB_SKIP_PIP: tests only
python3 -m pip install --quiet --disable-pip-version-check "pdfplumber>=0.11,<1" || echo "::warning::pdfplumber could not be installed"
python3 -m pip install --quiet --disable-pip-version-check "numpy>=2,<3" "pandas>=2.2,<4" "scipy>=1.13,<2" "scikit-learn>=1.5,<2" || echo "::warning::model packages could not be installed"
fi
python3 "$TOOLS/owner-tools/refresh.py" --work "$WORK" --live "$REPO" --state "$STATUS" --status-out "$WORK/status.json"
RC=$?
if [ -f "$WORK/OUT/REFRESH-REPORT.md" ]; then cat "$WORK/OUT/REFRESH-REPORT.md" >> "$SUMMARY"; fi
if [ $RC -eq 0 ] && [ -d "$WORK/OUT/UPLOAD-TO-GITHUB" ]; then cp "$WORK/OUT/UPLOAD-TO-GITHUB/"data-*.json "$REPO/"; fi
if [ -f "$WORK/status.json" ]; then cp "$WORK/status.json" "$STATUS"
else  # the refresh crashed before writing a status: record the failure, keep everything else
  python3 - "$STATUS" "$RC" <<'PY'
import json, sys, datetime
p, rc = sys.argv[1], sys.argv[2]
try: s = json.load(open(p))
except Exception: s = {'schema': 1}
s.update({'last_run': datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'), 'result': 'failed', 'changed_files': [], 'errors': [f'refresh stopped with exit code {rc} before finishing; published data unchanged']})
json.dump(s, open(p, 'w'), indent=1)
PY
fi
[ $RC -eq 0 ] || RC=3

cd "$REPO"
# 12 Nov 2026 (owner: "workflow failed" emails): the bot's name and email are set for the whole job, not only for the first commit.
# Before, when a website upload landed while a refresh was running, re-applying the data commit on top of it needed a committer name
# that was never set, so all 5 push attempts failed and the refreshed data was thrown away.
git config user.name "proplab-data-refresh[bot]"; git config user.email "41898282+github-actions[bot]@users.noreply.github.com"
git add -A -- 'data-*.json'
BAD=$(git status --porcelain | grep -Ev '^[ AM?]{1,2} data-[A-Za-z0-9._-]+\.json$' || true)
if [ -n "$BAD" ]; then
  echo "::error::Refusing to commit: files other than data-*.json changed:"; echo "$BAD"
  echo "Refused to commit non-data files: $BAD" >> "$SUMMARY"; exit 4
fi
if git diff --cached --quiet; then echo "No changes to commit."; exit $RC; fi
N=$(git diff --cached --name-only | wc -l | tr -d ' ')
git -c user.name="proplab-data-refresh[bot]" -c user.email="41898282+github-actions[bot]@users.noreply.github.com" commit -q -m "Data refresh $(TZ=Europe/London date '+%Y-%m-%d %H:%M %Z'): $N file(s)$([ $RC -eq 0 ] || echo ' (refresh failed: status only)')"
# Push with retries. A failed push is a FAILED run (exit 5), never reported as success: the data did not reach GitHub.
PUSHED=0
KEEP="$WORK/keep-data"; rm -rf "$KEEP"; mkdir -p "$KEEP"; git diff --name-only HEAD~1 HEAD -- 'data-*.json' > "$KEEP/list.txt"  # our data files, kept for a retry
while read -r f; do [ -f "$f" ] && cp "$f" "$KEEP/"; done < "$KEEP/list.txt"
for i in 1 2 3 4 5; do
  if git push -q 2>"$WORK/push-$i.err"; then PUSHED=1; break; fi
  echo "::warning::push attempt $i failed: $(tail -2 "$WORK/push-$i.err" | tr '\n' ' ')"
  # Someone else pushed meanwhile (e.g. an upload from the website). This job only ever owns data-*.json, so: keep our data files,
  # move to the latest commit on GitHub (with the upload), put our data files back and commit them again. No merge or rebase to go
  # wrong, and the upload is never undone.
  BR=$(git rev-parse --abbrev-ref HEAD)
  if git fetch -q origin "$BR" 2>>"$WORK/push-$i.err" && git reset -q --hard "origin/$BR"; then
    while read -r f; do [ -f "$KEEP/$f" ] && cp "$KEEP/$f" "$f"; done < "$KEEP/list.txt"
    git add -A -- 'data-*.json'
    if ! git diff --cached --quiet; then git commit -q -m "Data refresh $(TZ=Europe/London date '+%Y-%m-%d %H:%M %Z'): $N file(s)$([ $RC -eq 0 ] || echo ' (refresh failed: status only)')"; else echo "Nothing left to commit after the upload."; PUSHED=1; break; fi
  fi
  sleep $((i * ${PUSH_RETRY_SLEEP:-10}))
done
if [ $PUSHED -ne 1 ]; then
  echo "::error::All 5 push attempts failed. The refreshed data was NOT published; the website still shows the previous data."
  echo "**FAILED: the data could not be pushed to GitHub after 5 attempts. Nothing was published.** Last error: $(tail -3 "$WORK/push-5.err" | tr '\n' ' ')" >> "$SUMMARY"
  exit 5
fi
echo "Committed and pushed $N file(s): $(git rev-parse --short HEAD)." >> "$SUMMARY"
exit $RC
