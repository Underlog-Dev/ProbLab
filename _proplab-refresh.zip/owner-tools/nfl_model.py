#!/usr/bin/env python3
"""PropLab NFL player-prop model (experimental). Owner tool: never shipped to the browser as code; it writes JSON data files.

  python3 nfl_model.py backtest --nfl <nflverse dir> --out <dir>      walk-forward backtest + trained parameters
  python3 nfl_model.py predict  --nfl <nflverse dir> --params <model-params.json> --site <site dir>
                                                                     predictions for upcoming games + forward-test log

Method (details and evidence in docs/NFL-MODEL.md):
  * Only information available before kick-off: the player's earlier games, the opponent's earlier games, the betting-market point
    spread / total published in nflverse schedules, home/away, and the official injury-report status. Never the game's own result.
  * Projection = usage (attempts / targets / carries, exponentially weighted, last season down-weighted) x efficiency (yards or
    completions or touchdowns per opportunity, shrunk strongly towards the position average, because efficiency is far less stable
    than usage) x opponent factor (what this defence allowed to the position, shrunk to the league average) x game-environment factor
    (implied team points from spread and total). Exponents are fitted by Poisson regression on earlier seasons only.
  * Probability for any line comes from a predictive distribution, not from the hit rate: negative binomial for counts, the empirical
    distribution of actual/projected (by projection level) for yards and team points.
  * Walk-forward: parameters for season S are fitted on seasons < S; features for every game use only earlier games.
"""
import argparse, csv, datetime, gzip, hashlib, json, math, os, sys
from collections import defaultdict
import numpy as np, pandas as pd
from scipy import optimize, special, stats
from sklearn.linear_model import PoissonRegressor

VERSION = 'nfl-props-0.1.0'
SEASONS = [2023, 2024, 2025, 2026]
# market -> (position groups, target column, kind, volume column, efficiency description)
MARKETS = {
    'pass_yds': (('QB',), 'passing_yards', 'yards', 'attempts'),
    'att':      (('QB',), 'attempts', 'count', 'attempts'),
    'cmp':      (('QB',), 'completions', 'count', 'attempts'),
    'pass_td':  (('QB',), 'passing_tds', 'count', 'attempts'),
    'int':      (('QB',), 'passing_interceptions', 'count', 'attempts'),
    'rush_yds': (('QB', 'RB'), 'rushing_yards', 'yards', 'carries'),
    'car':      (('RB',), 'carries', 'count', 'carries'),
    'rec_yds':  (('RB', 'WR', 'TE'), 'receiving_yards', 'yards', 'targets'),
    'rec':      (('RB', 'WR', 'TE'), 'receptions', 'count', 'targets'),
    'tgt':      (('WR', 'TE'), 'targets', 'count', 'targets'),
    'rec_td':   (('WR', 'TE'), 'receiving_tds', 'count', 'targets'),
}
LABELS = {'pass_yds': 'Passing Yards', 'att': 'Pass Attempts', 'cmp': 'Pass Completions', 'pass_td': 'Passing Touchdowns', 'int': 'Interceptions Thrown',
          'rush_yds': 'Rushing Yards', 'car': 'Rushing Attempts', 'rec_yds': 'Receiving Yards', 'rec': 'Receptions', 'tgt': 'Targets', 'rec_td': 'Receiving Touchdowns', 'pts': 'Team Points'}
HALF_LIFE = 4.0          # games: usage weight halves every 4 games
PREV_SEASON_W = 0.5      # games from the previous season count half
USAGE_K = 2.0            # usage shrinkage: pseudo-games at the role prior
EFF_K = {'yards': 40.0, 'count': 60.0}  # efficiency shrinkage: pseudo-opportunities at the position average
OPP_K = 4.0              # opponent factor shrinkage: pseudo-games at the league average
MIN_GAMES = 3            # fewer earlier games -> "Insufficient data"
RATIO_Q = np.linspace(0.0, 1.0, 81)

# ------------------------------------------------------------------ data
def load(nfl_dir):
    frames = []
    for s in SEASONS:
        p = os.path.join(nfl_dir, f'stats_player_week_{s}.csv')
        if os.path.exists(p): frames.append(pd.read_csv(p, low_memory=False))
    d = pd.concat(frames, ignore_index=True)
    d = d[d['position'].isin(['QB', 'RB', 'WR', 'TE'])].copy()
    g = pd.read_csv(os.path.join(nfl_dir, 'games.csv'), low_memory=False)
    g = g[g['season'].isin(SEASONS)].copy()
    d = d.merge(g[['game_id', 'gameday', 'gametime', 'home_team', 'away_team', 'spread_line', 'total_line', 'game_type']], on='game_id', how='left')
    d = d[d['gameday'].notna()].copy()
    d['home'] = (d['team'] == d['home_team']).astype(int)
    d['implied'] = np.where(d['home'] == 1, (d['total_line'] + d['spread_line']) / 2, (d['total_line'] - d['spread_line']) / 2)
    d = d.sort_values(['gameday', 'game_id', 'player_id']).reset_index(drop=True)
    for c in set(m[1] for m in MARKETS.values()) | {'attempts', 'targets', 'carries'}:
        d[c] = pd.to_numeric(d[c], errors='coerce').fillna(0.0)
    return d, g

def team_games(g):
    """One row per team per final game: points scored and allowed, implied points from the market."""
    g = g[g['home_score'].notna()].copy(); rows = []
    for _, x in g.iterrows():
        for team, opp, pts, pa, home in ((x['home_team'], x['away_team'], x['home_score'], x['away_score'], 1), (x['away_team'], x['home_team'], x['away_score'], x['home_score'], 0)):
            imp = (x['total_line'] + (x['spread_line'] if home else -x['spread_line'])) / 2 if pd.notna(x['total_line']) and pd.notna(x['spread_line']) else np.nan
            rows.append({'game_id': x['game_id'], 'gameday': x['gameday'], 'season': x['season'], 'week': x['week'], 'team': team, 'opp': opp, 'pts': pts, 'pa': pa, 'home': home, 'implied': imp})
    return pd.DataFrame(rows).sort_values(['gameday', 'game_id', 'team']).reset_index(drop=True)

# ------------------------------------------------------------------ features (strictly earlier games only)
def _weights(seasons, cur_season):
    n = len(seasons); idx = np.arange(n)[::-1]  # 0 = most recent
    w = 0.5 ** (idx / HALF_LIFE)
    return w * np.where(np.array(seasons) == cur_season, 1.0, PREV_SEASON_W)

def player_features(d, market):
    """For every player-game of the market's positions: weighted earlier usage, efficiency and the earlier games list (n)."""
    pos, col, kind, vol = MARKETS[market]
    x = d[d['position'].isin(pos)].copy()
    # position-level efficiency prior from the data before each season (computed per season for walk-forward honesty)
    out = []
    for pid, grp in x.groupby('player_id', sort=False):
        grp = grp.sort_values('gameday'); ys = grp[col].values; vs = grp[vol].values; ss = grp['season'].values; ix = grp.index.values
        for i in range(len(grp)):
            season = ss[i]; prev = slice(max(0, i - 40), i)
            yp, vp, sp = ys[prev], vs[prev], ss[prev]
            keep = sp >= season - 1  # this season and last season only
            yp, vp, sp = yp[keep], vp[keep], sp[keep]
            n_cur = int((sp == season).sum())
            if len(yp):
                w = _weights(sp, season)
                usage = float((w * vp).sum() / w.sum()); ymean = float((w * yp).sum() / w.sum())
                eff_num, eff_den = float((w * yp).sum()), float((w * vp).sum())
                last5 = float(yp[-5:].mean()); cur = yp[sp == season]
                season_mean = float(cur.mean()) if len(cur) else np.nan; season_med = float(np.median(cur)) if len(cur) else np.nan; season_sd = float(cur.std(ddof=1)) if len(cur) > 1 else np.nan
                hit_hist = cur
            else:
                usage = ymean = eff_num = eff_den = last5 = season_mean = season_med = season_sd = np.nan; hit_hist = np.array([])
            out.append({'row': ix[i], 'n_prev': len(yp), 'n_cur': n_cur, 'usage': usage, 'ymean': ymean, 'eff_num': eff_num, 'eff_den': eff_den, 'last5': last5,
                        'season_mean': season_mean, 'season_med': season_med, 'season_sd': season_sd, 'hist': hit_hist.tolist()})
    f = pd.DataFrame(out).set_index('row')
    return x.join(f)

def opponent_factors(d, market):
    """What each defence allowed to the market's positions in its earlier games, relative to the league, shrunk (OPP_K games)."""
    pos, col, kind, vol = MARKETS[market]
    x = d[d['position'].isin(pos)]
    allowed = x.groupby(['game_id', 'gameday', 'season', 'opponent_team'])[col].sum().reset_index().sort_values('gameday')
    league = allowed.groupby('season')[col].mean().to_dict()
    fac = {}
    for opp, grp in allowed.groupby('opponent_team'):
        vals, ss, gids = grp[col].values, grp['season'].values, grp['game_id'].values
        for i in range(len(grp)):
            prev = (ss[:i] >= ss[i] - 1); v, s = vals[:i][prev], ss[:i][prev]
            lg = league.get(ss[i - 1] if i and ss[i - 1] == ss[i] else ss[i] - 1, np.mean(list(league.values())))
            if len(v):
                w = _weights(s, ss[i]); m = float((w * v).sum() + OPP_K * lg) / float(w.sum() + OPP_K)
            else: m = lg
            fac[(gids[i], opp)] = m / lg if lg else 1.0
    return fac

def build(d, market):
    pos, col, kind, vol = MARKETS[market]
    x = player_features(d, market)
    fac = opponent_factors(d, market)
    x['opp_factor'] = [fac.get((g, o), 1.0) for g, o in zip(x['game_id'], x['opponent_team'])]
    x['y'] = x[col].astype(float)
    return x

def priors(train, market):
    """Position efficiency (per opportunity) and usage priors from the training seasons."""
    pos, col, kind, vol = MARKETS[market]
    p = {}
    for ps, g in train.groupby('position'):
        tot_v = g[vol].sum(); p[ps] = {'eff': float(g[col].sum() / tot_v) if tot_v else 0.0, 'usage': float(g[vol].mean())}
    return p

def base_projection(x, market, pri):
    pos, col, kind, vol = MARKETS[market]
    eff_prior = x['position'].map(lambda q: pri.get(q, {'eff': 0})['eff']).values
    use_prior = x['position'].map(lambda q: pri.get(q, {'usage': 0})['usage']).values
    n = x['n_prev'].fillna(0).values; usage = np.nan_to_num(x['usage'].values, nan=0.0)
    # usage shrinkage (few earlier games -> towards the position's average usage)
    wsum = np.minimum(n, 8.0)
    u = (usage * wsum + use_prior * USAGE_K) / (wsum + USAGE_K)
    K = EFF_K[kind]; num = np.nan_to_num(x['eff_num'].values, nan=0.0); den = np.nan_to_num(x['eff_den'].values, nan=0.0)
    eff = (num + K * eff_prior) / (den + K)
    if market in ('att', 'car', 'tgt'): base = u            # the usage itself
    else: base = u * eff
    return np.maximum(base, 1e-3)

def design(x, base):
    env = np.where(np.isfinite(x['implied'].values), x['implied'].values / 22.5, 1.0)
    return np.column_stack([np.log(base), np.log(np.clip(x['opp_factor'].values, 0.3, 3.0)), np.log(np.clip(env, 0.4, 2.0)), x['home'].values])

def fit_mean(x, base):
    X = design(x, base); y = np.maximum(x['y'].values, 0)
    m = PoissonRegressor(alpha=1e-4, max_iter=1000).fit(X, y)
    return {'coef': m.coef_.tolist(), 'intercept': float(m.intercept_)}

def predict_mean(x, base, mp):
    return np.exp(design(x, base) @ np.array(mp['coef']) + mp['intercept'])

# ------------------------------------------------------------------ distributions
def fit_nb_alpha(y, mu):
    y = np.asarray(y, float); mu = np.maximum(np.asarray(mu, float), 1e-6)
    def nll(la):
        a = math.exp(la); r = 1.0 / a
        return -np.sum(special.gammaln(y + r) - special.gammaln(r) - special.gammaln(y + 1) + r * np.log(r / (r + mu)) + y * np.log(mu / (r + mu)))
    res = optimize.minimize_scalar(nll, bounds=(-8, 3), method='bounded')
    return float(math.exp(res.x))

def nb_sf(L, mu, a):
    """P(Y > L) for negative binomial with mean mu, variance mu + a mu^2 (a ~ 0 -> Poisson)."""
    k = math.floor(L)  # P(Y > L) = P(Y >= k+1) = 1 - CDF(k)
    if a < 1e-6: return float(stats.poisson.sf(k, mu))
    r = 1.0 / a; p = r / (r + mu)
    return float(stats.nbinom.sf(k, r, p))

def nb_pmf(k, mu, a):
    if a < 1e-6: return float(stats.poisson.pmf(k, mu))
    r = 1.0 / a; return float(stats.nbinom.pmf(k, r, r / (r + mu)))

def fit_ratio(y, mu, buckets):
    """Empirical distribution of actual / projected, separately for low / middle / high projections."""
    y = np.asarray(y, float); mu = np.maximum(np.asarray(mu, float), 1e-3); r = y / mu; out = []
    edges = list(np.quantile(mu, [1 / 3, 2 / 3])) if buckets else []
    lo = -np.inf
    for hi in edges + [np.inf]:
        sel = (mu > lo) & (mu <= hi); q = np.quantile(r[sel], RATIO_Q) if sel.sum() > 50 else np.quantile(r, RATIO_Q)
        out.append({'mu_max': None if hi == np.inf else float(hi), 'q': [round(float(v), 4) for v in q]}); lo = hi
    return out

def ratio_sf(L, mu, dist):
    b = next(x for x in dist if x['mu_max'] is None or mu <= x['mu_max'])
    q = np.array(b['q']); t = (math.floor(L) + 0.5) / max(mu, 1e-3)  # outcomes are whole numbers: Y > L <=> Y > floor(L) + 0.5
    # CDF by interpolation of the quantile function; ties (e.g. many zeros) handled by searchsorted on the right
    cdf = np.interp(t, q, RATIO_Q, left=0.0, right=1.0)
    if t >= q[-1]: cdf = 1.0
    return float(max(0.0, min(1.0, 1.0 - cdf)))

def p_over(L, mu, mk, pos=None):
    if mk['dist'] == 'nb': return nb_sf(L, mu, mk['alpha'])
    return ratio_sf(L, mu, (mk.get('ratio_by_pos') or {}).get(pos) or mk['ratio'])

RARE = {'pass_td', 'int', 'rec_td'}  # touchdowns / interceptions: negative binomial; everything else: empirical actual/projection distribution
def fit_temperature(p, o):
    """p' = sigmoid(a * logit(p) + b), fitted by log loss. a < 1 softens over-confident probabilities."""
    p = np.clip(np.asarray(p, float), 0.005, 0.995); o = np.asarray(o, float); lg = np.log(p / (1 - p))
    def nll(v):
        q = 1 / (1 + np.exp(-(v[0] * lg + v[1]))); q = np.clip(q, 1e-6, 1 - 1e-6)
        return -np.mean(o * np.log(q) + (1 - o) * np.log(1 - q))
    r = optimize.minimize(nll, [1.0, 0.0], method='Nelder-Mead')
    return {'a': round(float(r.x[0]), 4), 'b': round(float(r.x[1]), 4), 'n': int(len(p))}
def median_of(mu, mk, pos=None):
    """Typical outcome: the line at which the (calibrated) model gives Over and Under about 50% each. For skewed statistics such as
    yards it is below the projected average, because a few big games pull the average up."""
    hi = max(4.0, mu * 4); lo = -20.0 if mk['dist'] == 'ratio' else 0.0
    for _ in range(40):
        mid = (lo + hi) / 2
        if apply_cal(p_over(mid, mu, mk, pos), mk.get('calibration')) > 0.5: lo = mid
        else: hi = mid
    return float(math.floor(hi) + 0.5 if hi % 1 else hi)  # nearest half-point line where Over is no longer favoured
def apply_cal(p, cal):
    if not cal: return p
    p = min(max(p, 0.005), 0.995); return float(1 / (1 + math.exp(-(cal['a'] * math.log(p / (1 - p)) + cal['b']))))

# ------------------------------------------------------------------ evaluation helpers
def ref_line(season_med, ymean, n_cur=99, market=''):
    """Reference line: touchdowns / interceptions 0.5 (the usual 'anytime' line); otherwise the player's season MEDIAN (once 3+ games
    this season, else the weighted recent average) rounded down to the half point. The median, not the mean: yardage is right-skewed, so
    'under the season average' wins more often than not for almost everyone, which would make the reference line a trivially biased
    benchmark. A median-based line splits the player's own history roughly in half, so any lean comes from the model's inputs."""
    if market in RARE: return 0.5
    m = season_med if (np.isfinite(season_med) and n_cur >= 3) else ymean
    if not np.isfinite(m): return np.nan
    l = math.floor(m) + 0.5
    if l > m: l -= 1
    return max(0.5, l) if m >= 0 else l

def brier(p, o): return float(np.mean((np.asarray(p) - np.asarray(o)) ** 2))
def logloss(p, o):
    p = np.clip(np.asarray(p, float), 0.01, 0.99); o = np.asarray(o, float)
    return float(-np.mean(o * np.log(p) + (1 - o) * np.log(1 - p)))
def calib(p, o, bins=10):
    p = np.asarray(p, float); o = np.asarray(o, float); edges = np.linspace(0, 1, bins + 1); rows = []; ece = 0.0
    for i in range(bins):
        s = (p >= edges[i]) & (p < edges[i + 1] if i < bins - 1 else p <= 1)
        if s.sum(): rows.append({'from': round(edges[i], 2), 'to': round(edges[i + 1], 2), 'n': int(s.sum()), 'predicted': round(float(p[s].mean()), 4), 'observed': round(float(o[s].mean()), 4)}); ece += s.sum() / len(p) * abs(p[s].mean() - o[s].mean())
    return rows, float(ece)
def wilson(k, n, z=1.96):
    if not n: return (None, None)
    ph = k / n; d = 1 + z * z / n; c = (ph + z * z / (2 * n)) / d; h = z * math.sqrt(ph * (1 - ph) / n + z * z / (4 * n * n)) / d
    return (round(c - h, 4), round(c + h, 4))

# ------------------------------------------------------------------ backtest
def run_market(d, market, test_seasons, log):
    pos, col, kind, vol = MARKETS[market]
    x = build(d, market)
    x = x[x['game_type'].isin(['REG', 'WC', 'DIV', 'CON', 'SB'])]
    preds = []; params = {}
    for S in test_seasons + ['final']:
        train = x[(x['season'] < (S if S != 'final' else 9999)) & (x['n_prev'] >= MIN_GAMES)]
        if len(train) < 300: continue
        dd = d[(d['season'] < (S if S != 'final' else 9999)) & d['position'].isin(pos)]; pri = priors(dd, market)
        btr = base_projection(train, market, pri); mp = fit_mean(train, btr); mu_tr = predict_mean(train, btr, mp)
        mk = {'priors': pri, 'mean': mp, 'kind': kind}
        if market in RARE: mk.update({'dist': 'nb', 'alpha': fit_nb_alpha(np.maximum(train['y'].values, 0), mu_tr)})
        else:
            mk.update({'dist': 'ratio', 'ratio': fit_ratio(train['y'].values, mu_tr, True)})
            if len(pos) > 1:  # quarterbacks' rushing and running backs' receiving behave differently: one distribution per position
                mk['ratio_by_pos'] = {ps: fit_ratio(train['y'].values[(train['position'] == ps).values], mu_tr[(train['position'] == ps).values], True)
                                      for ps in pos if (train['position'] == ps).sum() >= 300}
        # calibration map fitted on the out-of-sample predictions of EARLIER test seasons only (none for the first test season)
        prev = [r for r in preds if r.get('p_raw') is not None and (S == 'final' or r['season'] < S)]
        mk['calibration'] = fit_temperature([r['p_raw'] for r in prev], [r['o'] for r in prev]) if len(prev) >= 200 else None
        if S == 'final': params = mk; break
        test = x[x['season'] == S].copy()
        bte = base_projection(test, market, pri); test['mu'] = predict_mean(test, bte, mp)
        for _, r in test.iterrows():
            L = ref_line(r['season_med'], r['ymean'], r['n_cur'], market)
            row = {'market': market, 'season': int(S), 'week': int(r['week']), 'game_id': r['game_id'], 'player_id': r['player_id'], 'position': r['position'], 'n_prev': int(r['n_prev']), 'n_cur': int(r['n_cur']), 'y': float(r['y'])}
            if r['n_prev'] < MIN_GAMES or not np.isfinite(L): row['insufficient'] = True; preds.append(row); continue
            mu = float(r['mu']); praw = p_over(L, mu, mk, r['position']); po = apply_cal(praw, mk['calibration']); o = 1.0 if r['y'] > L else 0.0
            hist = np.array(r['hist']) if len(r['hist']) else np.array([])
            ph = float((hist > L).mean()) if len(hist) else np.nan                      # Hiwi-style historical hit rate (this season)
            sm, sd = r['season_mean'], r['season_sd']
            if not np.isfinite(sm): sm, sd = r['ymean'], np.nan
            sd = sd if np.isfinite(sd) and sd > 0 else max(1.0, 0.6 * abs(sm))
            pn = float(stats.norm.sf(math.floor(L) + 0.5, sm, sd))   # naive season-average normal (continuity-corrected)
            l5 = r['last5'] if np.isfinite(r['last5']) else sm
            pl5 = p_over(L, max(l5, 1e-3), mk, r['position'])  # last-5 average through the same distribution (uncalibrated)
            row.update({'line': L, 'proj': round(mu, 3), 'p': round(po, 4), 'p_raw': round(praw, 4), 'o': o, 'p_hit': None if not np.isfinite(ph) else round(ph, 4), 'p_norm': round(pn, 4), 'p_last5': round(pl5, 4),
                        'base_season_mean': round(float(sm), 3), 'base_last5': round(float(l5), 3), 'usage_cv': None})
            preds.append(row)
        log(f'  {market} {S}: {len(test)} rows')
    return preds, params

def summarise(preds):
    df = pd.DataFrame(preds); out = {}
    ok = df[~df.get('insufficient', pd.Series(False, index=df.index)).fillna(False).astype(bool)] if 'insufficient' in df else df
    def block(g):
        res = {'n': int(len(g))}
        if not len(g): return res
        o = g['o'].values; hit = g['p_hit'].astype(float).fillna(0.5).values
        res['observed_over_rate'] = round(float(o.mean()), 4)
        for name, col in (('model', 'p'), ('hit_rate', None), ('season_avg_normal', 'p_norm'), ('last5', 'p_last5')):
            p = hit if col is None else g[col].values
            res[name] = {'brier': round(brier(p, o), 5), 'logloss': round(logloss(p, o), 5)}
        res['model']['ece'] = round(calib(g['p'].values, o)[1], 4)
        res['mae'] = {'model': round(float(np.mean(np.abs(g['proj'] - g['y']))), 3), 'season_avg': round(float(np.mean(np.abs(g['base_season_mean'] - g['y']))), 3), 'last5': round(float(np.mean(np.abs(g['base_last5'] - g['y']))), 3)}
        res['brier_skill_vs_hit_rate'] = round(1 - res['model']['brier'] / res['hit_rate']['brier'], 4) if res['hit_rate']['brier'] else None
        res['brier_skill_vs_season_avg'] = round(1 - res['model']['brier'] / res['season_avg_normal']['brier'], 4)
        res['model_accuracy'] = round(float(((g['p'] > 0.5) == (o == 1)).mean()), 4)
        return res
    out['overall'] = block(ok)
    out['by_market'] = {m: block(g) for m, g in ok.groupby('market')}
    out['by_season'] = {str(s): block(g) for s, g in ok.groupby('season')}
    out['by_position'] = {p: block(g) for p, g in ok.groupby('position')}
    out['by_market_season'] = {f'{m}|{s}': block(g) for (m, s), g in ok.groupby(['market', 'season'])}
    out['calibration'] = {m: calib(g['p'].values, g['o'].values)[0] for m, g in ok.groupby('market')}
    out['insufficient_rows'] = int(df.get('insufficient', pd.Series(dtype=bool)).fillna(False).sum()) if 'insufficient' in df else 0
    return out, ok

def confidence_table(ok):
    """Measured reliability by market, by how many earlier games the player had and by how far the probability is from 50%.
    These cells, measured on the out-of-sample seasons, set the confidence labels (docs/NFL-MODEL.md)."""
    ok = ok.copy()
    ok['sample'] = pd.cut(ok['n_prev'], [0, 5, 10, 999], labels=['3-5', '6-10', '11+'], include_lowest=True).astype(str)
    ok['edge'] = pd.cut((ok['p'] - 0.5).abs(), [0, 0.05, 0.10, 0.2, 0.5], labels=['<5', '5-10', '10-20', '20+'], include_lowest=True).astype(str)
    cells = {}
    for (m, s, e), g in ok.groupby(['market', 'sample', 'edge']):
        if len(g) < 30: continue
        o = g['o'].values; p = g['p'].values; side = np.where(p >= 0.5, o, 1 - o); pp = np.where(p >= 0.5, p, 1 - p)
        lo, hi = wilson(int(side.sum()), len(g))
        cells[f'{m}|{s}|{e}'] = {'n': int(len(g)), 'predicted_side_prob': round(float(pp.mean()), 4), 'observed_side_rate': round(float(side.mean()), 4), 'observed_ci95': [lo, hi],
                                 'brier_model': round(brier(p, o), 5), 'brier_hit_rate': round(brier(g['p_hit'].astype(float).fillna(0.5).values, o), 5)}
    return cells

def label_for(cell, market_ok):
    """Confidence label from the measured cell: is the model's chosen side actually winning about as often as predicted, with
    enough cases to know? (Probability of winning and confidence in that probability are kept separate.)"""
    if not market_ok: return 'Insufficient Data'
    if not cell or cell['n'] < 30: return 'Insufficient Data'
    lo, hi = cell['observed_ci95']; gap = abs(cell['observed_side_rate'] - cell['predicted_side_prob'])
    beats = cell['brier_model'] < cell['brier_hit_rate']
    if cell['n'] >= 300 and gap <= 0.03 and beats and lo is not None and lo > 0.5 + 0.02: return 'Very High'
    if cell['n'] >= 150 and gap <= 0.05 and beats and lo > 0.5: return 'High'
    if cell['n'] >= 60 and gap <= 0.07 and beats: return 'Medium'
    if gap <= 0.10: return 'Low'
    return 'Very Low'

def team_points(g, test_seasons):
    t = team_games(g); t = t[t['implied'].notna()]; preds = []; params = {}
    for S in test_seasons + ['final']:
        tr = t[t['season'] < (S if S != 'final' else 9999)]
        if len(tr) < 200: continue
        resid = (tr['pts'] - tr['implied']).values
        mk = {'dist': 'shift', 'q': [round(float(v), 3) for v in np.quantile(resid, RATIO_Q)], 'kind': 'points'}
        if S == 'final': params = mk; break
        te = t[t['season'] == S]
        for _, r in te.iterrows():
            L = math.floor(r['implied']) + 0.5 if r['implied'] % 1 else r['implied'] - 0.5
            L = round(L, 1); po = float(1 - np.interp(math.floor(L) + 0.5 - r['implied'], mk['q'], RATIO_Q))
            prev = t[(t['team'] == r['team']) & (t['gameday'] < r['gameday']) & (t['season'] == S)]['pts'].values
            ph = float((prev > L).mean()) if len(prev) else np.nan
            preds.append({'market': 'pts', 'season': int(S), 'week': int(r['week']), 'game_id': r['game_id'], 'player_id': r['team'], 'position': 'TEAM', 'n_prev': len(prev), 'n_cur': len(prev),
                          'y': float(r['pts']), 'line': L, 'proj': float(r['implied']), 'p': round(po, 4), 'o': float(r['pts'] > L), 'p_hit': None if not np.isfinite(ph) else round(ph, 4),
                          'p_norm': round(float(stats.norm.sf(math.floor(L) + 0.5, prev.mean(), max(prev.std(ddof=1), 4))) if len(prev) > 1 else 0.5, 4), 'p_last5': round(float(stats.norm.sf(math.floor(L) + 0.5, prev[-5:].mean(), 8)) if len(prev) else 0.5, 4),
                          'base_season_mean': float(prev.mean()) if len(prev) else float(r['implied']), 'base_last5': float(prev[-5:].mean()) if len(prev) else float(r['implied'])})
    return preds, params

def cmd_backtest(a):
    log = lambda *x: print(*x, flush=True)
    d, g = load(a.nfl); tests = [2024, 2025, 2026]; allp = []; params = {}
    for m in MARKETS:
        log('market', m); p, prm = run_market(d, m, tests, log); allp += p; params[m] = prm
    p, prm = team_points(g, tests); allp += p; params['pts'] = prm
    summ, ok = summarise(allp)
    # The deployed model uses a calibration map learned from earlier out-of-sample seasons. The first test season (2024) has no earlier
    # out-of-sample season, so activation and confidence are judged on 2025 and 2026, exactly as the model would have been used.
    later = [r for r in allp if r.get('season', 0) >= tests[1]]
    summ_cal, ok_cal = summarise(later); summ['deployed_style_2025_2026'] = summ_cal
    # activation: a market goes live only if, out of sample, it beats BOTH the hit-rate and the season-average baselines on Brier score
    # and log loss, and its calibration error is small.
    act = {}
    for m, r in summ_cal['by_market'].items():
        good = r['n'] >= 300 and r['model']['brier'] < r['hit_rate']['brier'] and r['model']['brier'] < r['season_avg_normal']['brier'] and r['model']['logloss'] < r['season_avg_normal']['logloss'] and r['model']['ece'] <= 0.04
        act[m] = {'active': bool(good), 'reason': 'passed' if good else 'did not beat the baselines out of sample with good calibration'}
    cells = confidence_table(ok_cal)
    for c in cells.values(): pass
    os.makedirs(a.out, exist_ok=True)
    trained = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
    params_out = {'schema': 1, 'version': VERSION, 'trained': trained, 'trained_on_seasons': SEASONS, 'markets': params, 'activation': act, 'confidence_cells': cells,
                  'settings': {'half_life_games': HALF_LIFE, 'prev_season_weight': PREV_SEASON_W, 'usage_k': USAGE_K, 'eff_k': EFF_K, 'opp_k': OPP_K, 'min_games': MIN_GAMES}}
    json.dump(params_out, open(os.path.join(a.out, 'model-params.json'), 'w'), indent=1)
    bt = {'schema': 1, 'version': VERSION, 'created': trained, 'method': 'walk-forward: parameters for each test season fitted on earlier seasons only; features use only earlier games',
          'test_seasons': tests, 'line': 'reference line = 0.5 for touchdowns and interceptions; otherwise the player\'s season-to-date median (weighted recent average before 3 games) rounded down to .5. No historical bookmaker lines are available',
          'summary': summ, 'activation': act, 'confidence_cells': cells}
    json.dump(bt, open(os.path.join(a.out, 'data-nfl-model-backtest.json'), 'w'), separators=(',', ':'))
    pd.DataFrame(allp).drop(columns=['usage_cv'], errors='ignore').to_csv(os.path.join(a.out, 'backtest-predictions.csv.gz'), index=False, compression='gzip')
    log(json.dumps({m: {k: v for k, v in r.items() if k in ('n', 'brier_skill_vs_hit_rate', 'brier_skill_vs_season_avg')} | {'ece': r['model']['ece'], 'mae': r['mae']} for m, r in summ['by_market'].items()}, indent=1))
    log('activation', json.dumps(act, indent=1))

# ------------------------------------------------------------------ predictions for upcoming games
def cmd_predict(a):
    P = json.load(open(a.params)); d, g = load(a.nfl); now = datetime.datetime.now(datetime.timezone.utc)
    up = g[(g['home_score'].isna()) & g['gameday'].notna()].copy()
    if a.now: now = datetime.datetime.fromisoformat(a.now)
    def ko(r):
        t = r['gametime'] if isinstance(r['gametime'], str) else '13:00'
        from zoneinfo import ZoneInfo
        return datetime.datetime.fromisoformat(f"{r['gameday']}T{t}").replace(tzinfo=ZoneInfo('America/New_York')).astimezone(datetime.timezone.utc)
    up['ko'] = up.apply(ko, axis=1); up = up[up['ko'] > now].sort_values('ko')
    if not len(up): print('no upcoming games'); return
    wk = up.iloc[0][['season', 'week']].tolist()
    games = up[up['ko'] <= now + datetime.timedelta(days=8)]  # every game in the next 8 days (the rest of this week and next week)
    if not len(games): games = up[(up['season'] == wk[0]) & (up['week'] == wk[1])]
    wk = games.iloc[-1][['season', 'week']].tolist()
    inj = {}
    ip = os.path.join(a.nfl, f'injuries_{int(wk[0])}.csv')
    if os.path.exists(ip):
        for r in csv.DictReader(open(ip)):
            if int(r['week']) in set(games['week'].astype(int)) and r['report_status']: inj[r['gsis_id']] = r['report_status']
    roster = {}
    rp = os.path.join(a.nfl, f'roster_weekly_{int(wk[0])}.csv')
    if os.path.exists(rp):
        for r in csv.DictReader(open(rp)):
            if r['position'] in ('QB', 'RB', 'WR', 'TE') and r['status'] in ('ACT',) : roster[r['gsis_id']] = r  # last listed week wins
    rows = []
    # pseudo rows: one per player expected for this week (played for the team in its last game), features from all earlier games
    last = d.sort_values('gameday').groupby('player_id').tail(1)
    teams = set(games['home_team']) | set(games['away_team'])
    cand = last[last['team'].isin(teams) & (last['season'] == wk[0])]
    cand = cand[cand['week'] >= int(games['week'].min()) - 3]  # appeared within the last three weeks
    for _, gm in games.iterrows():
        for team, opp, home in ((gm['home_team'], gm['away_team'], 1), (gm['away_team'], gm['home_team'], 0)):
            imp = (gm['total_line'] + (gm['spread_line'] if home else -gm['spread_line'])) / 2 if pd.notna(gm['total_line']) and pd.notna(gm['spread_line']) else np.nan
            for _, pl in cand[cand['team'] == team].iterrows():
                rows.append({'player_id': pl['player_id'], 'player_display_name': pl['player_display_name'], 'position': pl['position'], 'team': team, 'opponent_team': opp, 'home': home, 'implied': imp,
                             'game_id': gm['game_id'], 'gameday': gm['gameday'], 'gametime': gm['gametime'], 'season': int(wk[0]), 'week': int(wk[1]), 'game_type': gm['game_type'], 'ko': gm['ko'].isoformat()})
    fut = pd.DataFrame(rows)
    for c in set(m[1] for m in MARKETS.values()) | {'attempts', 'targets', 'carries'}: fut[c] = np.nan
    allrows = pd.concat([d, fut], ignore_index=True).sort_values(['gameday', 'game_id']).reset_index(drop=True)
    out = []
    for m, (pos, col, kind, vol) in MARKETS.items():
        mk = P['markets'].get(m); act = P['activation'].get(m, {}).get('active', False)
        if not mk: continue
        x = build(allrows.fillna({vol: 0}), m); x = x[x['y'].isna() | x['game_id'].isin(fut['game_id'])]
        x = x[x['game_id'].isin(set(fut['game_id']))]
        if not len(x): continue
        base = base_projection(x, m, mk['priors']); mu = predict_mean(x, base, mk['mean'])
        for (_, r), u, b in zip(x.iterrows(), mu, base):
            L = ref_line(r['season_med'], r['ymean'], r['n_cur'], m); n = int(r['n_prev']); status = inj.get(r['player_id'], '')
            pr = {'id': hashlib.sha1(f"{P['version']}|{r['game_id']}|{r['player_id']}|{m}".encode()).hexdigest()[:16], 'market': m, 'game_id': r['game_id'], 'kickoff': r['ko'],
                  'player_id': r['player_id'], 'player': r['player_display_name'], 'position': r['position'], 'team': r['team'], 'opp': r['opponent_team'], 'home': int(r['home']),
                  'n_prev': n, 'n_season': int(r['n_cur']), 'injury_status': status or None, 'active_market': bool(act)}
            if n < MIN_GAMES or not np.isfinite(L) or status in ('Out', 'Doubtful'):
                pr.update({'confidence': 'Insufficient Data', 'reason': 'injury report: ' + status if status in ('Out', 'Doubtful') else f'only {n} earlier games'}); out.append(pr); continue
            u = round(float(u), 2)  # the published projection; every published probability is computed from it so the website reproduces it exactly
            po = apply_cal(p_over(L, u, mk, r['position']), mk.get('calibration'))
            sample = '3-5' if n <= 5 else '6-10' if n <= 10 else '11+'; e = abs(po - 0.5); edge = '<5' if e < 0.05 else '5-10' if e < 0.10 else '10-20' if e < 0.2 else '20+'
            cell = P['confidence_cells'].get(f'{m}|{sample}|{edge}')
            conf = label_for(cell, act)
            if status == 'Questionable' and conf in ('Very High', 'High'): conf = 'Medium'
            env = (r['implied'] / 22.5) if np.isfinite(r['implied']) else None
            hist = np.array(r['hist']) if isinstance(r['hist'], list) and len(r['hist']) else np.array([])
            med = median_of(float(u), mk, r['position'])
            pr.update({'proj': round(float(u), 2), 'median': None if med is None else round(med, 1), 'ref_line': L, 'p_over_ref': round(po, 4), 'p_hit_ref': round(float((hist > L).mean()), 4) if len(hist) else None, 'n_hit': int(len(hist)), 'confidence': conf, 'cell': cell and {k: cell[k] for k in ('n', 'predicted_side_prob', 'observed_side_rate', 'observed_ci95')},
                       'factors': {'usage': round(float(r['usage']), 2) if np.isfinite(r['usage']) else None, 'season_avg': round(float(r['season_mean']), 2) if np.isfinite(r['season_mean']) else None,
                                   'last5_avg': round(float(r['last5']), 2) if np.isfinite(r['last5']) else None, 'opp_factor': round(float(r['opp_factor']), 3), 'implied_team_points': None if env is None else round(float(r['implied']), 1),
                                   'base': round(float(b), 2)},
                       })
            out.append(pr)
    # team points
    tp = P['markets'].get('pts')
    if tp:
        for _, gm in games.iterrows():
            for team, opp, home in ((gm['home_team'], gm['away_team'], 1), (gm['away_team'], gm['home_team'], 0)):
                if not (pd.notna(gm['total_line']) and pd.notna(gm['spread_line'])): continue
                imp = (gm['total_line'] + (gm['spread_line'] if home else -gm['spread_line'])) / 2; L = math.floor(imp) + 0.5 if imp % 1 else imp - 0.5
                po = float(1 - np.interp(math.floor(L) + 0.5 - imp, tp['q'], RATIO_Q))
                out.append({'id': hashlib.sha1(f"{P['version']}|{gm['game_id']}|{team}|pts".encode()).hexdigest()[:16], 'market': 'pts', 'game_id': gm['game_id'], 'kickoff': gm['ko'].isoformat(),
                            'player_id': team, 'player': team, 'position': 'TEAM', 'team': team, 'opp': opp, 'home': home, 'n_prev': None, 'proj': round(float(imp), 2), 'ref_line': L, 'p_over_ref': round(po, 4),
                            'confidence': label_for(P['confidence_cells'].get(f'pts|11+|{"<5" if abs(po - .5) < .05 else "5-10"}'), P['activation'].get('pts', {}).get('active', False)), 'active_market': P['activation'].get('pts', {}).get('active', False),
                            'factors': {'implied_team_points': round(float(imp), 1)}})
    model = {'schema': 1, 'version': P['version'], 'trained': P['trained'], 'generated': now.isoformat(timespec='seconds'), 'season': int(wk[0]), 'weeks': sorted(set(int(w) for w in games['week'])),
             'experimental': True, 'markets': {m: {'label': LABELS[m], 'active': P['activation'].get(m, {}).get('active', False), 'dist': P['markets'][m]['dist'], 'alpha': P['markets'][m].get('alpha'),
                                                    'ratio': P['markets'][m].get('ratio'), 'ratio_by_pos': P['markets'][m].get('ratio_by_pos'), 'q': P['markets'][m].get('q'), 'calibration': P['markets'][m].get('calibration')} for m in P['markets'] if P['markets'][m]},
             'predictions': out}
    json.dump(model, open(os.path.join(a.site, 'data-nfl-model.json'), 'w'), separators=(',', ':'))
    forward_log(a.site, out, P, now, d, g)
    print(f"{len(out)} predictions for {int(wk[0])} week {int(wk[1])}")

def forward_log(site, preds, P, now, d, g):
    """Forward test. One file per NFL week (data-nfl-forward-<season>-w<week>.json) so old weeks never change again once graded.
    A prediction is added once, before kick-off, and never edited; grading adds the outcome from the official final stats only.
    Corrections to a graded outcome (if nflverse revises a stat) are appended to the file's audit list, never overwritten silently."""
    gw = {r['game_id']: (int(r['season']), int(r['week'])) for _, r in g.iterrows()}
    files = defaultdict(list)
    for pr in preds: files[gw[pr['game_id']]].append(pr)
    finals = set(g[g['home_score'].notna()]['game_id']); col = {m: v[1] for m, v in MARKETS.items()}
    idx = {(r.game_id, r.player_id): r for r in d.itertuples()}; tg = team_games(g); tgi = {(r.game_id, r.team): r for r in tg.itertuples()}
    existing = sorted(f for f in os.listdir(site) if f.startswith('data-nfl-forward-') and f.endswith('.json'))
    keys = set(files) | {(int(f.split('-')[3]), int(f.split('-w')[1][:2])) for f in existing}
    for (season, week) in sorted(keys):
        p = os.path.join(site, f'data-nfl-forward-{season}-w{week:02d}.json')
        log = json.load(open(p)) if os.path.exists(p) else {'schema': 1, 'season': season, 'week': week, 'entries': [], 'audit': []}
        have = {e['id'] for e in log['entries']}
        for pr in files.get((season, week), []):
            if pr.get('confidence') == 'Insufficient Data' or pr['id'] in have or 'p_over_ref' not in pr or not pr.get('active_market'): continue
            if datetime.datetime.fromisoformat(pr['kickoff']) <= now: continue  # never added after kick-off
            log['entries'].append({'id': pr['id'], 'created': now.isoformat(timespec='seconds'), 'model_version': P['version'], 'game_id': pr['game_id'], 'kickoff': pr['kickoff'], 'player_id': pr['player_id'],
                                   'player': pr['player'], 'market': pr['market'], 'line': pr['ref_line'], 'line_source': 'reference', 'p_over': pr['p_over_ref'], 'p_hit': pr.get('p_hit_ref'), 'proj': pr['proj'],
                                   'confidence': pr['confidence'], 'odds': None, 'odds_time': None, 'outcome': None})
        with_stats = set(d['game_id'])
        for e in log['entries']:
            if e['game_id'] not in finals or e['game_id'] not in with_stats: continue  # wait for the official final stats
            if e['market'] == 'pts': r = tgi.get((e['game_id'], e['player_id'])); y = None if r is None else float(r.pts)
            else: r = idx.get((e['game_id'], e['player_id'])); y = None if r is None else float(getattr(r, col[e['market']]))
            new = {'result': 'no stat row (did not play)'} if y is None else {'value': y, 'result': 'over' if y > e['line'] else 'under' if y < e['line'] else 'push'}
            if e['outcome'] is None: e['outcome'] = {**new, 'graded': now.isoformat(timespec='seconds')}
            elif {k: e['outcome'].get(k) for k in new} != new:  # the official stat was revised later: keep the record, log the change
                log['audit'].append({'id': e['id'], 'at': now.isoformat(timespec='seconds'), 'before': e['outcome'], 'after': new}); e['outcome'] = {**new, 'graded': now.isoformat(timespec='seconds'), 'revised': True}
        if log['entries']: json.dump(log, open(p, 'w'), separators=(',', ':'))
    forward_summary(site)

def forward_summary(site):
    """Metrics over every graded forward prediction (never mixed with the backtest)."""
    E = []
    for f in sorted(os.listdir(site)):
        if f.startswith('data-nfl-forward-2') and f.endswith('.json'): E += json.load(open(os.path.join(site, f)))['entries']
    g = [e for e in E if e['outcome'] and e['outcome'].get('result') in ('over', 'under')]
    def block(rows):
        if not rows: return {'n': 0}
        o = np.array([1.0 if e['outcome']['result'] == 'over' else 0.0 for e in rows]); p = np.array([e['p_over'] for e in rows])
        ph = np.array([e['p_hit'] if e.get('p_hit') is not None else 0.5 for e in rows])
        side = np.where(p >= 0.5, o, 1 - o); k = int(side.sum())
        return {'n': len(rows), 'correct': k, 'incorrect': len(rows) - k, 'accuracy': round(k / len(rows), 4), 'accuracy_ci95': list(wilson(k, len(rows))),
                'brier': round(brier(p, o), 5), 'brier_hit_rate': round(brier(ph, o), 5), 'logloss': round(logloss(p, o), 5), 'mae': round(float(np.mean([abs(e['proj'] - e['outcome']['value']) for e in rows])), 3),
                'calibration': calib(p, o)[0]}
    out = {'schema': 1, 'created': datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'), 'logged': len(E), 'graded': len(g),
           'pending': len([e for e in E if not e['outcome']]), 'did_not_play': len([e for e in E if e['outcome'] and e['outcome'].get('result', '').startswith('no stat')]),
           'pushes': len([e for e in E if e['outcome'] and e['outcome'].get('result') == 'push']),
           'overall': block(g), 'by_market': {m: block([e for e in g if e['market'] == m]) for m in sorted({e['market'] for e in g})},
           'by_confidence': {c: block([e for e in g if e['confidence'] == c]) for c in ('Very High', 'High', 'Medium', 'Low', 'Very Low')},
           'by_week': {w: block([e for e in g if e['game_id'][:7] == w]) for w in sorted({e['game_id'][:7] for e in g})},
           'odds_recorded': len([e for e in E if e.get('odds')]), 'note': 'Lines are PropLab reference lines (season medians; 0.5 for touchdowns), not bookmaker lines. No odds were recorded, so no profit, ROI or drawdown can be calculated.'}
    json.dump(out, open(os.path.join(site, 'data-nfl-model-forward.json'), 'w'), separators=(',', ':'))

if __name__ == '__main__':
    ap = argparse.ArgumentParser(); sp = ap.add_subparsers(dest='cmd', required=True)
    b = sp.add_parser('backtest'); b.add_argument('--nfl', required=True); b.add_argument('--out', required=True)
    p = sp.add_parser('predict'); p.add_argument('--nfl', required=True); p.add_argument('--params', required=True); p.add_argument('--site', required=True); p.add_argument('--now')
    a = ap.parse_args()
    cmd_backtest(a) if a.cmd == 'backtest' else cmd_predict(a)
