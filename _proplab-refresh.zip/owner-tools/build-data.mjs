// PropLab data builder (private tool, NOT uploaded to the public site).
// Usage: node build-data.mjs <out-dir> <input-file> [<input-file> ...]
// Reads the data-*.json files already in <out-dir> (if any), validates and merges the input files, and writes the new data-*.json files plus data-manifest.json.
// Rules: blank stays blank (never 0), bad rows are skipped and listed, nothing is invented.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { detect, buildMatchesFromRows, playersFromJson, parseFixtures, parseNews, parseFootballDataCsv, parseFootballDataExtraCsv, tmKey, STAT_FIELDS } from './lib/import.js';
import { normName, normTeam, teamSlug, displayTeam } from './lib/teams.js';
import { LEAGUES } from './lib/football.js';
import { parseDirectoryText, buildDirectory } from './lib/directory.js';

const [, , outDir, ...inputs] = process.argv;
if (!outDir || !inputs.length) { console.error('Usage: node build-data.mjs <out-dir> <input-file>...'); process.exit(2); }
fs.mkdirSync(outDir, { recursive: true });
const now = process.env.PROPLAB_NOW ? new Date(process.env.PROPLAB_NOW) : new Date();
const today = now.toISOString().slice(0, 10), stamp = now.toISOString().replace(/\.\d+Z$/, 'Z');
const rd = f => { const p = path.join(outDir, f); return fs.existsSync(p) ? JSON.parse(fs.readFileSync(p, 'utf8')) : null; };
const wr = (f, o) => fs.writeFileSync(path.join(outDir, f), JSON.stringify(o));
const report = { errors: [], warnings: [], notes: [] };
const dayMinus = n => new Date(now - n * 864e5).toISOString().slice(0, 10);

// ---- load existing ----
const oldManifest = rd('data-manifest.json');
// UK calendar date / time of a UTC instant. The UTC instant is canonical: the stored date and kick-off are always derived from it.
const ukDateOf = iso => new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/London' }).format(new Date(iso));
const ukTimeOf = iso => new Intl.DateTimeFormat('en-GB', { timeZone: 'Europe/London', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(new Date(iso));
// Fixes fixtures published by older versions, which stored the source's local date (e.g. a 7:30pm ET MLS kick-off on 17 Oct = 00:30 UK on 18 Oct under 17 Oct).
const canonFixture = f => { if (!f.ko_utc) return f; const d = ukDateOf(f.ko_utc), t = ukTimeOf(f.ko_utc); if (d === f.date && t === f.kickoff) return f; const o = { ...f, date: d, kickoff: t }; if (f.date !== d && !f.local_date) o.local_date = f.date; return o; };
let fixtures = new Map((rd('data-fixtures.json')?.items || []).map(canonFixture).map(f => [`${f.league}|${f.date}|${normTeam(f.home)}|${normTeam(f.away)}`, f]));
let news = new Map((rd('data-news.json')?.items || []).map(n => [`${normTeam(n.team)}|${normName(n.player)}`, n]));
const teamMatches = new Map(); // `${league}-${season}` -> Map(key -> rec)
for (const e of oldManifest?.team_matches || []) { const d = rd(e.file); if (d) teamMatches.set(`${e.league}-${e.season}`, new Map(d.items.map(r => [tmKey2(r, e), r]))); }
const playerMatches = new Map(); // `${league}-${season}` -> Map(key -> match)
for (const e of oldManifest?.player_matches || []) { const d = rd(e.file); if (d) playerMatches.set(`${e.league}-${e.season}`, new Map(d.matches.map(m => [mkey(m), m]))); }
function tmKey2(r, e) { return `${r.date}|${teamSlug(r.home)}|${teamSlug(r.away)}`; }
function mkey(m) { return `${m.date}|${teamSlug(m.home)}|${teamSlug(m.away)}`; }
const sources = new Map((oldManifest?.sources || []).map(s => [s.id, s]));
let manifestNotes = null;
let directoryInput = null, photosInput = null, linksInput = [];
const roundRows = []; // from rounds-*.txt
const koTimes = []; // from kotimes-*.txt (4 Nov 2026)
const fxRun = new Set(), fxFull = new Set(); // fixture keys given by this run's inputs; leagues whose whole schedule was given
const touched = { fixtures: false, news: false, tm: new Set(), pm: new Set() };

// ---- process inputs ----
for (const file of inputs) {
  const text = fs.readFileSync(file, 'utf8'); const base = path.basename(file);
  if (base === 'sources.json') { const sj = JSON.parse(text); for (const x of sj.sources || []) sources.set(x.id, x); if (sj.notes) manifestNotes = sj.notes; continue; }
  if (/^directory.*\.txt$|^(epl|mls)-.*\.txt$/.test(base)) { const dlg = base.startsWith('mls') ? 'mls' : 'epl'; const built = buildDirectory(parseDirectoryText(text), { league: dlg }); built.league = dlg; built.nightly = /-squads-wikipedia\.txt$/.test(base); (directoryInput ||= []).push(built); const directoryInput1 = built; directoryInput1.errors.forEach(e => report.errors.push(`${base}: ${e}`)); report.notes.push(`${base}: read as ${dlg} player directory (${directoryInput1.items.length} players, ${directoryInput1.clubs.length} clubs)`); continue; }
  if (/^player-links.*\.json$/.test(base)) { linksInput = JSON.parse(text).links || []; report.notes.push(`${base}: ${linksInput.length} hand-checked name links`); continue; }
  if (/^photos.*\.json$/.test(base)) { photosInput = JSON.parse(text); report.notes.push(`${base}: ${Object.keys(photosInput.items || {}).length} player photos`); continue; }
  let mres = /^results-([a-z0-9]+)-(\d{4})(?:-[a-z]+)?\.txt$/.exec(base);
  if (mres) { // simple verified results: YYYY-MM-DD|Home|Away|HG|AG (goals only; other stats unknown = null)
    const [, lg, season] = mres; const k = `${lg}-${season}`; if (!teamMatches.has(k)) teamMatches.set(k, new Map()); let n = 0;
    text.split(/\r?\n/).forEach((line, i) => { const t = line.trim(); if (!t || t.startsWith('#')) return; const [date, h, a, hg, ag, src] = t.split('|').map(x => x.trim());
      const ok = /^\d{4}-\d{2}-\d{2}$/.test(date) && h && a && normTeam(h) !== normTeam(a) && /^\d{1,2}$/.test(hg) && /^\d{1,2}$/.test(ag);
      if (!ok) { report.errors.push(`${base} line ${i + 1}: cannot read "${t}"`); return; }
      const rec = { date, home: displayTeam(h), away: displayTeam(a), referee: null, hg: +hg, ag: +ag, hthg: null, htag: null, hs: null, as: null, hst: null, ast: null, hf: null, af: null, hc: null, ac: null, hy: null, ay: null, hr: null, ar: null, source: src || undefined };
      const key = tmKey2(rec); const old = teamMatches.get(k).get(key); if (old && (old.hg !== rec.hg || old.ag !== rec.ag)) report.errors.push(`${base}: ${key} already published with ${old.hg}-${old.ag}, input says ${hg}-${ag}; kept the published score`); else if (!old) { teamMatches.get(k).set(key, rec); n++; } });
    touched.tm.add(k); report.notes.push(`${base}: ${n} new results for ${lg} ${season}`); continue;
  }
  let mev = /^events-([a-z0-9]+)-(\d{4})\.json$/.exec(base);
  if (mev) { // completed matches with half-time score and goal events (scorer, minute, pen/og). Never changes a published score.
    const [, lg, season] = mev; const k = `${lg}-${season}`; if (!teamMatches.has(k)) teamMatches.set(k, new Map()); const mp = teamMatches.get(k); const j = JSON.parse(text); let added = 0, upd = 0;
    for (const it of j.items || []) {
      const rec0 = { date: it.date, home: displayTeam(it.home), away: displayTeam(it.away) }; const key = tmKey2(rec0);
      const goals = Array.isArray(it.goals) ? it.goals.filter(g => /^\d{1,3}(\+\d{1,2})?$/.test(String(g.min)) && ['home', 'away'].includes(g.team) && g.player && ['', 'pen', 'og'].includes(g.type || '')) : [];
      const gh = goals.filter(g => g.team === 'home').length, ga = goals.filter(g => g.team === 'away').length;
      if (goals.length && (gh !== it.hg || ga !== it.ag)) { report.errors.push(`${base}: ${key} goal list (${gh}-${ga}) does not add up to the score ${it.hg}-${it.ag}; events skipped`); continue; }
      if (it.hthg != null && (it.hthg > it.hg || it.htag > it.ag)) { report.errors.push(`${base}: ${key} half-time score above full time; skipped`); continue; }
      const old = mp.get(key);
      if (old) { if (old.hg !== it.hg || old.ag !== it.ag) { report.errors.push(`${base}: ${key} already published with ${old.hg}-${old.ag}, input says ${it.hg}-${it.ag}; kept the published record`); continue; }
        if (old.hthg == null && it.hthg != null) { old.hthg = it.hthg; old.htag = it.htag; } if (it.ko_utc && !old.ko_utc) old.ko_utc = it.ko_utc; if (it.stage && !old.stage) old.stage = String(it.stage).slice(0, 40); if (it.aet_score && !old.aet_score) old.aet_score = it.aet_score; if (goals.length) { old.goals = goals; old.goals_source = j.source || base; } upd++; }
      else { mp.set(key, { ...rec0, referee: null, hg: it.hg, ag: it.ag, hthg: it.hthg ?? null, htag: it.htag ?? null, hs: null, as: null, hst: null, ast: null, hf: null, af: null, hc: null, ac: null, hy: null, ay: null, hr: null, ar: null, source: j.source || base, ...(goals.length ? { goals, goals_source: j.source || base } : {}), ...(it.stage ? { stage: String(it.stage).slice(0, 40) } : {}), ...(it.aet_score ? { aet_score: it.aet_score } : {}), ...(it.ko_utc ? { ko_utc: it.ko_utc } : {}) }); added++; }
    }
    touched.tm.add(k); report.notes.push(`${base}: ${added} new matches, ${upd} updated with half-time score / goal events (${lg} ${season})`); continue;
  }
  let mts = /^teamstats-([a-z0-9]+)-(\d{4})\.json$/.exec(base);
  if (mts) { // per-match team stats to add to already-published results (only when the score agrees); values already published are never overwritten
    const [, lg, season] = mts; const k = `${lg}-${season}`; const mp = teamMatches.get(k); const j = JSON.parse(text); let n = 0;
    if (!mp) { report.errors.push(`${base}: no published ${lg} ${season} results to add stats to`); continue; }
    for (const it of j.items || []) {
      const key = tmKey2({ home: displayTeam(it.home), away: displayTeam(it.away), date: it.date }); const rec = mp.get(key);
      if (!rec) { report.errors.push(`${base}: ${key} not among published results; skipped`); continue; }
      if (rec.hg !== it.hg || rec.ag !== it.ag) { report.errors.push(`${base}: ${key} score ${it.hg}-${it.ag} differs from published ${rec.hg}-${rec.ag}; stats skipped`); continue; }
      const ok = v => v === null || v === undefined || (Number.isInteger(v) && v >= 0 && v <= 60);
      if (!['hs', 'as', 'hst', 'ast'].every(f => ok(it[f])) || (it.hst != null && it.hs != null && it.hst > it.hs) || (it.ast != null && it.as != null && it.ast > it.as)) { report.errors.push(`${base}: ${key} impossible stats; skipped`); continue; }
      let changed = false; for (const f of ['hs', 'as', 'hst', 'ast']) if ((rec[f] === null || rec[f] === undefined) && it[f] != null) { rec[f] = it[f]; changed = true; }
      if (changed) { rec.stats_source = j.source || base; n++; }
    }
    touched.tm.add(k); report.notes.push(`${base}: team stats added to ${n} ${lg} ${season} matches`); continue;
  }
  if (/^fixture-status-.*\.txt$/.test(base)) { // league|UK date|home|away|postponed or abandoned|new date (optional): a fixture whose date passed without a result
    let n = 0; text.split(/\r?\n/).forEach(line => { const t = line.trim(); if (!t || t.startsWith('#')) return; const [league, date, h, a, st, nd] = t.split('|').map(x => x.trim());
      if (!['postponed', 'abandoned'].includes(st)) return; const k = `${league}|${date}|${normTeam(h)}|${normTeam(a)}`; const f = fixtures.get(k); if (!f) return;
      f.status = st; if (nd) f.new_date = nd; f.status_source = 'Wikipedia season article'; n++; });
    touched.fixtures = true; report.notes.push(`${base}: ${n} fixtures marked postponed/abandoned`); continue;
  }
  if (/^rounds-.*\.txt$/.test(base)) { // league|round|UK date|home|away (full season calendar, played matches included)
    let n = 0; text.split(/\r?\n/).forEach((line, i) => { const t = line.trim(); if (!t || t.startsWith('#')) return; const [league, r, date, h, a] = t.split('|').map(x => x.trim());
      if (!LEAGUES[league] && league !== 'epl' || !/^\d+$/.test(r) || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !h || !a) { report.errors.push(`${base} line ${i + 1}: cannot read "${t}"`); return; }
      roundRows.push({ league, round: Number(r), date, pair: `${league}|${normTeam(h)}|${normTeam(a)}` }); n++; });
    touched.fixtures = true; report.notes.push(`${base}: ${n} matches in the round calendar`); continue;
  }
  if (/^kotimes-.*\.txt$/.test(base)) { // 4 Nov 2026: kick-off times only (same columns as fixtures-*.txt), applied after every input; never adds a fixture
    text.split(/\r?\n/).forEach(line => { const t = line.trim(); if (!t || t.startsWith('#')) return; const [league, date, ko, h, a, , src] = t.split('|').map(x => x.trim());
      if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:00Z$/.test(ko || '') && h && a) koTimes.push({ base, league, ko, h, a, src: src || base }); });
    continue;
  }
  if (/^fixtures-.*\.txt$/.test(base)) { // league|YYYY-MM-DD (local date)|kickoff UTC ISO|Home|Away|venue|source
    const fullSeason = /openfootball|wikipedia|^fixtures-mls-/.test(base); // complete season schedules (not next-round-only files)
    let n = 0; text.split(/\r?\n/).forEach((line, i) => { const t = line.trim(); if (!t || t.startsWith('#')) return; const [league, date, ko, h, a, venue, src] = t.split('|').map(x => x.trim());
      if (!LEAGUES[league] && league !== 'mls' && league !== 'epl' || !/^\d{4}-\d{2}-\d{2}$/.test(date) || (ko && !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:00Z$/.test(ko)) || !h || !a) { report.errors.push(`${base} line ${i + 1}: cannot read "${t}"`); return; }
      // The UTC instant decides the UK date; the date column is only trusted for matches without a time (TBC).
      const uk = ko ? ukTimeOf(ko) : '', ukDate = ko ? ukDateOf(ko) : date; // blank kick-off = time not yet set
      if (ko && Math.abs(Date.parse(ukDate) - Date.parse(date)) > 864e5) { report.errors.push(`${base} line ${i + 1}: date ${date} and kick-off ${ko} are more than a day apart; skipped`); return; }
      for (const k of [...fixtures.keys()]) if (k.startsWith(`${league}|${date}|${normTeam(h)}|${normTeam(a)}`) && date !== ukDate) fixtures.delete(k); // an older copy filed under the local date
      fxRun.add(`${league}|${ukDate}|${normTeam(h)}|${normTeam(a)}`); if (fullSeason) fxFull.add(league);
      const prevFx = fixtures.get(`${league}|${ukDate}|${normTeam(h)}|${normTeam(a)}`);
      if (!ko && prevFx?.ko_utc) { n++; return; } // a date-only copy (e.g. Wikipedia) never replaces a known kick-off time for the same day
      fixtures.set(`${league}|${ukDate}|${normTeam(h)}|${normTeam(a)}`, { league, date: ukDate, kickoff: uk, ...(ukDate !== date ? { local_date: date } : {}), ...(ko ? { ko_utc: ko } : {}), home: displayTeam(h), away: displayTeam(a), referee: '', venue: venue || '', source: src || '' }); n++; touched.fixtures = true; });
    report.notes.push(`${base}: ${n} fixtures`); continue;
  }
  const d = detect(text, base);
  const note = m => report.notes.push(`${base}: ${m}`);
  const errs = (arr, label = '') => arr.forEach(e => report.errors.push(`${base} ${label}row ${e.row}: ${e.msg}`));
  if (d.kind === 'unknown' || d.kind === 'empty') { report.errors.push(`${base}: ${d.why || 'empty file'}`); continue; }
  if (d.kind === 'fd-results-only') { report.errors.push(`${base}: results-only file, no stats`); continue; }
  let rows = [], fx = [], nw = [], tm = [], j = null;
  if (d.kind === 'json') {
    j = d.json; const p = playersFromJson(j); rows = p.rows; errs(p.errors);
    if (Array.isArray(j.fixtures)) { const f = parseFixtures(j.fixtures.map((x, i) => ({ ...x, _row: `fixture ${i + 1}` }))); fx = f.items; errs(f.errors, 'fixture '); }
    if (Array.isArray(j.team_news)) { const n = parseNews(j.team_news.map((x, i) => ({ ...x, _row: `news ${i + 1}` }))); nw = n.items; errs(n.errors, 'news '); }
  } else if (d.kind === 'players-csv') rows = d.records;
  else if (d.kind === 'fixtures-csv') { const f = parseFixtures(d.records); fx = f.items; errs(f.errors); }
  else if (d.kind === 'news-csv') { const n = parseNews(d.records); nw = n.items; errs(n.errors); }
  else if (d.kind === 'fd-csv') { const t = parseFootballDataCsv(d.records); tm = t.items; errs(t.errors); t.skippedDivs.forEach(([dv, c]) => report.warnings.push(`${base}: skipped ${c} rows of division ${dv}`)); }
  else if (d.kind === 'fd-extra') { const t = parseFootballDataExtraCsv(d.records, { firstSeason: 2021 }); tm = t.items; errs(t.errors); report.notes.push(`${base}: ${tm.length} final scores (other countries in the file ignored: ${t.skippedDivs.length})`); } // 27 Oct: Eliteserien, score only

  if (rows.length) {
    const b = buildMatchesFromRows(rows, { defaultSource: j?.source || base }); errs(b.errors); b.warnings.forEach(w => report.warnings.push(`${base}: ${w}`));
    for (const m of b.matches) {
      const k = `${m.league}-${m.season}`; if (!playerMatches.has(k)) playerMatches.set(k, new Map());
      const rec = { date: m.date, home: displayTeam(m.home), away: displayTeam(m.away), referee: m.referee || null, complete: m.complete === true, source: m.source || base,
        players: [...m.rows.values()].map(r => { const o = { team: displayTeam(r.teamName), name: r.name, position: r.position, minutes: r.minutes, started: r.started }; if (r.spid) o.spid = r.spid; for (const f of STAT_FIELDS) if (r[f] !== null && r[f] !== undefined) o[f] = r[f]; return o; }) };
      playerMatches.get(k).set(mkey(rec), rec); touched.pm.add(k);
    }
  }
  for (const f of fx) { if (f.date < dayMinus(1)) continue; fixtures.set(`${f.league}|${f.date}|${normTeam(f.home)}|${normTeam(f.away)}`, { ...f, home: displayTeam(f.home), away: displayTeam(f.away) }); touched.fixtures = true; }
  for (const n of nw) { const k = `${normTeam(n.team)}|${normName(n.player)}`; const o = news.get(k); if (!o || n.asOf >= o.as_of) news.set(k, { team: displayTeam(n.team), player: n.player, status: n.status, detail: n.detail, as_of: n.asOf, source: n.source }); touched.news = true; }
  for (const r of tm) {
    const k = `${r.league}-${r.season}`; if (!teamMatches.has(k)) teamMatches.set(k, new Map());
    const { league, season, ...rest } = r; const old = teamMatches.get(k).get(tmKey2(r));
    if (old && /Wikipedia/.test(old.source || '') && (old.hg !== r.hg || old.ag !== r.ag)) report.errors.push(`${base}: ${tmKey2(r)} Wikipedia score ${old.hg}-${old.ag} replaced by football-data.co.uk ${r.hg}-${r.ag} (statistics source wins; check the match)`);
    else if (old && old.hg !== null && (old.hg !== r.hg || old.ag !== r.ag)) { report.errors.push(`${base}: ${tmKey2(r)} already published with ${old.hg}-${old.ag}, input says ${r.hg}-${r.ag}; kept the published record`); continue; }
    if (old && ((r.hst !== null && r.hs !== null && r.hst > r.hs) || (r.ast !== null && r.as !== null && r.ast > r.as))) { report.errors.push(`${base}: ${tmKey2(r)} has more shots on target than shots in the input; stats row skipped, the published record (goals) kept`); continue; }
    teamMatches.get(k).set(tmKey2(r), { ...rest, home: displayTeam(r.home), away: displayTeam(r.away), source: 'football-data.co.uk', ...(old?.goals ? { goals: old.goals, goals_source: old.goals_source } : {}), ...(rest.hthg == null && old?.hthg != null ? { hthg: old.hthg, htag: old.htag } : {}), ...(!rest.ko_utc && old?.ko_utc ? { ko_utc: old.ko_utc, ...(old.ko_source ? { ko_source: old.ko_source } : {}) } : {}) }); touched.tm.add(k);
  }
  if (j?.source) sources.set('src:' + base, { id: 'src:' + base, name: j.source, url: '', used_for: base });
  note(`read as ${d.kind}`);
}

// ---- extra validation of what we are about to publish: impossible rows are removed (never repaired) and listed ----
for (const [k, mp] of teamMatches) for (const [kk, r] of [...mp]) {
  const probs = [];
  const pair = (a, b, l) => { if (a !== null && b !== null && a > b) probs.push(`${l} exceeds total`); };
  pair(r.hst, r.hs, 'home shots on target'); pair(r.ast, r.as, 'away shots on target'); pair(r.hthg ?? null, r.hg, 'home half-time goals'); pair(r.htag ?? null, r.ag, 'away half-time goals');
  for (const f of ['hg', 'ag', 'hs', 'as', 'hf', 'af', 'hc', 'ac', 'hy', 'ay', 'hr', 'ar']) if (r[f] !== null && (r[f] < 0 || r[f] > 60)) probs.push(`${f}=${r[f]} out of range`);
  if (probs.length) { mp.delete(kk); report.errors.push(`SKIPPED ${k} ${kk}: ${probs.join(', ')}`); }
}

// A score-only record from Wikipedia filed under a date that later turned out different (e.g. a rearranged match) would double up with the
// football-data.co.uk record: same home and away within 10 days -> keep football-data.co.uk.
// 9 Nov 2026 (Nacional v Académico de Viseu, filed under Sat 7 Nov from PropLab's fixture calendar, played Sun 8 Nov): such a move is a
// correction of a published record, so it is written to data-results-reconciliation.json (an append-only audit log, published) and
// validate.py accepts the old record's disappearance ONLY when this log explains it with the same score. A different score is never
// reconciled automatically: both records are kept, the run reports it and validation stops publication until someone reviews it.
const reconPath = path.join(outDir, 'data-results-reconciliation.json');
const recon = fs.existsSync(reconPath) ? JSON.parse(fs.readFileSync(reconPath, 'utf8')) : { schema: 1, note: 'Corrections to published results: a score-only record replaced by a fuller record of the same match on another date. Append-only; a different score is never reconciled automatically.', items: [] };
const reconAt = new Date().toISOString().slice(0, 19) + 'Z'; let reconNew = 0;
for (const [k, mp] of teamMatches) {
  const byPair = new Map(); for (const [kk, r] of mp) { const pk = `${teamSlug(r.home)}|${teamSlug(r.away)}`; if (!byPair.has(pk)) byPair.set(pk, []); byPair.get(pk).push([kk, r]); }
  for (const list of byPair.values()) if (list.length > 1) for (const [kk, r] of list) if (/Wikipedia/.test(r.source || '')) for (const [kk2, g] of list)
    if (kk2 !== kk && mp.has(kk) && mp.has(kk2) && !/Wikipedia/.test(g.source || '') && Math.abs(Date.parse(r.date) - Date.parse(g.date)) <= 10 * 864e5) {
      if (r.hg !== g.hg || r.ag !== g.ag) { report.errors.push(`RESULT CONFLICT ${k}: Wikipedia score ${r.hg}-${r.ag} (${r.date}) differs from ${g.source} ${g.hg}-${g.ag} (${g.date}) for ${r.home} v ${r.away}; both kept for review`); continue; }
      const lg = k.slice(0, k.lastIndexOf('-')), season = k.slice(k.lastIndexOf('-') + 1);
      if (r.date !== g.date) { recon.items.push({ at: reconAt, league: lg, season: Number(season), home: r.home, away: r.away, hg: r.hg, ag: r.ag, from: { date: r.date, source: r.source }, to: { date: g.date, source: g.source },
        reason: `the score-only record was filed under ${r.date} from PropLab's fixture calendar; ${g.source} dates the match ${g.date} with the same score` }); reconNew++; }
      report.notes.push(`${k}: ${r.home} v ${r.away} score-only record of ${r.date} replaced by the ${g.source} record of ${g.date}${r.date !== g.date ? ' (date corrected; logged in data-results-reconciliation.json)' : ''}`);
      mp.delete(kk);
    }
}
if (reconNew || fs.existsSync(reconPath)) wr('data-results-reconciliation.json', recon);

// ---- prune + write ----
// A match moved to a new date can appear twice (season file with the old date, next-round file with the new one). Same league, home and away
// within 45 days: keep the football-data.co.uk next-round entry (the most recent information) and report the other.
{ const byPair = new Map(); for (const [k, f] of fixtures) { const pk = `${f.league}|${normTeam(f.home)}|${normTeam(f.away)}`; if (!byPair.has(pk)) byPair.set(pk, []); byPair.get(pk).push([k, f]); }
  for (const list of byPair.values()) if (list.length > 1) for (const [k, f] of list) for (const [k2, g] of list) if (k !== k2 && fixtures.has(k) && fixtures.has(k2) && Math.abs(Date.parse(f.date) - Date.parse(g.date)) <= 45 * 864e5 && /football-data/.test(g.source) && !/football-data/.test(f.source)) { fixtures.delete(k); report.notes.push(`fixture ${k} replaced by the rescheduled ${g.date} entry`); } }
// A league whose complete schedule was given in this run: an upcoming fixture from an earlier build that no input lists any more
// (moved to another date, or cancelled) is removed and reported. Matches already played are never touched here.
const notStarted = f => (f.ko_utc ? Date.parse(f.ko_utc) > now.getTime() : f.date > today);
// 4 Nov 2026: an MLS fixture's local_date is the calendar date at its stadium (venue named in the fixture, else the home club's stadium),
// worked out from the UTC kick-off; the schedule source's own date column is Eastern Time. A named stadium that is not in
// data-src/mls/venue-timezones.json gets no computed local date (listed, never guessed). ko_utc stays the authoritative instant.
{ let tzs = null; try { tzs = JSON.parse(fs.readFileSync(new URL('../data-src/mls/venue-timezones.json', import.meta.url), 'utf8')); } catch { report.warnings.push('MLS venue time zones not readable; local dates left as the source gave them'); }
  if (tzs) { let set = 0, changed = 0; const unknown = [];
    for (const f of fixtures.values()) { if (f.league !== 'mls' || !f.ko_utc) continue;
      const tz = f.venue ? tzs.venues[f.venue] : tzs.clubs[f.home];
      if (!tz) { unknown.push(`${f.date} ${f.home} v ${f.away} (${f.venue || 'no stadium named; club not listed'})`); continue; }
      const loc = new Intl.DateTimeFormat('en-CA', { timeZone: tz }).format(new Date(f.ko_utc)), was = f.local_date || f.date;
      if (loc !== was) changed++; if (loc !== f.date) f.local_date = loc; else delete f.local_date; f.local_tz = tz; set++; }
    report.notes.push(`MLS local dates: ${set} fixtures dated by their stadium's time zone (${changed} differed from the source's date)`);
    if (unknown.length) report.warnings.push(`MLS: ${unknown.length} fixture(s) with no known stadium time zone, local date not worked out: ${unknown.slice(0, 5).join('; ')}`); } }
// Kick-off times from a second source fill in a date-only fixture only when both sources give the same UK date. A different date means one
// of them is out of date (e.g. a rearranged match), so the time is not used and the disagreement is listed. Times already known are kept.
if (koTimes.length) { let used = 0, known = 0, differ = [], none = 0;
  for (const x of koTimes) { const d = ukDateOf(x.ko), k = `${x.league}|${d}|${normTeam(x.h)}|${normTeam(x.a)}`, f = fixtures.get(k);
    if (f) { const mine = (f.source || '').endsWith(`; kick-off time: ${x.src}`); if (f.ko_utc && !(mine && f.ko_utc !== x.ko)) { known++; continue; } /* a time this source gave earlier is revised by it */ if (!notStarted({ ko_utc: x.ko })) continue; f.ko_utc = x.ko; f.kickoff = ukTimeOf(x.ko); if (!mine) f.source = `${(f.source || '').replace(/,? ?date only: kick-off time to be confirmed/, '')}; kick-off time: ${x.src}`; used++; continue; }
    if (Date.parse(x.ko) <= now.getTime()) continue;
    const other = [...fixtures.values()].find(g => g.league === x.league && normTeam(g.home) === normTeam(x.h) && normTeam(g.away) === normTeam(x.a) && notStarted(g) && Math.abs(Date.parse(g.date) - Date.parse(d)) <= 45 * 864e5);
    if (other) differ.push(`${x.league} ${displayTeam(x.h)} v ${displayTeam(x.a)}: ${x.src} ${d}, published ${other.date}`); else none++; }
  report.notes.push(`kick-off times: ${used} fixtures given a time (or re-timed by the same source), ${known} already had one, ${differ.length} not used because the dates disagree, ${none} not in the published schedule`);
  if (differ.length) report.warnings.push(`kick-off times not used, dates disagree between sources: ${differ.slice(0, 8).join('; ')}`); }
for (const [k, f] of [...fixtures]) if (fxFull.has(f.league) && notStarted(f) && !fxRun.has(k)) { fixtures.delete(k); report.notes.push(`fixture removed (no longer in the ${f.league} schedule): ${f.date} ${f.home} v ${f.away}`); }
// 9 Nov 2026: provisional fixtures (a source that gives one date for a whole round and no times, e.g. openfootball's Süper Lig text).
// They are kept, labelled, and never given a time. One goes as soon as something better is known for the same pairing within 10 days:
// a confirmed fixture (football-data, a timed source), a published result (the match was played), or a newer provisional date from the
// source itself. So a pairing is never listed twice.
{ const prov = f => /provisional date/.test(f.source || ''), pairOf = f => `${f.league}|${normTeam(f.home)}|${normTeam(f.away)}`, near = (a, b) => Math.abs(Date.parse(a) - Date.parse(b)) <= 10 * 864e5;
  const played = new Map(); for (const [lk, m] of teamMatches) { const lg = lk.slice(0, lk.lastIndexOf('-')); for (const r of m.values()) { const p = `${lg}|${normTeam(r.home)}|${normTeam(r.away)}`; if (!played.has(p)) played.set(p, []); played.get(p).push(r.date); } }
  const byPair = new Map(); for (const [k, f] of fixtures) { const p = pairOf(f); if (!byPair.has(p)) byPair.set(p, []); byPair.get(p).push([k, f]); }
  const gone = { confirmed: 0, played: 0, moved: 0 };
  for (const [k, f] of [...fixtures]) { if (!prov(f)) continue; const p = pairOf(f), mates = byPair.get(p) || [];
    if (mates.some(([k2, g]) => k2 !== k && !prov(g) && near(g.date, f.date))) { fixtures.delete(k); gone.confirmed++; continue; }
    if ((played.get(p) || []).some(d => near(d, f.date))) { fixtures.delete(k); gone.played++; continue; }
    if (!fxRun.has(k) && mates.some(([k2, g]) => k2 !== k && prov(g) && fxRun.has(k2))) { fixtures.delete(k); gone.moved++; } }
  if (gone.confirmed + gone.played + gone.moved) report.notes.push(`provisional fixtures replaced: ${gone.confirmed} by a confirmed fixture, ${gone.played} by a published result, ${gone.moved} by a newer provisional date`); }
// Round calendars: each round's window is the span of its match dates, ignoring single matches moved far away from the rest of the round
// (more than 4 days from the round's median date, e.g. a postponed game). Fixtures are tagged with their round by home/away pairing.
const oldRounds = rd('data-fixtures.json')?.rounds || {};
const rounds = roundRows.length ? {} : oldRounds;
if (roundRows.length) {
  const byLg = new Map(); for (const x of roundRows) { if (!byLg.has(x.league)) byLg.set(x.league, new Map()); const m = byLg.get(x.league); if (!m.has(x.round)) m.set(x.round, []); m.get(x.round).push(x.date); }
  for (const [lg, m] of byLg) rounds[lg] = [...m.entries()].sort((a, b) => a[0] - b[0]).map(([r, ds]) => { ds.sort(); const med = Date.parse(ds[Math.floor(ds.length / 2)]);
    const core = ds.filter(d => Math.abs(Date.parse(d) - med) <= 4 * 864e5); return { r, from: core[0], to: core[core.length - 1], n: ds.length }; });
  for (const lg of Object.keys(oldRounds)) if (!rounds[lg]) rounds[lg] = oldRounds[lg];
}
{ const pr = new Map(roundRows.map(x => [x.pair, x.round])); let tagged = 0; const miss = [];
  for (const f of fixtures.values()) { const r = pr.get(`${f.league}|${normTeam(f.home)}|${normTeam(f.away)}`); if (r) { f.round = r; tagged++; } else if (roundRows.length && rounds[f.league] && f.date >= dayMinus(1)) miss.push(`${f.league} ${f.home} v ${f.away}`); }
  if (roundRows.length) { report.notes.push(`round calendar: ${tagged} fixtures tagged with their round`); if (miss.length) report.notes.push(`round calendar: ${miss.length} upcoming fixtures not found in it (dated by window instead): ${miss.slice(0, 5).join('; ')}`); } }
const fxItems = [...fixtures.values()].filter(f => f.date >= dayMinus(1)).sort((a, b) => (a.date + a.kickoff < b.date + b.kickoff ? -1 : 1));
const newsItems = [...news.values()].filter(n => n.as_of >= dayMinus(45)).sort((a, b) => (a.team < b.team ? -1 : 1));
const manifest = { schema: 1, generated: stamp, fixtures: null, news: null, directory: null, team_matches: [], player_index: null, player_matches: [], sources: [], notes: [] };
const upd = (flag, old) => (flag ? today : old || today);
wr('data-fixtures.json', { schema: 1, updated: upd(touched.fixtures, rd('data-fixtures.json')?.updated), items: fxItems, ...(Object.keys(rounds).length ? { rounds } : {}) });
manifest.fixtures = { file: 'data-fixtures.json', count: fxItems.length, updated: upd(touched.fixtures, oldManifest?.fixtures?.updated) };
wr('data-news.json', { schema: 1, updated: upd(touched.news, rd('data-news.json')?.updated), items: newsItems });
manifest.news = { file: 'data-news.json', count: newsItems.length, updated: upd(touched.news, oldManifest?.news?.updated) };

// Fixture -> result kick-off (owner audit 26 Oct, MLS dates): a result whose source gives only a date (e.g. American Soccer Analysis, US date)
// takes the exact kick-off instant of the published fixture it replaces, matched by competition and both clubs within one day. Never guessed:
// no matching fixture with a time = no time.
{ const fxBy = new Map(); for (const f of fixtures.values()) if (f.ko_utc) { const k2 = `${f.league}|${normTeam(f.home)}|${normTeam(f.away)}`; if (!fxBy.has(k2)) fxBy.set(k2, []); fxBy.get(k2).push(f); }
  let carried = 0;
  for (const [k, mp] of teamMatches.entries()) for (const it of mp.values()) {
    if (it.ko_utc) continue; const cands = fxBy.get(`${k.split('-')[0]}|${normTeam(it.home)}|${normTeam(it.away)}`) || [];
    const f = cands.find(x => Math.abs(Date.parse(x.date + 'T12:00:00Z') - Date.parse(it.date + 'T12:00:00Z')) <= 864e5);
    if (f) { it.ko_utc = f.ko_utc; it.ko_source = 'published fixture'; touched.tm.add(k); carried++; } }
  if (carried) report.notes.push(`kick-off times: ${carried} results took the exact kick-off of their published fixture`); }
for (const [k, mp] of [...teamMatches.entries()].sort()) {
  const [league, season] = k.split('-'); const items = [...mp.values()].sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0)); const file = `data-team-matches-${league}-${season}.json`;
  const old = (oldManifest?.team_matches || []).find(e => e.file === file);
  const updated = touched.tm.has(k) ? today : old?.updated || today;
  wr(file, { schema: 1, league, season: Number(season), updated, items });
  manifest.team_matches.push({ league, season: Number(season), file, count: items.length, through: items[items.length - 1].date, updated });
}
const idx = new Map();
for (const [k, mp] of [...playerMatches.entries()].sort()) {
  const [league, season] = k.split('-'); const matches = [...mp.values()].sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0)); const file = `data-matches-${league}-${season}.json`;
  const old = (oldManifest?.player_matches || []).find(e => e.file === file); const updated = touched.pm.has(k) ? today : old?.updated || today;
  wr(file, { schema: 1, league, season: Number(season), updated, matches });
  const rowsN = matches.reduce((s, m) => s + m.players.length, 0);
  manifest.player_matches.push({ league, season: Number(season), file, matches: matches.length, rows: rowsN, through: matches[matches.length - 1].date, updated });
  for (const m of matches) for (const p of m.players) {
    // One entry per person: the source's own player id when it has one (so a player who changed clubs keeps all his logs), otherwise name + club.
    const idAt = `${normName(p.name).replace(/ /g, '-')}--${teamSlug(p.team)}`; const gk = p.spid || idAt;
    const e = idx.get(gk) || { id: idAt, name: p.name, team: p.team, league, pos: p.position || null, n: 0, last: '', seasons: [], spid: p.spid || null, clubs: [] };
    e.n++; if (m.date >= e.last) { e.last = m.date; e.team = p.team; e.id = idAt; e.name = p.name; e.pos = p.position || e.pos; } if (!e.seasons.includes(Number(season))) e.seasons.push(Number(season)); if (!e.clubs.includes(p.team)) e.clubs.push(p.team); idx.set(gk, e);
  }
}
// Link match-log players to directory players when the source spells the name differently (e.g. "Heung-Min Son" / "Son Heung-min"):
// same club and the same set of name words, or (if unique within the club) same surname and first initial. Otherwise the player keeps his own id.
{
  const dirNow = rd('data-directory.json')?.items || [];
  const toks = n => normName(n).split(' ').filter(Boolean).sort().join(' ');
  const byClub = new Map(); for (const d of dirNow) { const k = teamSlug(d.team); if (!byClub.has(k)) byClub.set(k, []); byClub.get(k).push(d); }
  const merged = new Map();
  for (const e of idx.values()) {
    const club = byClub.get(teamSlug(e.team)) || []; let d = club.find(x => x.id === e.id) || club.find(x => toks(x.name) === toks(e.name));
    if (!d) { const L = linksInput.find(l => teamSlug(l.team) === teamSlug(e.team) && normName(l.source_name) === normName(e.name)); if (L) { d = club.find(x => x.name === L.directory_name); if (!d) report.errors.push(`player-links: "${L.directory_name}" (${L.team}) is not in the directory`); } }
    if (!d) { const w = normName(e.name).split(' '); const c = club.filter(x => { const v = normName(x.name).split(' '); return v[v.length - 1] === w[w.length - 1] && v[0][0] === w[0][0]; }); if (c.length === 1) d = c[0]; }
    const id = d ? d.id : e.id; const cur = merged.get(id);
    const rec = cur ? { ...cur, n: cur.n + e.n, last: cur.last > e.last ? cur.last : e.last, seasons: [...new Set([...cur.seasons, ...e.seasons])], clubs: [...new Set([...(cur.clubs || []), ...(e.clubs || [])])], spids: [...new Set([...(cur.spids || []), ...(e.spid ? [e.spid] : [])])], src_names: [...new Set([...cur.src_names, e.name])] } : { ...e, id, name: d ? d.name : e.name, src_names: [e.name], spids: e.spid ? [e.spid] : [] };
    if (d && e.name !== d.name) report.notes.push(`linked "${e.name}" (${e.team}) to directory player "${d.name}"`);
    merged.set(id, rec);
  }
  idx.clear(); for (const [k, v] of merged) idx.set(k, v);
}
const idxItems = [...idx.values()].map(({ spid, ...x }) => ({ ...x, ...(x.clubs && x.clubs.length > 1 ? {} : { clubs: undefined }), ...(x.spids && x.spids.length ? {} : { spids: undefined }) })).sort((a, b) => (a.name < b.name ? -1 : 1));
wr('data-players.json', { schema: 1, updated: today, items: idxItems });
manifest.player_index = { file: 'data-players.json', count: idxItems.length, updated: today };
const oldDir = rd('data-directory.json');
{
  const old = rd('data-directory.json');
  let items = old?.items || [], clubs = (old?.clubs || []).map(c => ({ league: c.league || 'epl', ...c })), leagueMeta = old?.leagues || (old ? { epl: { updated: old.updated, source: old.source } } : {});
  for (const d of directoryInput || []) {
    if (!d.items.length) continue;
    items = items.filter(i => i.league !== d.league).concat(d.items); clubs = clubs.filter(c => c.league !== d.league).concat(d.clubs.map(c => ({ league: d.league, ...c })));
    leagueMeta[d.league] = { updated: today, source: d.nightly ? 'Wikipedia club articles (refreshed nightly)' : d.league === 'mls' ? 'Wikipedia MLS club articles' : 'Wikipedia club season articles' };
  }
  if (items.length) {
    items.sort((a, b) => (a.name < b.name ? -1 : a.name > b.name ? 1 : a.team < b.team ? -1 : 1));
    const updated = Object.values(leagueMeta).map(x => x.updated).sort().pop() || today;
    const dir = { schema: 1, updated, source: 'Wikipedia', license: 'CC BY-SA 4.0', license_url: 'https://creativecommons.org/licenses/by-sa/4.0/', note: 'Names, clubs and positions only. Squad tables on Wikipedia can lag real transfers; each club carries its own as_of date.', leagues: leagueMeta, clubs, items };
    wr('data-directory.json', dir); manifest.directory = { file: 'data-directory.json', count: items.length, clubs: clubs.length, updated, source: dir.source, license: dir.license, leagues: Object.fromEntries(Object.entries(leagueMeta).map(([k, v]) => [k, { ...v, count: items.filter(i => i.league === k).length }])) };
  }
}
{ // photos: only Commons thumbnails with a free licence, author and file page; only for players in the directory
  const src = photosInput || rd('data-photos.json'); const dirIds = new Set((rd('data-directory.json')?.items || []).map(i => i.id));
  if (src?.items) { const items = {}; let bad = 0;
    const blocked = src.blocked || {}; // removed after a check by eye: never shown, and the site does not look them up live either
    for (const [id, v] of Object.entries(src.items)) { if (blocked[id]) continue; if (dirIds.has(id) && /^https:\/\/upload\.wikimedia\.org\//.test(v.thumb || '') && v.license && v.page && /^(cc[ -]?by|cc0|public domain|pd)/i.test(v.license)) items[id] = { qid: v.qid, file: v.file, thumb: v.thumb, thumb_sm: v.thumb_sm, page: v.page, artist: v.artist, license: v.license, license_url: v.license_url }; else bad++; }
    if (bad) report.warnings.push(`photos: ${bad} entries skipped (not in directory or not freely licensed)`);
    // Players already checked with no safe photo: the site shows the silhouette without repeating the live lookup.
    const none = [...new Set([...Object.keys(src.none || {}), ...Object.keys(blocked), ...(src.checked_none || [])])].filter(id => dirIds.has(id) && !items[id]).sort();
    const updated = photosInput ? today : src.updated; wr('data-photos.json', { schema: 1, updated, source: 'Wikimedia Commons', items, checked_none: none }); manifest.photos = { file: 'data-photos.json', count: Object.keys(items).length, checked_none: none.length, updated }; }
}
manifest.sources = [...sources.values()].filter(x => !x.id.startsWith('src:')); manifest.notes = manifestNotes || oldManifest?.notes || [];
// Cache keys (owner audit 21 Oct): every file listed gets a content version v (first 12 hex of its SHA-256). The site fetches each file
// with ?v=<its own v>, so a changed file is always fetched fresh even when 'generated' did not move (e.g. a hand-uploaded fix), and an
// unchanged large file keeps its browser cache across refreshes.
{ const ver = e => { if (e && e.file && fs.existsSync(path.join(outDir, e.file))) e.v = crypto.createHash('sha256').update(fs.readFileSync(path.join(outDir, e.file))).digest('hex').slice(0, 12); };
  for (const k of ['fixtures', 'news', 'directory', 'player_index', 'photos']) ver(manifest[k]); for (const e of manifest.team_matches) ver(e); for (const e of manifest.player_matches) ver(e); }
wr('data-manifest.json', manifest);

console.log(JSON.stringify({ wrote: fs.readdirSync(outDir).filter(f => f.startsWith('data-')), fixtures: fxItems.length, news: newsItems.length, team_matches: manifest.team_matches.map(e => `${e.league}-${e.season}:${e.count}`), player_matches: manifest.player_matches.map(e => `${e.league}-${e.season}:${e.matches}m/${e.rows}r`), players: idxItems.length, directory: manifest.directory?.count ?? 0 }, null, 1));
report.notes.forEach(n => console.log('note:', n)); report.warnings.forEach(n => console.log('warning:', n)); report.errors.forEach(n => console.log('ERROR:', n));
if (report.errors.length) console.log(`\n${report.errors.length} problem(s) found. Rows listed above were skipped; everything else was written.`);
