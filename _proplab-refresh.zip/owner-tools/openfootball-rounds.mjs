// Writes the round (matchweek) calendar of one league season from an openfootball/football.json file (CC0) as a PropLab rounds-*.txt file.
// Usage: node owner-tools/openfootball-rounds.mjs <league-key> <source-timezone> <in.json> <out.txt>
//   e.g. node owner-tools/openfootball-rounds.mjs epl Europe/London en.1.json data-src/leagues/rounds-epl-openfootball.txt
// One line per match (played or not): league|round number|UK date|home|away. The builder uses it to tag fixtures with their round
// and to work out each round's date window for Hiwi's Section "This Gameweek". Dates are converted to UK dates when a kick-off time is given.
import fs from 'node:fs';
const [lg, tz, inp, outp] = process.argv.slice(2);
if (!lg || !tz || !inp || !outp) { console.error('usage: <league> <tz> <in.json> <out.txt>'); process.exit(1); }
const j = JSON.parse(fs.readFileSync(inp, 'utf8'));
const toUtc = (date, time) => { const guess = Date.parse(`${date}T${time}:00Z`); let t = guess;
  for (let i = 0; i < 2; i++) { const p = Object.fromEntries(new Intl.DateTimeFormat('en-GB', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(new Date(t)).map(x => [x.type, x.value]));
    const shown = Date.parse(`${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}:00Z`); t += guess - shown; }
  return new Date(t); };
const ukDate = d => new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/London' }).format(d);
const lines = [`# league|round|UK date|home|away   (openfootball/football.json ${j.name || ''}, CC0; round calendar for "This Gameweek")`];
let n = 0, skipped = 0;
for (const m of j.matches || []) {
  const r = Number(String(m.round || '').match(/(\d+)/)?.[1]);
  if (!r || !/^\d{4}-\d{2}-\d{2}$/.test(m.date || '')) { skipped++; continue; }
  const d = m.time ? ukDate(toUtc(m.date, m.time)) : m.date;
  lines.push([lg, r, d, m.team1, m.team2].join('|')); n++;
}
fs.writeFileSync(outp, lines.join('\n') + '\n'); console.log(`${n} matches written (${skipped} without a round number skipped)`);
